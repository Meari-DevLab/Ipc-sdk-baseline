/**
 * @file        hal_watchdog.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/05/08
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_WATCHDOG_H_
#define _MCP_WATCHDOG_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum mcp_watchdog_type {
    MCP_BASE_TYPE,
    MCP_S0_MVSTREAM_TYPE,
    MCP_S1_MVSTREAM_TYPE,
    MCP_S0_SVSTREAM_TYPE,
    MCP_S1_SVSTREAM_TYPE,
    MCP_HIGH_CPU_USAGE_TYPE,
    MCP_DP_MSG_MANAGE_TYPE,
    MCP_MQTT_STATUS_TYPE,
    MCP_AAC_ASTREAM_TYPE,
} MCP_WATCHDOG_TYPE_E;

typedef pps_s32 (*mcp_software_dog_feed_timeout_f)(pps_s32 type);

/** @fn      pps_s32 mcp_software_watchdog_init(pps_void *dua_handler, pps_s32 interval_s, mcp_software_dog_feed_timeout_f time_out_cb);
 * @brief   <software dog init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] interval_s : timeout
 * @param   [in] time_out_cb: feed dog timeout callback
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_init(pps_void *dua_handler, pps_s32 interval_s, mcp_software_dog_feed_timeout_f time_out_cb);

/** @fn      pps_s32 mcp_software_watchdog_deinit(pps_void);
 * @brief   <software watchdog deinit>
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_deinit(pps_void);

/** @fn      pps_s32 mcp_software_watchdog_node_register(pps_char *node_id, pps_s32 threshold, MCP_WATCHDOG_TYPE_E type);
 * @brief   <register software watchdog>
 * @param   [in] node_id    : node id
 * @param   [in] threshold  : allow number of error threshold
 * @param   [in] type       : software watchdog type
 * @return  0 - success | else - failure
 * @note    once register dog, hardware dog will also be fed.
 */
pps_s32 mcp_software_watchdog_node_register(pps_u8 *node_id, pps_s32 threshold, MCP_WATCHDOG_TYPE_E type);

/** @fn      pps_s32 mcp_software_watchdog_node_unregister(pps_char *node_id);
 * @brief   <unregister software watchdog>
 * @param   [in] node_id: node id
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_node_unregister(pps_u8 node_id);

/** @fn      pps_s32 watchdog_feed(pps_char *node_id);
 * @brief   <feed software watchdog>
 * @param   [in] node_id: node id
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_feed(pps_u8 node_id);

#ifdef __cplusplus
}
#endif
#endif /* __HAL_WATCHDOG_H */
