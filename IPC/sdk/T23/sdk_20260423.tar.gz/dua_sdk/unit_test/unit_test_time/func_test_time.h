/**
 * @file        time_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/07
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_TIME_H
#define __FUNC_TEST_TIME_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include "pps_osal_type.h"

/** @fn      pps_s32 time_test_module(pps_void *dua_handler, pps_slong cur_sec, pps_char* tmz);
 * @brief   <time test>
 * @param   [in] dua_handler : dua 句柄 cur_sec：current time tmz: 时区信息
 * @return  1 - success | 0 - failure
 */
pps_s32 time_test_module(pps_void *dua_handler, pps_slong cur_sec, pps_char *tmz);

#ifdef __cplusplus
}
#endif
#endif /* __TIME_TEST_H */
