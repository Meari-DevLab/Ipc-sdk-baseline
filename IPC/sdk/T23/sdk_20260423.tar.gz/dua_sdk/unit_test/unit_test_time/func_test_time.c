/**
 * @file        time_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       time test
 *
 * @author      lihao
 *
 * @date        2023/04/07
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "dua_time.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "func_test_time.h"

pps_s32 time_test_module(pps_void *dua_handler, pps_slong cur_sec, pps_char *tmz)
{
    pps_char *ret1 = NULL;
    pps_char *ret2 = NULL;
    pps_s32 ret = PPS_TEST_FAILURE;
    struct timeval get_tv = {0};
    struct timeval current_tv = {0};
    pps_char timezone_read[64] = {0};
    FILE *fd = NULL;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    if (tmz == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_time_set_timezone(tmz, 64);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua time set timezone failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    fd = fopen("/etc/TZ", "r");
    if (fd == NULL) {
        PPS_ERROR("func[%s] fopen /etc/timezone! fail\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = fread(timezone_read, 1, sizeof(timezone_read), fd);
    if (ret < 0) {
        PPS_ERROR("func[%s] fread /etc/timezone fail!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    if (fd) {
        fclose(fd);
    }

    // pps_file_read("/etc/timezone", timezone_read, sizeof(timezone_read));

    PPS_INFO("timezone read %s\n", timezone_read);

    ret1 = strstr(timezone_read, "CST");
    if (!ret1) {
        PPS_ERROR("writ and read is not!\n");
        return PPS_TEST_FAILURE;
    }

    ret2 = strstr(timezone_read, "8:00:00");
    if (!ret2) {
        PPS_ERROR("writ and read is not!\n");
        return PPS_TEST_FAILURE;
    }

    current_tv.tv_sec = cur_sec;

    ret = dua_time_set_systime(current_tv.tv_sec);
    if (ret != 0) {
        PPS_ERROR("dua time set systime failure!\n");
        return PPS_TEST_FAILURE;
    }

    ret = gettimeofday(&get_tv, NULL);
    if (ret != 0) {
        PPS_ERROR("gettimeofday failure!\n");
        return PPS_TEST_FAILURE;
    }

    PPS_INFO("current_tv sec:%ld; get_tv sec:%ld\n", current_tv.tv_sec, get_tv.tv_sec);

    if (current_tv.tv_sec != get_tv.tv_sec) {
        PPS_ERROR("func[%s] current_tv.tv_sec != get_tv.tv_sec!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}
