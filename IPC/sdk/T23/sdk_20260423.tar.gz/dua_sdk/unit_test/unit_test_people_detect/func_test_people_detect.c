/**
 * @file        people_detect_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       people detect test
 *
 * @author      lihao
 *
 * @date        2023/04/04
 *
 * @version     1.0.0
 *
 * @note
 */
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#include "dua_base.h"
#include "dua_common.h"
#include "test_comm_def.h"
#include "dua_event_def.h"
#include "dua_config_def.h"
#include "dua_config_mgr.h"
#include "func_test_people_detect.h"

static mutex_cond_t people_mutex_cond = {{{0}}};

pps_void people_detect_test_event_cb(pps_u32 event_id, pps_void *data, pps_s32 data_len)
{
    if (DUA_EVENT_AVPROC_PD_IN_GIRD_ALARM == event_id && !people_mutex_cond.connect_sigevent) {
        people_mutex_cond.connect_sigevent = 1;
        pthread_cond_signal(&(people_mutex_cond.cv));
    }

    PPS_INFO("event_id : %d\n", event_id);

    return;
}

pps_s32 people_detect_test_module(pps_void *dua_handler)
{
    pps_s32 ret = PPS_TEST_FAILURE;
    DUA_DEVICE_CFG_PTR dev_cfg = NULL;
    pps_s32 i = 0;
    struct timespec tv = {0};
    pps_void *avproc_handler = NULL;
    DUA_AVPROC_CFG_T avproc_cfg = {0};
    pps_char region[9][16] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                              {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    dua_dev_config_read(dua_handler, &dev_cfg);



    // register people detect event
    people_mutex_cond.connect_sigevent = 0;
    pthread_condattr_init(&(people_mutex_cond.cattr));
    pthread_mutex_init(&(people_mutex_cond.mutex), NULL);
    pthread_condattr_setclock(&(people_mutex_cond.cattr), CLOCK_MONOTONIC);
    pthread_cond_init(&(people_mutex_cond.cv), &(people_mutex_cond.cattr));

    avproc_cfg.type = DUA_AVPROC_PEOPLE_DETECTION;
    avproc_cfg.sensor_nums = dev_cfg->sensor_num;

    avproc_handler = dua_avproc_init(dua_handler, &avproc_cfg);
    if (avproc_handler == NULL) {
        PPS_ERROR("func[%s] dua avproc init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    for (i = 0; i < avproc_cfg.sensor_nums; i++) {
        ret = dua_avproc_enable(avproc_handler, 1, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_start(avproc_handler, 1, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_set_detect_sensitivity(avproc_handler, 2, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect_sensitivity failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_set_detect_zone(avproc_handler, 0, region, sizeof(DUA_AVPROC_ALARM_BITMAP_ROI_T), i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }
    }

    ret = dua_avproc_event_register(dua_handler, people_detect_test_event_cb);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua register event receiver failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    clock_gettime(CLOCK_MONOTONIC, &tv);
    tv.tv_sec += 60; // Set the event timeout return after 60 seconds
    pthread_cond_timedwait(&(people_mutex_cond.cv), &(people_mutex_cond.mutex), &tv);

    if (people_mutex_cond.connect_sigevent == 1) {
        PPS_INFO("people detect success!\n");
    }

    ret = dua_avproc_deinit(avproc_handler, avproc_cfg.sensor_nums);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    for (i = 0; i < avproc_cfg.sensor_nums; i++) {
        ret = dua_avproc_enable(avproc_handler, 0, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_start(avproc_handler, 0, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }
    }

    return PPS_TEST_SUCCESS;
}
