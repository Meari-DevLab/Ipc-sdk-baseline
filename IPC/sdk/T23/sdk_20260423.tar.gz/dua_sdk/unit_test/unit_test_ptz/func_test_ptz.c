/**
 * @file        ptz_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       ptz move test
 *
 * @author      lihao
 *
 * @date        2023/04/10
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "dua_ptz.h"
#include "dua_common.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"

pps_s32 ptz_ctrl_test_module(pps_void *dua_handler)
{
    pps_s32 ret = PPS_TEST_FAILURE;
    DUA_PTZ_MOVE_CTRL_CMD_E cmd = 0;
#ifndef DUA_CONFIG_BATTERY_DEVICE
    pps_s32 move_steps;
#endif

#ifndef DUA_CONFIG_BATTERY_DEVICE
    ret = dua_ptz_set_origin(0,0);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua set origin failure!\n");
        return PPS_TEST_FAILURE;
    }
    PPS_INFO("SET ORIGIN SUCCESE!\n");
#endif
    // set ptz move left 2s
    cmd = DUA_PTZ_MOVE_CTRL_CMD_LEFT;

    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(2);

    // set ptz stop move
    cmd = DUA_PTZ_MOVE_CTRL_CMD_HORIZONTAL_STOP;
    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

#ifndef DUA_CONFIG_BATTERY_DEVICE
    move_steps = dua_ptz_get_steps(DUA_MOTOR_P_TYPE);
    PPS_INFO("LEFT MOVE STEPS:%d\n",move_steps);
#endif
    // set ptz move right 2s
    cmd = DUA_PTZ_MOVE_CTRL_CMD_RIGHT;

    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(2);

    // set ptz stop move
    cmd = DUA_PTZ_MOVE_CTRL_CMD_HORIZONTAL_STOP;
    ret = dua_ptz_move_ctrl(dua_handler, cmd, 600, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

#ifndef DUA_CONFIG_BATTERY_DEVICE
    move_steps = dua_ptz_get_steps(DUA_MOTOR_P_TYPE);
    PPS_INFO("RIGHT MOVE STEPS:%d\n",move_steps);
#endif
    // set ptz move DOWN 2s
    cmd = DUA_PTZ_MOVE_CTRL_CMD_DOWN;

    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(2);

    // set ptz stop move
    cmd = DUA_PTZ_MOVE_CTRL_CMD_VERTICAL_STOP;
    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

#ifndef DUA_CONFIG_BATTERY_DEVICE
    move_steps = dua_ptz_get_steps(DUA_MOTOR_T_TYPE);
    PPS_INFO("DOWN MOVE STEPS:%d\n",move_steps);
#endif

    // set ptz move DOWN 2s
    cmd = DUA_PTZ_MOVE_CTRL_CMD_UP;

    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(2);

    // set ptz stop move
    cmd = DUA_PTZ_MOVE_CTRL_CMD_VERTICAL_STOP;
    ret = dua_ptz_move_ctrl(dua_handler, cmd, 500, 2000);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua ptz move ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

#ifndef DUA_CONFIG_BATTERY_DEVICE
    move_steps = dua_ptz_get_steps(DUA_MOTOR_T_TYPE);
    PPS_INFO("UP MOVE STEPS:%d\n",move_steps);
#endif

    return PPS_TEST_SUCCESS;
}

