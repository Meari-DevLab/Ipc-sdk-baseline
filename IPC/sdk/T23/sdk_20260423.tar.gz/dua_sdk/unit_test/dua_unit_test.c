#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "dua_time.h"
#include "cmockery.h"
#include "dua_base.h"

#include "pps_osal_log.h"
#include "pps_osal_type.h"
#include "dua_event_def.h"
#include "func_test_ptz.h"
#include "func_test_wifi.h"
// #include "func_test_time.h"
#include "func_test_light.h"
#include "func_test_media.h"
#include "func_test_sdcard.h"
#include "func_test_upgrade.h"
#include "func_test_recorder.h"
#include "func_test_device_info.h"
#include "func_test_motion_detect.h"
#include "func_test_people_detect.h"


pps_void *dua_handler = NULL;
DUA_NETWORK_WIFI_PARAM_T wlan_info ;
pps_char qr_result[128] = "1234"; // 去除头尾字符后的结果
pps_slong g_cur_sec = 1681197743; // 2023-04-11 15:22:23
pps_char g_tmz[64] = "CST08:00:00";

// static void wifi_test(void **state);
static void motion_detect_test(void **state);
static void people_detect_test(void **state);
static void device_info_test(void **state);
static void light_test(void **state);
static void sdcard_test(void **state);
// static void time_test(void **state);
// static void media_init_test(void **state);
// static void media_deinit_test(void **state);
static void ptz_test(void **state);
static void upgrade_test(void **state);
static void recorder_test(void **state);
static void media_func_test(void **state);
static void media_func_test(void **state);
// static void deinit_test(void **state);
// static void config_mgr_test(void **state);

const UnitTest tests[] = {
//   unit_test(media_init_test),
//   unit_test(time_test),

  unit_test(media_func_test),
  unit_test(recorder_test),
  unit_test(sdcard_test),
  unit_test(device_info_test),
  unit_test(light_test),
  unit_test(people_detect_test),
  unit_test(motion_detect_test),
//   unit_test(wifi_test),
  unit_test(ptz_test),
//   unit_test(deinit_test),

//   unit_test(upgrade_test),
  unit_test(upgrade_test),
    // unit_test(config_mgr_test),
};


int main()
{
    dua_handler = dua_init(NULL);
    if (dua_handler == NULL) {
        PPS_ERROR("dua sdk new failure!\n");
        return -1;
    }

    // PPS_INFO("------------------------------------TEST START------------------------------------\n");
    run_tests(tests);

    // PPS_INFO("------------------------------------TEST END------------------------------------\n");

    // ret = dua_deinit(dua_handler);

    while (1) {
        usleep(100000);
        PPS_INFO("test running!\n");
    }

    return 0;
}
// void config_mgr_test(void **state)
// {
//     assert_true(config_mgr_test_module(dua_handler, 10));

//     return;
// }
// void wifi_test(void **state)
// {
//     assert_true(wifi_test_module(dua_handler, "wlan0", wlan_info));

//     return;
// }

void people_detect_test(void **state)
{
    // assert_true(people_detect_test_module(dua_handler));

    return;
}

void motion_detect_test(void **state)
{
    assert_true(motion_detect_test_module(dua_handler));

    return;
}

void device_info_test(void **state)
{
    // assert_true(get_device_info_test_module(dua_handler));

    return;
}

void light_test(void **state)
{

    // assert_true(light_test_init(dua_handler));

    // custom_ligt_test();
    // assert_true(led_light_test_module(DUA_LED_BLUE));
    // // assert_true(rgb_light_test_module(50, 50 , 50));
    // assert_true(white_light_test_module(50));
    // assert_true(infrared_light_test_module());

    return;
}

void sdcard_test(void **state)
{
    // assert_true(sd_card_test_module(dua_handler, "/mnt/mmc01/"));

    return;
}

// void time_test(void **state)
// {
//     assert_true(time_test_module(dua_handler, g_cur_sec, g_tmz));

//     return;
// }

void media_func_test(void **state)
{
    //1.media init test
    // playback_test_module();
    assert_true(media_init_test_module(dua_handler));

    // // //2.set media register
    // assert_true(media_avstream_test_module(dua_handler));

    // //set fps test
    // assert_true(media_fps_test_module(dua_handler));
    // sleep(20);
    // media_deinit_test_module(dua_handler);

    // assert_true(media_snapday_test_module(dua_handler));
    // assert_true(qrcode_test_module(dua_handler, qr_result));

    //assert_true(media_deinit_test_module(dua_handler));

    return;
}

// void media_deinit_test(void **state)
// {
//     assert_true(media_deinit_test_module(dua_handler));

//     return;
// }

void ptz_test(void **state)
{
    // assert_true(ptz_ctrl_test_module(dua_handler));

    return;
}

void upgrade_test(void **state)
{
    // assert_true(upgrade_by_buffer_test_module(dua_handler));

    return;
}

void recorder_test(void **state)
{

    // assert_true(recorder_test_module(dua_handler));

    return;
}

// void deinit_test(void **state)
// {
// #ifdef DUA_CONFIG_STORAGE_SUPPORT
//     assert_true(recorder_deinit_test_module(dua_handler));
// #endif
//     assert_true(sd_card_deinit_test_module(dua_handler));
//     assert_true(wifi_test_deinit_module(dua_handler));
//     assert_true(media_deinit_test_module(dua_handler));

//     return;
// }