/**
 * @file        sdcord_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/07
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_SDCORD_H
#define __FUNC_TEST_SDCORD_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#include "pps_osal_type.h"

/** @fn      pps_s32 sd_card_test_module(pps_void *dua_handler, pps_char *mount_dir)
 * @brief   <sdcard test module>
 * @param   [in] dua_handler : dua 句柄, mount_dir: 挂载目录
 * @return  1 - success | 0 - failure
 */
pps_s32 sd_card_test_module(pps_void *dua_handler, pps_char *mount_dir);

/** @fn      pps_s32 sd_card_deinit_test_module(pps_void *dua_handler);
 * @brief   <sdcard test module>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 sd_card_deinit_test_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __SDCORD_TEST_H */
