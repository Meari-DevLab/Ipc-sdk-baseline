/**
 * @file        sdcord_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       sdcard test
 *
 * @author      lihao
 *
 * @date        2023/04/07
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#include "dua_base.h"
#include "dua_media.h"
#include "dua_sdcard.h"
#include "dua_common.h"
#include "dua_storage.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "dua_event_def.h"

static pps_void sdcard_test_event_cb(pps_u32 event_id, pps_void *data, pps_s32 data_len);
static pps_s32 sd_card_format_test_module(pps_void *dua_handler);
pps_void sdcard_test_event_cb(pps_u32 event_id, pps_void *data, pps_s32 data_len)
{
    pps_s32 ret = 0;
    DUA_SDCARD_INFO_T sdcard_info = {{0}};
    DUA_SDCARD_STATUS_T sd_status = {0};

    if (event_id == DUA_EVENT_SDCARD_MOUNT_DONE) {
         // get the SD card status
        // PPS_ERROR("func[%s] dua sdcard get status failure!\n", __func__);

        PPS_WARN("------------dua_sdcard_get_status--------------------------\n");
        ret = dua_sdcard_get_status(&sd_status);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua sdcard get status failure!\n", __func__);
        }

        PPS_INFO("sd card state : %d\n", sd_status.status);
        PPS_INFO("sd card state : %d\n", sd_status.err_code);

        // get the SD card info
        ret = dua_sdcard_get_info(&sdcard_info);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua sdcard get info failure!\n", __func__);
        }

        PPS_INFO("sdcard mount dir is [%s]\n", sdcard_info.mount_dir);
        PPS_INFO("total_bytes is [%lld]\n", sdcard_info.total_bytes);
        PPS_INFO("used_bytes is [%lld]\n", sdcard_info.used_bytes);
        PPS_INFO("avail_bytes is [%lld]\n", sdcard_info.free_bytes);
    }

    return;
}

pps_s32 sd_card_test_module(pps_void *dua_handler, pps_char *mount_dir)
{
    pps_s32 ret = PPS_TEST_FAILURE;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    if (mount_dir == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }


    ret = dua_sdcard_init(dua_handler, mount_dir);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua sdcard get status failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    PPS_WARN("--------------------------------------\n");

    dua_sdcard_event_register(dua_handler, sdcard_test_event_cb);
    PPS_WARN("--------------------------------------\n");

    sd_card_format_test_module(dua_handler);

    return PPS_TEST_SUCCESS;
}

pps_s32 sd_card_format_test_module(pps_void *dua_handler)
{
    // pps_s32 retval = -1;
    // pps_s32 percent = 0;

    // retval = dua_sdcard_format();
    // if (retval != 0) {
    //     PPS_ERROR("sdcard format failed: %d\n", retval);
    //     return PPS_TEST_FAILURE;
    // }
    // while (1) {
    //     percent = dua_sdcard_get_format_percent();
    //     if (percent == 100) {
    //         PPS_INFO("SDCARD FORMAT SUCCESS! %d\n",percent);
    //         break;
    //     } else {
    //         PPS_INFO("FORMAT PERCENT:%d\n",percent);
    //         sleep(1);
    //     }
    // }

    return PPS_TEST_SUCCESS;
}
pps_s32 sd_card_deinit_test_module(pps_void *dua_handler)
{
    pps_s32 ret = 0;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_sdcard_deinit(dua_handler);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua sdcard deinit failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}
