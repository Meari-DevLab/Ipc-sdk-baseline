/**
 * @file        motion_detect_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       motion detect test
 *
 * @author      lihao
 *
 * @date        2023/04/06
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "dua_base.h"
#include "dua_common.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "dua_event_def.h"
#include "dua_config_def.h"
#include "dua_config_mgr.h"
#include "func_test_motion_detect.h"

static mutex_cond_t motion_mutex_cond = {{{0}}};

pps_void motion_detect_test_event_cb(pps_u32 event_id, pps_void *data, pps_s32 data_len)
{
    if (DUA_EVENT_AVPROC_MD_IN_GIRD_ALARM == event_id && !motion_mutex_cond.connect_sigevent) {
        motion_mutex_cond.connect_sigevent = 1;
        pthread_cond_signal(&(motion_mutex_cond.cv));
    }

    PPS_INFO("event_id : %d\n", event_id);

    return;
}

pps_s32 motion_detect_test_module(pps_void *dua_handler)
{
    pps_s32 ret = PPS_TEST_FAILURE;
    DUA_DEVICE_CFG_PTR dev_cfg = NULL;
    pps_s32 i = 0;
    struct timespec tv = {0};
    pps_void *avproc_handler = NULL;
    DUA_AVPROC_CFG_T avproc_cfg = {0};
    DUA_AVPROC_ALARM_BITMAP_ROI_T bitmap_zone[DUA_MAX_SENSOR_NUM];

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    dua_dev_config_read(dua_handler, &dev_cfg);
    // register motion detect event
    motion_mutex_cond.connect_sigevent = 0;
    pthread_condattr_init(&(motion_mutex_cond.cattr));
    pthread_mutex_init(&(motion_mutex_cond.mutex), NULL);
    pthread_condattr_setclock(&(motion_mutex_cond.cattr), CLOCK_MONOTONIC);
    pthread_cond_init(&(motion_mutex_cond.cv), &(motion_mutex_cond.cattr));

    memset(bitmap_zone, 0, sizeof(bitmap_zone));

    avproc_cfg.type = DUA_AVPROC_MOTION_DETECTION;
    avproc_cfg.sensor_nums = dev_cfg->sensor_num;

    avproc_handler = dua_avproc_init(dua_handler, &avproc_cfg);
    if (avproc_handler == NULL) {
        PPS_ERROR("func[%s] dua avproc init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    for (i = 0; i < avproc_cfg.sensor_nums; i++) {
        strncpy(bitmap_zone[i].bitmap, "010061E07CE07FE03D483FD83F901E800000", sizeof(bitmap_zone[i].bitmap));

        avproc_cfg.zone_type[i] = DUA_ZONE_TYPE_RECTANGLES;
        avproc_cfg.zone = bitmap_zone[i].bitmap;
        avproc_cfg.zone_size[i] = sizeof(DUA_AVPROC_ALARM_BITMAP_ROI_T);

        ret = dua_avproc_set_detect_zone(avproc_handler,
                                            avproc_cfg.zone_type[i],
                                            avproc_cfg.zone + i * avproc_cfg.zone_size[i],
                                            avproc_cfg.zone_size[i],
                                            i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_set_detect_sensitivity(avproc_handler, 3, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect_sensitivity failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        // enable grid
        ret = dua_avproc_enable(avproc_handler, 1, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        // start detection
        ret = dua_avproc_start(avproc_handler, PPS_TRUE, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }
    }

    ret = dua_avproc_event_register(dua_handler, motion_detect_test_event_cb);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua register event eceiver failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    clock_gettime(CLOCK_MONOTONIC, &tv);
    tv.tv_sec += 60; // Set the event timeout return after 60 seconds
    pthread_cond_timedwait(&(motion_mutex_cond.cv), &(motion_mutex_cond.mutex), &tv);

    if (motion_mutex_cond.connect_sigevent == 1) {
        PPS_INFO("motion detect success!\n");
    }

    ret = dua_avproc_deinit(avproc_handler, avproc_cfg.sensor_nums);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    for (i = 0; i < avproc_cfg.sensor_nums; i++) {
        ret = dua_avproc_enable(avproc_handler, 0, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }

        ret = dua_avproc_start(avproc_handler, 0, i);
        if (ret != 0) {
            PPS_ERROR("func[%s] dua avproc set detect zone failure!\n", __func__);
            return PPS_TEST_FAILURE;
        }
    }

    return PPS_TEST_SUCCESS;
}
