/**
 * @file        people_detect_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/06
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_MOTION_DETECT_H
#define __FUNC_TEST_MOTION_DETECT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "dua_media.h"
#include "dua_avproc.h"
#include "pps_osal_log.h"
#include "pps_osal_type.h"

/** @fn    pps_s32 motion_detect_test_module(pps_void *dua_handler);
 * @brief   <motion_detect_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 motion_detect_test_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __PEOPLE_DETECT_TEST_H */
