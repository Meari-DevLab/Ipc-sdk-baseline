/**
 * @file        device_info_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/03
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_DEVICE_INFO_H
#define __FUNC_TEST_DEVICE_INFO_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#include "dua_base.h"

/** @func    pps_s32 get_device_info_test(pps_void *dua_handler);
 * @brief   <get device info test>
 * @param   [in] dua_handler : dua handler
 * @return  1 - success | 0 - failure
 */
pps_s32 get_device_info_test_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __DEVICE_INFO_TEST_H */