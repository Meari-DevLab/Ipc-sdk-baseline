/**
 * @file        device_info_test.c
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       device info test
 *
 * @author      lihao
 *
 * @date        2023/04/03
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <string.h>

#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "func_test_device_info.h"

pps_s32 get_device_info_test_module(pps_void *dua_handler)
{
    DUA_BOARD_INFO_PTR dua_board_info_handler = NULL;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    dua_board_info_handler = dua_get_board_info(dua_handler);
    ;

    if (dua_board_info_handler == NULL) {
        PPS_ERROR("func[%s] dua get board info fail!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    // get device info

    PPS_INFO("device name: %s\n", dua_board_info_handler->name);
    PPS_INFO("device_type: %d\n", dua_board_info_handler->device_type);
    PPS_INFO("model_name: %s\n", dua_board_info_handler->model_name);
    PPS_INFO("sensor_name: %s\n", dua_board_info_handler->name);
    PPS_INFO("pcb name: %s\n", dua_board_info_handler->pcb_name);
    PPS_INFO("hardware_version: %s\n", dua_board_info_handler->hardware_version);
    PPS_INFO("software_version: %s\n", dua_board_info_handler->software_version);
    PPS_INFO("firmware_version: %s\n", dua_board_info_handler->firmware_version);
    PPS_INFO("software_buildtime: %s\n", dua_board_info_handler->software_buildtime);
    PPS_INFO("wifi_module: %d\n", dua_board_info_handler->wifi_module);
    PPS_INFO("soc_name: %s\n", dua_board_info_handler->soc_name);
    PPS_INFO("flash_type: %d\n", dua_board_info_handler->flash_type);
    PPS_INFO("country_id: %d\n", dua_board_info_handler->country_id);
    PPS_INFO("wifi_mac: %s\n", dua_board_info_handler->wifi_mac);
    PPS_INFO("mcu_version: %s\n", dua_board_info_handler->mcu_version);

    return PPS_TEST_SUCCESS;
}
