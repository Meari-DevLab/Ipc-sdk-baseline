/**
 * @file        light_test.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/03
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_LIGHT_H
#define __FUNC_TEST_LIGHT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "dua_light.h"
#include "pps_osal_log.h"
#include "pps_osal_type.h"

/** @fn      pps_s32 light_test_init(pps_void *handler);
 * @brief   <dua light init>
 * @param   [in] dua_handler: dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 light_test_init(pps_void *dua_handler);

/** @fn      pps_s32 led_light_test_module(DUA_LED_ID_E led_id)
 * @brief   <led light test>
 * @param   [in] led_id: led id
 * @return  1 - success | 0 - failure
 */
pps_s32 led_light_test_module(DUA_LED_ID_E led_id);

/** @fn      pps_s32 rgb_light_test_module(pps_s32 red_brightness, pps_s32 green_brightness, pps_s32 blue_brightness);
 * @brief   <rgb light test>
 * @param   [in] red_brightness， green_brightness，blue_brightness ：rgb亮度 0-100
 * @return  1 - success | 0 - failure
 */
pps_s32 rgb_light_test_module(pps_s32 red_brightness, pps_s32 green_brightness, pps_s32 blue_brightness);

/** @fn      pps_s32 white_light_test_module(pps_s32 white_brightness);
 * @brief   <white light test>
 * @param   [in] white_brightness： 白光灯亮度 0-100
 * @return  1 - success | 0 - failure
 */
pps_s32 white_light_test_module(pps_s32 white_brightness);

/** @fn      pps_s32 infrared_light_test(pps_void);
 * @brief   <infrared light test>
 * @return  1 - success | 0 - failure
 */
pps_s32 infrared_light_test_module(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* __LIGHT_TEST_H */
