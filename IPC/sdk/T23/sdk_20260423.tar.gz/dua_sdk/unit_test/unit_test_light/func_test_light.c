/**
 * @file        light_test.c
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       light test
 *
 * @author      lihao
 *
 * @date        2023/04/03
 *
 * @version     1.0.0
 *
 * @note
 */
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "test_comm_def.h"
#include "func_test_light.h"

static pps_void *g_dua_light_handler = NULL;
pps_s32 light_test_init(pps_void *dua_handler)
{
    pps_s32 ret = -1;
    PPS_INFO("----------------LIGHT TEST-----------------\n");
    g_dua_light_handler = dua_handler;
    ret = dua_light_init(g_dua_light_handler);

    if (ret != 0) {
        PPS_ERROR("func[%s] dua_led_ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_s32 led_light_test_module(DUA_LED_ID_E led_id)
{
    pps_s32 ret = -1;
    pps_s32 switch_on = 0;

    PPS_INFO("-------led light test-------\n");
    if (g_dua_light_handler == NULL) {
        PPS_ERROR("func[%s] g_dua_light_handler failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    ret = dua_led_ctrl(g_dua_light_handler, led_id, 1);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua_led_ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_led_get_status(g_dua_light_handler, led_id, &switch_on);
    if (ret != 0 && switch_on != 1) {
        PPS_ERROR("func[%s] dua_led_get_status failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_led_ctrl(g_dua_light_handler, led_id, 0);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua led ctrl failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_led_get_status(g_dua_light_handler, led_id, &switch_on);
    if (ret != 0 && switch_on != 0) {
        PPS_ERROR("dua_led_get_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_s32 rgb_light_test_module(pps_s32 red_brightness, pps_s32 green_brightness, pps_s32 blue_brightness)
{
    pps_s32 ret = -1;
    pps_s32 rd_brightness = -1;
    pps_s32 gr_brightness = -1;
    pps_s32 bl_brightness = -1;

    if (g_dua_light_handler == NULL) {
        PPS_ERROR("func[%s] g_dua_light_handler failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    ret = dua_rgb_light_ctrl(g_dua_light_handler, red_brightness, green_brightness, blue_brightness);
    if (ret != 0) {
        PPS_ERROR(" dua_rgb_light_ctrl failure!\n");
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_rgb_light_get_status(g_dua_light_handler, &rd_brightness, &gr_brightness, &bl_brightness);
    if (ret != 0 && rd_brightness != red_brightness && gr_brightness != green_brightness
        && bl_brightness != blue_brightness) {
        PPS_ERROR("dua_rgb_get_light_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_s32 white_light_test_module(pps_s32 white_brightness)
{
    pps_s32 ret = -1;
    pps_s32 brightness = -1;

    PPS_INFO("--------white light test-------\n");
    if (g_dua_light_handler == NULL) {
        PPS_ERROR("func[%s] g_dua_light_handler failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    ret = dua_white_light_ctrl(g_dua_light_handler, DUA_LIGHT_CTRL_TYPE_HARD, 100);//直接控制
    if (ret != 0) {
        PPS_ERROR("dua_white_light_ctrl failure!\n");
        return PPS_TEST_FAILURE;
    }

    sleep(3);

    ret = dua_white_light_get_status(g_dua_light_handler, &brightness);
    if (ret != 0 && brightness != white_brightness) {
        PPS_ERROR("dua_white_light_get_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    ret = dua_white_light_ctrl(g_dua_light_handler, DUA_LIGHT_CTRL_TYPE_SOFT, 0);//媒体控制
    if (ret != 0) {
        PPS_ERROR("dua_white_light_ctrl failure!\n");
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_white_light_get_status(g_dua_light_handler, &brightness);
    if (ret != 0 && brightness != 0) {
        PPS_ERROR("dua_white_light_get_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_s32 infrared_light_test_module(pps_void)
{
    pps_s32 ret = -1;
    pps_s32 switch_on = -1;

    PPS_INFO("-------infrared light test-------\n");
    if (g_dua_light_handler == NULL) {
        PPS_ERROR("func[%s] g_dua_light_handler failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    ret = dua_infrared_led_ctrl(g_dua_light_handler, DUA_INFR_ID_1, 1);
    if (ret != 0) {
        PPS_ERROR("dua_infrared_led_ctrl failure!\n");
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_infrared_led_get_status(g_dua_light_handler, DUA_INFR_ID_1, &switch_on);
    if (ret != 0 && switch_on != 1) {
        PPS_ERROR("dua_infrared_led_get_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    ret = dua_infrared_led_ctrl(g_dua_light_handler, DUA_INFR_ID_1, 0);
    if (ret != 0) {
        PPS_ERROR("dua_infrared_led_ctrl failure!\n");
        return PPS_TEST_FAILURE;
    }

    sleep(1);

    ret = dua_infrared_led_get_status(g_dua_light_handler, DUA_INFR_ID_1, &switch_on);
    if (ret != 0 && switch_on != 0) {
        PPS_ERROR("dua_infrared_led_get_status failure!\n");
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}


