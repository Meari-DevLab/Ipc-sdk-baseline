/**
 * @file        wifi_test.c
 * @copyright   2016-2022 Meari technology Co., Ltd
 * @brief       wifi test
 * @author      lihao
 * @date        2023/04/04
 * @version     1.0.0
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "dua_base.h"
#include "dua_network.h"
#include "test_comm_def.h"
#include "dua_event_def.h"
#include "func_test_wifi.h"
#include "dua_common.h"

static pps_void *g_wlan0_handler = NULL;

pps_s32 wifi_test_module(pps_void *dua_handler, pps_char *if_name, DUA_NETWORK_WIFI_PARAM_T wifi)
{
    pps_s32 ret = -1;
    DUA_NETWORK_WIFI_PARAM_T wifi_info = {{0}};
    pps_char ipaddr[46] = {0};
    pps_char gateway[32] = {0};
    pps_char netmask[32] = {0};
    pps_char macaddr[6] = {0};

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    if (if_name == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }


    g_wlan0_handler = dua_network_init(dua_handler, if_name);

    if (g_wlan0_handler == NULL) {
        PPS_ERROR("func[%s] dua network init fail!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    memset(&wifi, 0, sizeof(wifi));
    strcpy(wifi.ssid, "QRS-LiPing");
    strcpy(wifi.psw , "56565099");

    ret = dua_network_connect_wifi(g_wlan0_handler, &wifi);
    if (ret != 0) {
        PPS_ERROR("dua_network connect wifi failure!\n");
        return PPS_TEST_FAILURE;
    }

    PPS_INFO("wifi:[%s] connect success!\n", wifi.ssid);

    sleep(7); // Wait until the output is complete
    ret = dua_get_current_interface_changed(); // Get the default gateway being used
    if (ret < 0) {
        PPS_ERROR("input parameter invalid\n");
        return -1;
    }
    PPS_INFO("ssid is [%s]\n", wifi_info.ssid);

    dua_network_get_ipaddr(ipaddr, sizeof(ipaddr));
    PPS_INFO("ipaddr is [%s]\n", ipaddr);

    dua_network_get_gateway(gateway, sizeof(gateway));
    PPS_INFO("gateway is [%s]\n", gateway);

    dua_network_get_netmask(netmask, sizeof(netmask));
    PPS_INFO("netmask is [%s]\n", netmask);

    dua_network_get_mac(macaddr, sizeof(macaddr));
    PPS_INFO("macaddr is [%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx]\n", macaddr[0],
        macaddr[1],
        macaddr[2],
        macaddr[3],
        macaddr[4],
        macaddr[5]);



    return PPS_TEST_SUCCESS;
}



pps_s32 wifi_test_deinit_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;

    if (g_wlan0_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_network_deinit(dua_handler, g_wlan0_handler);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua network deinit failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    g_wlan0_handler = NULL;

    return PPS_TEST_SUCCESS;
}