/**
 * @file        wifi_test.h
 * @copyright   2016-2022 Meari technology Co., Ltd
 * @brief       wifi test
 * @author      lihao
 * @date        2023/04/04
 * @version     1.0.0
 * @note
 */
#ifndef __FUNC_TEST_WIFI_H
#define __FUNC_TEST_WIFI_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#include "dua_common.h"
#include "pps_osal_log.h"
#include "pps_osal_type.h"

/** @fn      pps_s32 wifi_test_module(pps_void *dua_handler, pps_char *if_name, DUA_NETWORK_WIFI_PARAM_T wifi);
 * @brief   <wifi test module>
 * @param   [in] dua_handler : dua 句柄 if_name: 网卡名称 wifi：wifi信息
 * @return  1 - success | 0 - failure
 */
pps_s32 wifi_test_module(pps_void *dua_handler, pps_char *if_name, DUA_NETWORK_WIFI_PARAM_T wifi);

/** @fn      pps_s32 wifi_test_deinit_module(pps_void *dua_handler);
 * @brief   <wifi test module>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 wifi_test_deinit_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __WIFI_TEST_H */