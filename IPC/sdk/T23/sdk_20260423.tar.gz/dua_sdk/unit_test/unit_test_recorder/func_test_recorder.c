/**
 * @file        sdcord_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       sdcard test
 *
 * @author      lihao
 *
 * @date        2023/04/11
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#include "dua_base.h"
#include "dua_media.h"
#include "dua_sdcard.h"
#include "dua_common.h"
#include "dua_storage.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "dua_event_def.h"

static pps_s32 dua_media_avstream(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 len)
{
    if (NULL == header || NULL == data) {
        PPS_ERROR("func[%s] dua recorder init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    dua_recorder_write_avframe(NULL, header, data, len);

    return 0;
}

pps_s32 recorder_test_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_recorder_init(dua_handler, "mnt/mmc01/", "test-56565032", NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua recorder init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_register_avstream(0, dua_media_avstream, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_recorder_set_configs(NULL, DUA_RECORD_TYPE_CONTINUE, 90);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua recorder set configs failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_recorder_start(NULL, 1);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua recorder start failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_s32 recorder_deinit_test_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_recorder_deinit(dua_handler, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua recorder deinit failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}