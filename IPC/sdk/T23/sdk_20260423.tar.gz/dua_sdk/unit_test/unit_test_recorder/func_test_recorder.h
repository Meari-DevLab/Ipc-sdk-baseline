/**
 * @file        sdcord_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/1
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __FUNC_TEST_RECORDER_H
#define __FUNC_TEST_RECORDER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#include "pps_osal_type.h"

/** @fn    pps_s32 recorder_test_module(pps_void *dua_handler);
 * @brief   <recorder test module>
 * @param   [in] dua_handler : dua handler
 * @return  1 - success | 0 - failure
 */
pps_s32 recorder_test_module(pps_void *dua_handler);

/** @fn    pps_s32 recorder_test_module(pps_void *dua_handler);
 * @brief   <recorder test module>
 * @param   [in] dua_handler : dua handler
 * @return  1 - success | 0 - failure
 */
pps_s32 recorder_deinit_test_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __SDCORD_TEST_H */
