/**
 * @file        upgrade_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/10
 *
 * @version     1.0.0
 *
 * @note
 */

#ifndef __FUNC_TEST_UPGRADE_H
#define __FUNC_TEST_UPGRADE_H

#ifdef __cplusplus
extern "C" {
#endif

pps_s32 upgrade_by_img_test_module(pps_void *dua_handler);
pps_s32 upgrade_by_url_test_module(pps_void *dua_handler);
pps_s32 upgrade_by_sdcard_test_module(pps_void *dua_handler);
pps_s32 upgrade_by_buffer_test_module(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* __UPGRADE_TEST_H */
