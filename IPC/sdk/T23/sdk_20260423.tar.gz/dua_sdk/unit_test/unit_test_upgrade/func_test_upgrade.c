/**
 * @file        upgrade_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       upgrade by buffer test.
 *
 * @author      lihao
 *
 * @date        2022/03/23
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "dua_base.h"
#include "dua_common.h"
#include "dua_upgrade.h"
#include "pps_osal.h"
#include "mcp_upgrade_service.h"

MCP_UPGRADE_PERCENT_T g_upgrade_percent_ctx = {0, 0, 0};

typedef struct mcp_upgrade_ctx {
    pps_char *upgrade_buffer;
    pps_s32 upgrade_buffer_size;
} MCP_UPGRADE_CTX_T, *MCP_UPGRADE_CTX_PTR;

MCP_UPGRADE_CTX_T g_upg_buffer_ctx = {
  .upgrade_buffer = NULL,
  .upgrade_buffer_size = 0,
};

/// @brief http rang get function
/// @param file url
/// @param seek_set rang seek
/// @param buffer
/// @param size
/// @return
pps_s32 upgrade_read_ota(pps_void *file, pps_s32 seek_set, pps_void *buffer, pps_s32 size)
{
    //your code Implementation of the http rang get function，buffer Not to malloc，Upgrade component internal management
    return size;
}

/// @brief Read data from fd function
/// @param file fd
/// @param seek_set fd seek
/// @param buffer Direct use buffer ,not malloc
/// @param size
/// @return
pps_s32 upgrade_read_File(pps_void *file, pps_s32 seek_set, pps_void *buffer, pps_s32 size)
{
    pps_s32 retval = 0;
    if (file == NULL || buffer == NULL) {
        return -1;
    }

    FILE *filePtr = (FILE *)file;
    retval = fseek(filePtr, seek_set, SEEK_SET);
    if (retval != 0) {
        PPS_ERROR("fseek failed\n");
        return -1;
    }
    return fread(buffer, 1, size, filePtr);
}


/// @brief 2.Using the Upgrade Component,Upgrade from file,For example, sdcard
/// @param dua_handler
/// @return

pps_s32 upgrade_by_sdcard_test_module(pps_void *dua_handler)
{
    pps_s32 retval = 0;
    pps_s32 upgrade_res = PPS_ERR_FAIL;
    pps_char filename[128] = {0};
    FILE *upgrade_fp = NULL;
    UPGRADE_TYPE_INFO upgrade_info;

    memset(&upgrade_info, 0, sizeof(upgrade_info));

    //Upgrade Firmware Path
	//Need to put the upgrade firmware in the sd card！！
    sprintf(filename, "%s%s", "/mnt/mmc01/", "upgrade.bin");
    if (access(filename, F_OK) != 0) {
        PPS_WARN("filename[%s] is not exist\n", filename);
        return PPS_ERR_FAIL;
    }

    retval = mcp_upgrade_init(dua_handler);
    if (retval != PPS_ERR_SUCCESS) {
        PPS_ERROR("upgrading init faild!\n");
        goto exit;
    }

    upgrade_fp = fopen(filename, "rb");
    if (upgrade_fp == NULL) {
        PPS_ERROR("open %s failure\n", filename);
        goto exit;
    }

    upgrade_info.context = (pps_void *)upgrade_fp;
    upgrade_res = mcp_upgrade_start(dua_handler, upgrade_read_File, upgrade_info);
    if (upgrade_res != PPS_ERR_SUCCESS && upgrade_res != PPS_ERR_UPGRADE_NO_UPGREADE_REQUIRED) {
        PPS_ERROR("ota upgrade start failed: %d\n", upgrade_res);
        goto exit;
    }

exit:
    if (upgrade_fp) {
        fclose(upgrade_fp);
    }

    mcp_upgrade_deinit(dua_handler, upgrade_res);

    return retval;
}

/// @brief 3.Using the Upgrade Component,Upgrade from url, The http server needs to support rang get
/// @param dua_handler
/// @return
pps_s32 upgrade_by_url_test_module(pps_void *dua_handler)
{
    pps_s32 retval;
    pps_s32 upgrade_res = PPS_ERR_FAIL;
    UPGRADE_TYPE_INFO upgrade_info;

    memset(&upgrade_info, 0, sizeof(upgrade_info));

    pps_char upgrade_url[256] = "www.otaurl.com";

    retval = mcp_upgrade_init(dua_handler);
    if (retval) {
        PPS_ERROR("ota upgrade init failed: %d\n", retval);
        goto exit;
    }

    upgrade_info.context = (pps_void *)upgrade_url;
    upgrade_res = mcp_upgrade_start(dua_handler, upgrade_read_ota, upgrade_info);
    if (upgrade_res != PPS_ERR_SUCCESS && upgrade_res != PPS_ERR_UPGRADE_NO_UPGREADE_REQUIRED) {
        PPS_ERROR("ota upgrade start failed: %d\n", upgrade_res);
        goto exit;
    }

exit:
    mcp_upgrade_deinit(dua_handler, upgrade_res);

    return retval;
}

/// @brief 3.Using the Upgrade Component,Upgrade from url,or file ,This function requires data to be read or downloaded into memory first,
////         Injecting upgrade components at the slice
/// @param dua_handler
/// @return
pps_s32 upgrade_by_buffer_test_module(pps_void *dua_handler)
{
    const pps_s32 bufferSize = 2048;
    pps_char buffer[bufferSize];
    pps_s32 retval = 0;
    pps_s32 upgrade_res = PPS_ERR_FAIL;
    pps_char filename[128] = {0};
    FILE *upgrade_fp = NULL;

    sprintf(filename, "%s%s", "/mnt/mmc01/", "upgrade.bin");
    if (access(filename, F_OK) != 0) {
        PPS_WARN("filename[%s] is not exist\n", filename);
        return PPS_ERR_FAIL;
    }

    upgrade_fp = fopen(filename, "rb");
    if (upgrade_fp == NULL) {
        PPS_ERROR("open %s failure\n", filename);
        goto exit;
    }

    retval = mcp_upgrade_init(dua_handler);
    if (retval != PPS_ERR_SUCCESS) {
        PPS_ERROR("upgrading init faild!\n");
        goto exit;
    }

    //Download fixed-size data for input into the Component
    pps_s32 bytesRead = 0;
    while ((bytesRead = fread(buffer, 1, bufferSize, upgrade_fp)) > 0) {
        //Injecting data from memory into the upgrade Component
        retval =  mcp_upgrade_write_buf(dua_handler, buffer, bytesRead);
        if(retval != PPS_SUCCESS){
            PPS_ERROR("upgrade write buf error!\n");
        }
    }

    upgrade_res = mcp_upgrade_start_by_buf(dua_handler);
    if (upgrade_res != PPS_ERR_SUCCESS && upgrade_res != PPS_ERR_UPGRADE_NO_UPGREADE_REQUIRED) {
        PPS_ERROR("ota upgrade start failed: %d\n", upgrade_res);
        goto exit;
    }

exit:
    if (upgrade_fp) {
        fclose(upgrade_fp);
    }

    mcp_upgrade_deinit(dua_handler, upgrade_res);

    return retval;

}