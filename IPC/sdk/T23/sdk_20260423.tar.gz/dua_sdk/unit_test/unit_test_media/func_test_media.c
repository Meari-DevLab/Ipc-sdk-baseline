/**
 * @file        media_test.c
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/10
 *
 * @version     1.0.0
 *
 * @note
 */

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "pps_osal.h"
#include "dua_base.h"
#include "dua_sdcard.h"
#include "dua_common.h"
#include "dua_storage.h"
#include "pps_osal_log.h"
#include "test_comm_def.h"
#include "dua_event_def.h"
#include "func_test_media.h"
#include "dua_config_def.h"
#include "dua_config_mgr.h"
#include "func_test_media.h"
#include "pps_cbuf.h"
#include "dua_sensor.h"

FILE *g_sub_fpsFile = NULL;
FILE *g_main_fpsFile = NULL;


#define FUNC_UNIT_TEST_SNAPSHOT_PATH "/mnt/mmc01/unit_test/snapshot_test"
#define FUNC_UNIT_TEST_FPS_TEST_PATH "/mnt/mmc01/unit_test/fps_test"
#define FUNC_UNIT_TEST_QR_TEST_PATH  "/mnt/mmc01/unit_test/qrcode_test"

#define PPS_RECORD_CBUF_SIZE (1024 * 1024 * 1)

typedef struct record_job_ctx {
    pps_s32 job_id;          // 录像任务ID
    pps_char job_name[32];   // 录像任务ID
    pps_char job_root[16];   // 录像根目录
    pps_u32 is_enable;       // 录像任务是否使能
    pps_u32 is_start;        // 是否在录像
    pps_u32 record_job_type; // PPS_RECORD_TYPE_FULL_DAY-全天录制 | PPS_RECORD_TYPE_EVENT-事件录制
    pps_u32 duration;        // 录像时长
} record_job_ctx_t;

static DUA_MEDIA_INIT_CFG_T g_media_cfg = {0};
static DUA_MEDIA_AUDIO_INIT_CFG_T g_audia_cfg;
static DUA_MEDIA_SENSOR_INIT_CFG_T g_sensor_cfg[2] = {0};;
// static pps_s32 g_main_stream_fps_oft = 20;
// static pps_s32 g_sub_stream_fps_oft = 20;
static pps_char g_qr_result[128] = {0};
DUA_DEVICE_CFG_PTR dev_cfg = NULL;
// static pps_cbuf_t *g_storage_cbuf = NULL;
// static pthread_mutex_t g_storage_cbuf_mutex = PTHREAD_MUTEX_INITIALIZER;
// static record_job_ctx_t g_recorder_job_ctx = {0};

static pps_s32 media_snapshot(pps_char *path);
static pps_void qrcode_get_result_cb(pps_char *data, pps_u32 len);
static pps_s32 media_main_stream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len);
static pps_s32 media_sub_stream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len);
static pps_s32 media_avstream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len);

static pps_s32 media_osd_test(pps_void);

/********************************timezone/daylight/west*********************/

pps_s32 media_init_test_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;

    pps_s32 is_mirror = 0, is_flip = 0;
    pps_s32 spk_vol = 0, mic_vol = 0;

    // DUA_CAPABILITY_PTR dua_capa = NULL;
    // dua_capa = dua_get_device_capacity(MCP_BASE_GET_DUA_HANDLER());


    dua_dev_config_read(dua_handler, &dev_cfg);

    memset(&g_media_cfg, 0, sizeof(g_media_cfg));
    memset(&g_audia_cfg, 0, sizeof(g_audia_cfg));

    g_sensor_cfg[0].main_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.bitrate;
    g_sensor_cfg[0].main_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.fps;
    g_sensor_cfg[0].sub_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.bitrate;
    g_sensor_cfg[0].sub_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.fps;

    g_sensor_cfg[0].flip_mirror_param.is_flip = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].is_flip ^ is_flip;
    g_sensor_cfg[0].flip_mirror_param.is_mirror = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].is_mirror ^ is_mirror;

    g_sensor_cfg[0].main_stream_quality = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.img_quality;
    g_sensor_cfg[0].sub_stream_quality = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.img_quality;

    // encode_type
    g_sensor_cfg[0].main_stream_encode_type = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.encode_type;
    g_sensor_cfg[0].sub_stream_encode_type = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.encode_type;

    g_sensor_cfg[0].is_avproc_use_model = 1;
    g_sensor_cfg[0].sensor_id = DUA_SENSOR_FIRST;

    g_sensor_cfg[0].main_osd_cfg.time_osd_format = 0; //mcp

    g_sensor_cfg[0].main_osd_cfg.time_osd_x_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.osd_x;
    g_sensor_cfg[0].main_osd_cfg.time_osd_y_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.osd_y;

    memcpy(g_sensor_cfg[0].main_osd_cfg.time_osd_prefix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_prefix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_prefix));
    memcpy(g_sensor_cfg[0].main_osd_cfg.time_osd_suffix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_suffix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_suffix));

    g_sensor_cfg[0].sub_osd_cfg.time_osd_format = 0; //mcp

    g_sensor_cfg[0].sub_osd_cfg.time_osd_x_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.osd_x;
    g_sensor_cfg[0].sub_osd_cfg.time_osd_y_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.osd_y;

    memcpy(g_sensor_cfg[0].sub_osd_cfg.time_osd_prefix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_prefix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_prefix));
    memcpy(g_sensor_cfg[0].sub_osd_cfg.time_osd_suffix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_suffix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].osd_suffix));


    g_sensor_cfg[1].main_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.bitrate;
    g_sensor_cfg[1].main_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.fps;

    g_sensor_cfg[1].sub_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.bitrate;
    g_sensor_cfg[1].sub_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.fps;

    g_sensor_cfg[1].flip_mirror_param.is_flip = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].is_flip ^ is_flip;
    g_sensor_cfg[1].flip_mirror_param.is_mirror = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].is_mirror ^ is_mirror;

    g_sensor_cfg[1].main_stream_quality = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.img_quality;
    g_sensor_cfg[1].sub_stream_quality = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.img_quality;

    // encode_type
    g_sensor_cfg[1].main_stream_encode_type = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.encode_type;
    g_sensor_cfg[1].sub_stream_encode_type = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.encode_type;

    g_sensor_cfg[1].is_avproc_use_model = 1;
    g_sensor_cfg[1].sensor_id = DUA_SENSOR_SECOND;

    g_sensor_cfg[1].main_osd_cfg.time_osd_format = 0; // mcp
    g_sensor_cfg[1].main_osd_cfg.time_osd_x_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.osd_x;
    g_sensor_cfg[1].main_osd_cfg.time_osd_y_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.osd_y;

    memcpy(g_sensor_cfg[1].main_osd_cfg.time_osd_prefix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_prefix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_prefix));
    memcpy(g_sensor_cfg[1].main_osd_cfg.time_osd_suffix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_suffix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_suffix));

    // sensor 1 子码流 osd
    g_sensor_cfg[1].sub_osd_cfg.time_osd_format = 0; // mcp
    g_sensor_cfg[1].sub_osd_cfg.time_osd_x_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.osd_x;
    g_sensor_cfg[1].sub_osd_cfg.time_osd_y_pos = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.osd_y;

    memcpy(g_sensor_cfg[1].sub_osd_cfg.time_osd_prefix,
           dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_prefix,
           strlen(dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].osd_prefix));
    // 抗频闪
    g_sensor_cfg[0].flicker_freq = 1;// mcp 和低功耗区分
    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    // 通道初始默认编码
    g_audia_cfg.audio_lq_encode_type = dev_cfg->astream_cfg[0].lq_encode_type;
    // g_audia_cfg.audio_lq_encode_type = DUA_AUDIO_G711U_TYPE;

    // 喇叭百分比音量参数
    spk_vol = 70; //mcp
    g_audia_cfg.speaker_volume = dev_cfg->spk_cfg.digital_vol * spk_vol / 100;

    g_audia_cfg.mic_enable = 1;
    // 麦克风百分比音量参数
    mic_vol = 100; //mcp
    g_audia_cfg.mic_volume = dev_cfg->mic_cfg.digital_vol * mic_vol / 100;

    //日夜
    g_sensor_cfg[0].daynight_mode = DUA_DAYNIGHT_MODE_NONE;


    memset(&g_audia_cfg, 0, sizeof(DUA_MEDIA_AUDIO_INIT_CFG_T));

    if (access("/mnt/mmc01/unit_test/", F_OK) != 0) {
        system("mkdir /mnt/mmc01/unit_test");
    }

    if (access(FUNC_UNIT_TEST_SNAPSHOT_PATH, F_OK) != 0) {
        system("mkdir /mnt/mmc01/unit_test/snapshot_test");
    }

    if (access(FUNC_UNIT_TEST_FPS_TEST_PATH, F_OK) != 0) {
        system("mkdir /mnt/mmc01/unit_test/fps_test");
    }

    if (access(FUNC_UNIT_TEST_QR_TEST_PATH, F_OK) != 0) {
        system("mkdir /mnt/mmc01/unit_test/qrcode_test");
    }

    // g_sensor_cfg.is_avproc_use_model = 1;
    // g_sensor_cfg.sub_stream_quality = DUA_MEDIA_VIDEO_QUALITY_LEVEL_5;
    // g_sensor_cfg.main_stream_quality = DUA_MEDIA_VIDEO_QUALITY_LEVEL_5;
     PPS_INFO("-------------------media init------------------------\n");
    g_media_cfg.mediacfg = dev_cfg->ppsmedia_cfg;

    ret = dua_media_init(dua_handler, &g_media_cfg, &g_audia_cfg, g_sensor_cfg, 1);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    g_sub_fpsFile = fopen("/mnt/mmc01/sub_stream_fps.hevc", "ab");
    g_main_fpsFile = fopen("/mnt/mmc01/main_stream_fps.hevc", "ab");

    media_avstream_test_module(dua_handler);

    sleep(3);

    media_osd_test();

    return PPS_TEST_SUCCESS;
}

pps_s32 media_deinit_test_module(pps_void *dua_handler)
{
    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    dua_media_deinit(dua_handler);
    // if (ret != 0) {
    //     PPS_ERROR("func[%s] dua media deinit failure!\n", __func__);
    //     return PPS_TEST_FAILURE;
    // }
    fclose(g_sub_fpsFile);
    g_sub_fpsFile = NULL;

    return PPS_TEST_SUCCESS;
}

pps_s32 media_osd_test(pps_void)
{
    const char str1[] = "1A2B3C4D5E";
    const char str2[] = "xxx!";

    int enabled = 0;
    DUA_OSD_CONFIG_T cfgMain;
    dua_media_get_osd_configuration(DUA_VIDEO_MAIN_STREAM_CHANNEL, &cfgMain, &enabled); // returns 0

    memset(cfgMain.time_osd_prefix, '\0', sizeof(cfgMain.time_osd_prefix));
    memset(cfgMain.time_osd_suffix, '\0', sizeof(cfgMain.time_osd_suffix));

    strcpy(cfgMain.time_osd_prefix, str1);
    strcpy(cfgMain.time_osd_suffix, str1);

    dua_media_osd_enable(DUA_VIDEO_MAIN_STREAM_CHANNEL, 0); // returns 0
    dua_media_configure_osd(DUA_VIDEO_MAIN_STREAM_CHANNEL, &cfgMain); // returns 0
    dua_media_osd_enable(DUA_VIDEO_MAIN_STREAM_CHANNEL, 1); // returns 0

    sleep(10);

    dua_media_get_osd_configuration(DUA_VIDEO_MAIN_STREAM_CHANNEL, &cfgMain, &enabled); // returns 0
    PPS_WARN("cfgMain.time_osd_prefix [%s], cfgMain.time_osd_suffix[%s]", cfgMain.time_osd_prefix, cfgMain.time_osd_suffix);

    memset(cfgMain.time_osd_prefix, '\0', sizeof(cfgMain.time_osd_prefix));
    memset(cfgMain.time_osd_suffix, '\0', sizeof(cfgMain.time_osd_suffix));

    strcpy(cfgMain.time_osd_prefix, str2);
    strcpy(cfgMain.time_osd_suffix, str2);

    dua_media_osd_enable(DUA_VIDEO_MAIN_STREAM_CHANNEL, 0); // returns 0

    sleep(5);
    dua_media_configure_osd(DUA_VIDEO_MAIN_STREAM_CHANNEL, &cfgMain); // returns 0
    dua_media_osd_enable(DUA_VIDEO_MAIN_STREAM_CHANNEL, 1); // returns 0

    dua_media_get_osd_configuration(DUA_VIDEO_MAIN_STREAM_CHANNEL, &cfgMain, &enabled); // returns 0
    PPS_WARN("cfgMain.time_osd_prefix [%s], cfgMain.time_osd_suffix[%s]", cfgMain.time_osd_prefix, cfgMain.time_osd_suffix);

    return 0;
}

pps_s32 media_main_stream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len)
{
    static pps_s32 s_frame_count = 0;
    static pps_u32 s_prev_timestamp = 0;

    if ((header->media_format != 0x01) && (header->media_format != 0x04)) {
        PPS_ERROR("media sub_stream format is not correct\n");
        return -1;
    }

    if (s_frame_count == 0) {
        s_prev_timestamp = header->timestamp;
    }

    s_frame_count++;


    if (g_main_fpsFile == NULL) {
        PPS_ERROR("func[%s] open sub_stream_fps_err failed\n", __func__);
        return -1;
    }

    if (fseek(g_main_fpsFile, 0, SEEK_END) != 0) {
        fclose(g_main_fpsFile);
        return -1;
    }

    fwrite(data, 1, header->size, g_main_fpsFile);

    PPS_ERROR("###write frame [%d],len [%d]\n",header->seq,header->size);

    if (header->timestamp - s_prev_timestamp < 0) {
        s_frame_count = 0;
    }

    return 0;
}

pps_s32 media_sub_stream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len)
{
    static pps_s32 s_frame_count = 0;
    static pps_u32 s_prev_timestamp = 0;

    if ((header->media_format != 0x01) && (header->media_format != 0x04)) {
        PPS_ERROR("media sub_stream format is not correct\n");
        return -1;
    }

    if (s_frame_count == 0) {
        s_prev_timestamp = header->timestamp;
    }

    s_frame_count++;

    // if (header->timestamp - s_prev_timestamp <= 5000) {

        if (g_sub_fpsFile == NULL) {
            PPS_ERROR("func[%s] open sub_stream_fps_err failed\n", __func__);
            return -1;
        }

        if (fseek(g_sub_fpsFile, 0, SEEK_END) != 0) {
            fclose(g_sub_fpsFile);
            return -1;
        }

        fwrite(data, 1, header->size, g_sub_fpsFile);

        PPS_ERROR("###write frame [%d],len [%d]\n",header->seq,header->size);
    // }

    if (header->timestamp - s_prev_timestamp < 0) {
        s_frame_count = 0;
    }

    return 0;
}

pps_s32 media_snapshot(pps_char *path)
{
    pps_char *snapshot_buffer = NULL;
    pps_s32 snapshot_len = 0;
    pps_s32 ret = -1;
    FILE *pFile = NULL;
    snapshot_buffer = (pps_char *)pps_malloc(256 * 1024);

    if (NULL == path) {
        PPS_ERROR("func[%s] path is NULL!\n", __func__);
        return -1;
    }

    if (NULL == snapshot_buffer) {
        PPS_ERROR("func[%s] malloc snapshot_buffer failed !\n", __func__);
        return -1;
    }

    snapshot_len = 256 * 1024;
    memset(snapshot_buffer, 0, snapshot_len);
    ret = dua_media_video_snapshot(DUA_SENSOR_FIRST, 0, snapshot_buffer, &snapshot_len);
    if (ret != 0) {
        PPS_ERROR("func[%s] snapshot failed !\n", __func__);
        return -1;
    }

    pFile = fopen(path, "w+");

    if (pFile == NULL) {
        PPS_ERROR("func[%s] open snapshot.jpg failed\n", __func__);
        return -1;
    }

    fwrite(snapshot_buffer, snapshot_len, 1, pFile);
    if (snapshot_buffer) {
        pps_free(snapshot_buffer);
        snapshot_buffer = NULL;
    }

    fclose(pFile);
    pFile = NULL;

    return 0;
}

pps_s32 media_fps_test_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;
    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_video_set_frame_rate(DUA_VIDEO_MAIN_STREAM_CHANNEL, 15);
    if (ret != 0) {
        PPS_ERROR("func[%s] media_video_set_frame_rate failed !\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_video_set_frame_rate(DUA_VIDEO_SUB_STREAM_CHANNEL, 15);
    if (ret != 0) {
        PPS_ERROR("func[%s] media_video_set_frame_rate failed !\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}


pps_s32 media_avstream_cb(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, void *data, pps_s32 len)
{
    return 0;
}

pps_s32 media_avstream_test_module(pps_void *dua_handler)
{
    PPS_ERROR("11111111\n");
    pps_s32 ret = -1;
    DUA_VIDEO_STREAM_INFO_T main_stream_info = {0};
    DUA_VIDEO_STREAM_INFO_T sub_stream_info = {0};

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }
     //set resolution
    // ret = dua_media_video_set_resolution( DUA_VIDEO_MAIN_STREAM_CHANNEL, DUA_VIDEO_SUB_RESOLUTION_1280_720);
    // if (ret != 0) {
    //     PPS_ERROR("func[%s] dua media video set encode failure!\n", __func__);
    //     return PPS_TEST_FAILURE;
    // }

    // ret = dua_media_set_video_compression_mode(DUA_VIDEO_MAIN_STREAM_CHANNEL,DUA_VIDEO_CBR_TYPE);
    // PPS_ERROR("compression_mode:%d\n",ret);
    // ret = dua_media_set_video_compression_mode(DUA_VIDEO_MAIN_STREAM_CHANNEL,DUA_VIDEO_VBR_TYPE);
    // PPS_ERROR("compression_mode:%d\n",ret);

    // //set encode type
    // ret = dua_media_video_set_encode_type(DUA_VIDEO_MAIN_STREAM_CHANNEL,DUA_VIDEO_H264_TYPE);
    // if (ret != 0) {
    //     PPS_ERROR("func[%s] dua media video set encode failure!\n", __func__);
    //     return PPS_TEST_FAILURE;
    // }


    ret = dua_media_register_avstream(DUA_VIDEO_MAIN_STREAM_CHANNEL, media_main_stream_cb, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_register_avstream(DUA_VIDEO_SUB_STREAM_CHANNEL, media_sub_stream_cb, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_register_avstream(DUA_AUDIO_G711U_STREAM_CHANNEL, media_avstream_cb, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_register_avstream(DUA_AUDIO_PCM_STREAM_CHANNEL, media_avstream_cb, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_register_avstream(DUA_AUDIO_AAC_STREAM_CHANNEL, media_avstream_cb, NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media register avstream failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_video_get_stream_info(DUA_VIDEO_MAIN_STREAM_CHANNEL, &main_stream_info);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media video get stream info failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    PPS_INFO(
      "bitrate [%d], bitrate_type [%d], encode_type [%d], fps [%d], height [%d] width [%d] image[%d] quality [%d] ret "
      "[%d]\n",
      main_stream_info.bitrate,
      main_stream_info.bitrate_type,
      main_stream_info.encode_type,
      main_stream_info.fps,
      main_stream_info.height,
      main_stream_info.width,
      main_stream_info.image.brightness,
      main_stream_info.quality);

    ret = dua_media_video_get_stream_info(DUA_VIDEO_SUB_STREAM_CHANNEL, &sub_stream_info);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media video get stream info failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    PPS_INFO(
      "bitrate [%d], bitrate_type [%d], encode_type [%d], fps [%d], height [%d] width [%d] image[%d] quality [%d] ret "
      "[%d]\n",
      sub_stream_info.bitrate,
      sub_stream_info.bitrate_type,
      sub_stream_info.encode_type,
      sub_stream_info.fps,
      sub_stream_info.height,
      sub_stream_info.width,
      sub_stream_info.image.brightness,
      sub_stream_info.quality);

    return PPS_TEST_SUCCESS;
}

pps_s32 media_snapday_test_module(pps_void *dua_handler)
{
    pps_s32 ret = -1;
    pps_char path_day[128] = "/mnt/mmc01/unit_test/snapshot_test/day.jpg";
    pps_char path_night[128] = "/mnt/mmc01/unit_test/snapshot_test/night.jpg";

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_set_daynight_mode(DUA_SENSOR_FIRST, DUA_DAYNIGHT_MODE_DAY);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media set daynight_mode failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = media_snapshot(path_day);
    if (ret != 0) {
        PPS_ERROR("func[%s] media_snapshot failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_set_daynight_mode(DUA_SENSOR_FIRST, DUA_DAYNIGHT_MODE_NIGHT);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media set daynight_mode failure failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = media_snapshot(path_night);
    if (ret != 0) {
        PPS_ERROR("func[%s] media_snapshot failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    ret = dua_media_set_daynight_mode(DUA_SENSOR_FIRST, DUA_DAYNIGHT_MODE_AUTO);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua media set daynight_mode failure failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}

pps_void qrcode_get_result_cb(pps_char *data, pps_u32 len)
{
    pps_s32 ret = -1;
    pps_char qr_err[256] = {0};
    FILE *qrFile = NULL;

    // 比较二维码扫描结果
    if (memcmp(g_qr_result, data, sizeof(g_qr_result)) != 0) {
        PPS_ERROR("func[%s] qrcode result is not correct!\n", __func__);
        snprintf(qr_err, sizeof(qr_err), "qrcode_result is not correct, the result is [%s]", data);
        qrFile = fopen("/mnt/mmc01/unit_test/qrcode_test/qrcode_result.txt", "a+");

        if (qrFile == NULL) {
            PPS_ERROR("func[%s] open qrcode_result.txt failed\n", __func__);
        }

        fwrite(qr_err, sizeof(qr_err), 1, qrFile);
        fclose(qrFile);
        qrFile = NULL;
    }

    ret = dua_qrcode_scanner_enable(0);
    if (ret != 0) {
        PPS_ERROR("func[%s] media qrcode scanner enable failure!\n", __func__);
    }

    return;
}

pps_s32 qrcode_test_module(pps_void *dua_handler, pps_char *qr_result)
{
    pps_s32 ret = -1;

    if (qr_result == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    memcpy(g_qr_result, qr_result, sizeof(g_qr_result));

    dua_register_qrcode_data_process_cb(dua_handler, qrcode_get_result_cb);

    ret = dua_qrcode_scanner_enable(1);
    if (ret != 0) {
        PPS_ERROR("func[%s] qrcode scanner enable failure failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }

    return PPS_TEST_SUCCESS;
}
\
pps_s32 playback_test_module(pps_void)
{
    pps_s32 ret = -1;
    pps_void *dua_handler = NULL;

    dua_handler = dua_init(NULL);
    if (dua_handler == NULL) {
        printf("func[%s] dua_init failed!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    printf("----------------- dua_init succeed ! --------------------\n");

    DUA_MEDIA_INIT_CFG_T media_cfg;
    pps_s32 spk_vol = 0, mic_vol = 0;
    DUA_MEDIA_AUDIO_INIT_CFG_T audio_cfg;
    DUA_MEDIA_SENSOR_INIT_CFG_T sensor_cfg[DUA_SENSOR_MAX];

    DUA_DEVICE_CFG_PTR dev_cfg = NULL;
    DUA_CAPABILITY_PTR dua_capa = NULL;
    pps_s32 is_mirror = 0, is_flip = 0;
    pps_s32 retval = 0;


    memset(&media_cfg, 0, sizeof(media_cfg));
    memset(&sensor_cfg[DUA_SENSOR_FIRST], 0, sizeof(DUA_MEDIA_SENSOR_INIT_CFG_T));
    memset(&sensor_cfg[DUA_SENSOR_SECOND], 0, sizeof(DUA_MEDIA_SENSOR_INIT_CFG_T));
    memset(&audio_cfg, 0, sizeof(audio_cfg));

    if (dua_handler == NULL) {
        PPS_ERROR("func[%s] invalid param!\n", __func__);
        return PPS_ERR_INVALARG;
    }

    dua_dev_config_read(dua_handler, &dev_cfg);

    // set photoresistor threshold
    dua_capa = dua_get_device_capacity(dua_handler);
    if (dua_capa->support_lum) {
        retval = dua_sensor_set_photoresistor_value(
          dua_handler, dua_capa->support_lum, dev_cfg->media_cfg.lum_max, dev_cfg->media_cfg.lum_min);
        if (retval) {
            PPS_ERROR("set photoresistor fail: %d\n", retval);
        }

        media_cfg.lum_threshold = dev_cfg->media_cfg.lum_value;
        media_cfg.ldr_max = dev_cfg->media_cfg.lum_max;
        media_cfg.ldr_min = dev_cfg->media_cfg.lum_min;
    }

    media_cfg.mediacfg = dev_cfg->ppsmedia_cfg;

    // use av mode
    sensor_cfg[DUA_SENSOR_FIRST].is_avproc_use_model = 1;
    sensor_cfg[DUA_SENSOR_SECOND].is_avproc_use_model = 1;

    // encode type
    sensor_cfg[DUA_SENSOR_FIRST].main_stream_encode_type
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.encode_type;
    sensor_cfg[DUA_SENSOR_FIRST].sub_stream_encode_type
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.encode_type;

    sensor_cfg[DUA_SENSOR_SECOND].main_stream_encode_type
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.encode_type;
    sensor_cfg[DUA_SENSOR_SECOND].sub_stream_encode_type
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.encode_type;

    //fps set
    sensor_cfg[DUA_SENSOR_FIRST].main_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.fps;
    sensor_cfg[DUA_SENSOR_FIRST].sub_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.fps;

    sensor_cfg[DUA_SENSOR_SECOND].main_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.fps;
    sensor_cfg[DUA_SENSOR_SECOND].sub_stream_fps = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.fps;

    //bitrate
    sensor_cfg[DUA_SENSOR_FIRST].main_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.bitrate;
    sensor_cfg[DUA_SENSOR_SECOND].main_stream_bitrate = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.bitrate;

    // img quality
    sensor_cfg[DUA_SENSOR_FIRST].main_stream_quality
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.img_quality;
    sensor_cfg[DUA_SENSOR_FIRST].sub_stream_quality
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.img_quality;

    sensor_cfg[DUA_SENSOR_SECOND].main_stream_quality
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].main_stream_cfg.img_quality;
    sensor_cfg[DUA_SENSOR_SECOND].sub_stream_quality
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_1].sub_stream_cfg.img_quality;

    //flip
    sensor_cfg[DUA_SENSOR_FIRST].flip_mirror_param.is_flip
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].is_flip ^ is_flip;
    sensor_cfg[DUA_SENSOR_FIRST].flip_mirror_param.is_mirror
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].is_mirror ^ is_mirror;

    //daynight mode
    sensor_cfg[DUA_SENSOR_FIRST].daynight_mode = DUA_DAYNIGHT_MODE_DAY;
    sensor_cfg[DUA_SENSOR_SECOND].daynight_mode = DUA_DAYNIGHT_MODE_DAY;
    sensor_cfg[DUA_SENSOR_FIRST].daynight_mode_proc = DUA_DAYNIGHT_MODE_PROC_AUTO;
    sensor_cfg[DUA_SENSOR_SECOND].daynight_mode_proc = DUA_DAYNIGHT_MODE_PROC_AUTO;

    // Anti-screen flicker
    sensor_cfg[DUA_SENSOR_FIRST].flicker_freq = DUA_MEDIA_ANTIFLICKER_MODE_AUTO;
    sensor_cfg[DUA_SENSOR_SECOND].flicker_freq = DUA_MEDIA_ANTIFLICKER_MODE_AUTO;

    //audio type
    audio_cfg.audio_lq_encode_type = DUA_AUDIO_G711U_TYPE;

    // Horn volume
    spk_vol = 100;
    audio_cfg.speaker_volume = dev_cfg->spk_cfg.digital_vol * spk_vol / 100;

    // mic volume
    audio_cfg.mic_enable = 1;
    mic_vol = 100;
    audio_cfg.mic_volume = dev_cfg->mic_cfg.digital_vol * mic_vol / 100;

    // OSD position
    sensor_cfg[DUA_SENSOR_FIRST].main_osd_cfg.time_osd_x_pos
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.osd_x;
    sensor_cfg[DUA_SENSOR_FIRST].main_osd_cfg.time_osd_y_pos
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].main_stream_cfg.osd_y;

    // osd mode
    sensor_cfg[DUA_SENSOR_FIRST].main_osd_cfg.time_osd_format = DUA_OSD_YYYY_MM_DD_24HOURS;
    sensor_cfg[DUA_SENSOR_FIRST].sub_osd_cfg.time_osd_format = DUA_OSD_YYYY_MM_DD_24HOURS;
    sensor_cfg[DUA_SENSOR_FIRST].sub_osd_cfg.time_osd_x_pos
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.osd_x;
    sensor_cfg[DUA_SENSOR_FIRST].sub_osd_cfg.time_osd_y_pos
      = dev_cfg->sensor_cfg[DUA_DEV_CFG_SENSOR_0].sub_stream_cfg.osd_y;

   // Appeler la fonction dua_media_init en utilisant init_cfg
    PPS_INFO("-------------------media init------------------------\n");
    retval = dua_media_init(dua_handler, &media_cfg,&audio_cfg,sensor_cfg, 1);
    if (retval != PPS_ERR_SUCCESS) {
        PPS_ERROR("media init fail: %d\n", retval);
        return PPS_ERR_FAIL;
    }


    FILE *fp = NULL;
    pps_s32 session_id = -1;
    pps_char *playback_buf = NULL;
    DUA_RECORD_TIME_T date_time = {0};
    DUA_PLAYBACK_AVFRAME_T p_avframe;
    pps_s32 max_frame_size = 512 * 1024;


    ret = dua_sdcard_init(dua_handler, "mnt/");
    if (ret != 0) {
        PPS_ERROR("func[%s] dua sdcard init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
            printf("dua_sdcard_init OK!\n");
    //modif Meari

    ret = dua_recorder_init(dua_handler, "mnt/", "test-56565032", NULL);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua recorder init failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
            printf("dua_recorder_init OK!\n");



    date_time.year = 2024;
    date_time.month = 05;
    date_time.day = 28;
    date_time.hour = 16;
    date_time.min = 42;
    date_time.sec = 0;
    printf("Date and Time: %04d-%02d-%02d %02d:%02d:%02d\n",
           date_time.year, date_time.month, date_time.day,
           date_time.hour, date_time.min, date_time.sec);

    // Note that the recording module needs to be initialized first
   ret = dua_playback_start(NULL, &session_id, date_time);
    if (ret != 0) {
        PPS_ERROR("func[%s] dua playback start failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
            printf("dua_playback_start OK!%d\n",session_id);

    fp = fopen("/mnt/mmc01/test.h264", "w+");
    if (fp == NULL) {
        PPS_ERROR("open /mnt/test.h264 failed\n");
        return PPS_TEST_FAILURE;
    }

            printf("after fopen OK!\n");

    // memset(&p_avframe, 0, sizeof(DUA_PLAYBACK_AVFRAME_T));

    playback_buf = calloc(1, max_frame_size);
    if (playback_buf == NULL) {
        PPS_ERROR("malloc playback buffer failed\n", strerror(errno));
        return PPS_TEST_FAILURE;
    }
                printf("after calloc OK!\n");

    p_avframe.buf = playback_buf;
    p_avframe.buffer_size = max_frame_size;
    while (1) {
                      printf("start while OK!\n");

        p_avframe.buffer_size = max_frame_size;
        // memset(p_avframe.buf, 0, sizeof(max_frame_size));
        if (PPS_ERR_SUCCESS != dua_playback_get_avframe(NULL, session_id, &p_avframe)) {
            PPS_ERROR("func[%s] dua_playback_get_avframe failure!\n", __func__);
            break;
        }
        if (p_avframe.avtype == MCP_RECORD_AVTYPE_VIDEO) {
            PPS_ERROR("1111111111\n");
            fwrite(p_avframe.buf, p_avframe.size, 1 , fp);
        }
    }
                    printf("after while 1 OK!\n");


    if (fp) {
        fclose(fp);
    }
                    printf("after close fp OK!\n");


    if (p_avframe.buf) {
        pps_free(p_avframe.buf);
    }

    PPS_INFO("get record 2024-05-20/15:00:00 done!\n");

    ret = dua_playback_stop(NULL, session_id);
    if (ret != 0) {
        printf("func[%s] dua_playback_stop failure!\n", __func__);
        return PPS_TEST_FAILURE;
    }
    printf("dua_playback_stop OK!\n");


    return PPS_TEST_SUCCESS;
}
