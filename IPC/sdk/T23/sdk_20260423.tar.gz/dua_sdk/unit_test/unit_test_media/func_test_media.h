/**
 * @file        media_test.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      lihao
 *
 * @date        2023/04/10
 *
 * @version     1.0.0
 *
 * @note
 */

#ifndef __FUNC_TEST_MEDIA_H
#define __FUNC_TEST_MEDIA_H

#ifdef __cplusplus
extern "C" {
#endif

#include "dua_media.h"
#include "dua_avproc.h"
#include "pps_osal_log.h"
#include "pps_osal_type.h"

#define USR_MEDIA_USR_S00_FLIP        "UsrS00Flip"
#define USR_MEDIA_USR_S00_MIRROR      "UsrS00Mirror" //(IPC/LPC)
#define USR_MEDIA_USR_S01_FLIP        "UsrS01Flip"   //(IPC/LPC)
#define USR_MEDIA_USR_S01_MIRROR      "UsrS01Mirror" //(IPC/LPC)
#define USR_MEDIA_ANTIFLICKER_MODE    "AntiFMode"    //(IPC/LPC) 防闪烁模式

#define USR_OSD_S00_FORMAT "OsdS00Format" //(IPC/LPC) 时间 osd 格式
#define USR_OSD_S01_FORMAT "OsdS01Format"

/** @fn    pps_s32 media_init_test(pps_void *dua_handler);
 * @brief   <media_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 media_init_test_module(pps_void *dua_handler);

/** @fn      pps_s32 media_deinit_test(pps_void *dua_handler);
 * @brief   <media_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 media_deinit_test_module(pps_void *dua_handler);

/** @fn      pps_s32 media_avstream_test_module(pps_void *dua_handler);
 * @brief   <media_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 media_avstream_test_module(pps_void *dua_handler);

/** @fn      pps_s32 media_snapday_test_module(pps_void *dua_handler);
 * @brief   <media_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 media_snapday_test_module(pps_void *dua_handler);

/** @fn      pps_s32 qrcode_test_module(pps_char *qr_result);
 * @brief   <media_test>
 * @param   [in] qr_result : 二维码内容
 * @return  1 - success | 0 - failure
 */
pps_s32 qrcode_test_module(pps_void *dua_handler, pps_char *qr_result);

/** @fn      pps_s32 media_fps_test_module(pps_void *dua_handler);
 * @brief   <media_test>
 * @param   [in] dua_handler : dua 句柄
 * @return  1 - success | 0 - failure
 */
pps_s32 media_fps_test_module(pps_void *dua_handler);
pps_s32 playback_test_module(pps_void);


#ifdef __cplusplus
}
#endif
#endif /* __PEOPLE_DETECT_TEST_H */
