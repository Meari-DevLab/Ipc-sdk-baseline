ifeq ($(DUA_PLATFORM), ingenic_t23n)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/t23/mips-gcc540-glibc222-64bit-r3.3.0.smaller/bin/mips-linux-gnu-
DUA_MEDIA_DIR=media_T23N
DUA_MEDIA_SRC=media_5xx.c
else ifeq ($(DUA_PLATFORM), ingenic_t40)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/t40/mips-linux-gnu-ingenic-gcc7.2.0-glibc2.29-fp64/bin/mips-linux-gnu-
DUA_MEDIA_DIR=media_T40N
DUA_MEDIA_SRC=media_5xx.c
else ifeq ($(DUA_PLATFORM), ingenic_t41)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/t41/mips-linux-gnu-ingenic-gcc7.2.0-glibc2.29-fp64-r5.1.8/bin/mips-linux-gnu-
DUA_MEDIA_DIR=media_T41L
DUA_MEDIA_SRC=media_t41.c
else ifeq ($(DUA_PLATFORM), ingenic_t41lq)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/t41/mips-linux-gnu-ingenic-gcc7.2.0-glibc2.29-fp64-r5.1.8/bin/mips-linux-gnu-
DUA_MEDIA_DIR=media_T41LQ
DUA_MEDIA_SRC=media_t41.c
else ifeq ($(DUA_PLATFORM), ingenic_t41nq)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/t41/mips-linux-gnu-ingenic-gcc7.2.0-glibc2.29-fp64-r5.1.8/bin/mips-linux-gnu-
DUA_MEDIA_DIR=media_T41NQ
DUA_MEDIA_SRC=media_t41.c
else ifeq ($(DUA_PLATFORM), ingenic_t31)
DUA_CROSS_COMPILE:=/opt/toolchains/ingenic/mips-gcc472-glibc216-64bit/bin/mips-linux-uclibc-gnu-
DUA_MEDIA_DIR=media_T31LC
DUA_MEDIA_SRC=media.c
else ifeq ($(DUA_PLATFORM), anyka_100N)
DUA_CROSS_COMPILE:=/opt/toolchains/anyka/anycloud39av100/arm-anycloud-linux-uclibcgnueabi/bin/arm-anycloud-linux-uclibcgnueabi-
DUA_MEDIA_DIR=media_AV100N
DUA_MEDIA_SRC=media_t41.c
endif