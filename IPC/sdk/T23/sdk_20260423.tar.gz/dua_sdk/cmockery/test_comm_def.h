/**
 * @file        comm_def.h
 * @copyright   2016-2022 Meari technology Co., Ltd
 * @brief       common definition
 * @author      Shi Yanlin
 * @date        2022/03/15
 * @version     1.0.0
 * @note
 */
#ifndef _COMM_DEF_H_
#define _COMM_DEF_H_

#ifdef __cplusplus
extern "C" {
#endif
#include <pthread.h>

#define API_TEST_FREQ 100
typedef enum error_code {
    PPS_TEST_SUCCESS = 1,
    PPS_TEST_FAILURE = 0,
} error_code_e;

typedef struct mutex_cond {
    pthread_condattr_t cattr;
    pthread_mutex_t    mutex;
    pthread_cond_t     cv;
    int                connect_sigevent;
} mutex_cond_t;

#ifdef __cplusplus
}
#endif
#endif /* _COMM_DEF_H_ */
