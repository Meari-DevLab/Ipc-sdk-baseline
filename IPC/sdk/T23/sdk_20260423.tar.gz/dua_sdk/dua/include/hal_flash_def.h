/**
 * @file        hal_flash_def.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      liping
 *
 * @date        2023/03/14
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __HAL_FLASH_DEF_H
#define __HAL_FLASH_DEF_H

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* hal flash type */

/*-----------------------------加密ID-------------------------------*/
#define PPS_SYSINFO_ID          0x1
#define PPS_MODEL_ID            0x2
#define PPS_DEVTYPE_ID          0x4
#define PPS_PRODDATE_ID         0x8
#define PPS_SN_ID               0x10
#define PPS_P2P_TYPE_ID         0x20
#define PPS_P2PID_ID            0x40
#define PPS_LICENSE_SWITCH_ID   0x80
#define PPS_LICENSE_TYPE_ID     0x100
#define PPS_LICENSE_ID          0x200
#define PPS_SECRET_ID           0x400
#define PPS_ETHMAC_ID           0x800
#define PPS_LENSINFO_ID         0x1000
#define PPS_LANGUAGE_ID         0x2000
#define PPS_DEVCLASS_ID         0x4000
#define PPS_OEM_CODE_ID         0x8000
#define PPS_ENCRYPT_VER_ID      0x10000
#define PPS_IDENTITY_ID         0x20000
#define PPS_OEM_ID              0x40000
#define PPS_TP_ID               0x80000
#define PPS_ZONE                0x100000
#define PPS_FREQ_POINT_ID       0x200000
#define PPS_BANDWIDTH_ID        0x400000
#define PPS_AUTH_LICENSE_LEN_ID 0x800000
#define PPS_AUTH_LICENSE_ID     0x1000000
#define PPS_CUSTOM_INFO         0x2000000
#define PPS_OPTICAL_CODE        0x4000000

#define PPS_ALL_ID         0xfffffff
#define PPS_EXCEPT_IDEN_ID 0x1ffff

#define PPS_ENCRYPT_FILE   "/mnt/mmc01/ppsEncrypt.txt"
#define PPS_ENCRYPTED_FILE "/mnt/mmc01/ppsEncrypted.txt"

/*-----------------------------------------------------------------------*/

#define PPS_ENCRYPT_FILE_MAX_COL 256

/*-----------------------------SD加密类型值-------------------------------*/
#define TUTK_STYLE         0
#define LICENSE_ONLY_STYLE 1
#define LICENSE_TUTK_STYLE 2
#define LICENSE_SY_STYLE   3
#define TUYA2_STYLE        4
#define IDENTITY_STYTLE    16

/*--------------------------------状态值----------------------------------*/
#define STATUS_OK      0
#define STATUS_IN_PROG 1
#define STATUS_ERR     -1
#define YES            1
#define NO             0

/*------------------------------------------------------------------------*/

#define min(a, b) a > b ? b : a


#define UPGRADE_PACKAGE_MCU     ("mcu.bin")
#define UPGRADE_PACKAGE         ("upgrade.bin")
#define UPGRADE_PACKAGE_APP     ("app.img")
#define UPGRADE_PACKAGE_UBOOT   ("u-boot.bin")
#define UPGRADE_PACKAGE_KERNEL  ("uImage")
#define UPGRADE_PACKAGE_ENCRYPT ("Encrypt.bin")
#define UPGRADE_PACKAGE_SYSFLAG ("sysflg")

#define PROC_MTD_PROC_FILE ("/proc/mtd")
#define PROC_MTD_FIRST     ("dev:    size   erasesize  name\n")
#define PROC_MTD_FIRST_LEN (sizeof(PROC_MTD_FIRST) - 1)
#define PROC_MTD_PATT      ("mtd%d: %llx %x")
#define PROC_MTD_MAX_LEN   (4096)
#define MTD_NAME_MAX       (128)
#define MTD_MAX_COUNT      (13)

#define ENC_BASE_MAGIC_NUM (0x5354524e) /* STRN */
#define ENC_EXT_MAGIC_NUM  (0x56565099) /* STRN */

/** @struct  hal_flash_demo_info
 * @brief   <设备加密信息(全)>
 * @note    所有数据块都多给4个字节
 *          总共 28 + 48 Bytes
 */
typedef struct hal_flash_demo_info {
    pps_u8 strSpareString[28]; // 28B   /*偏移28B，与之前保持一致*/
    pps_u8 civilCode[48];      // 48B   /* 民用产品唯一编号 ---  由20字节扩展到48字节*/
} HAL_FLASH_DEMO_INFO_T, *HAL_FLASH_FLASH_DEMO_INFO_PTR;

/** @struct  boot_params
 * @brief   <boot参数>
 * @note    总共 256 + 28 Bytes
 */
typedef struct hal_flash_boot_params {
    /* 0  */ pps_u32 magicNumber;  // 幻数
    /* 4  */ pps_u32 paraChecksum; // 检查和
    /* 8  */ pps_u32 paraLength;   // 结构长度  检查和、长度从'encryptVer'开始计算
    /* 12 */ pps_u32 encryptVer;   // 加密版本:用于控制此结构的更改
    /*
        以下4项用户升级控制:必须与升级文件包中的内容一致
    */
    /* 16 */ pps_u32               language;            // 支持语言  1--EN 2--CN
    /* 20 */ pps_u32               deviceClass;         // 产品类型，1--NVR, 2--IPC
    /* 24 */ pps_u32               oemCode;             // oem代码： 1--代表原厂自己
    /* 28 */ pps_u8                reservedFeature[16]; // 保留产品特性，用于升级控制
    /* 44 */ pps_u16               encodeChans;         // 编码路数
    /* 46 */ pps_u16               decodeChans;         // 解码路数
    /* 48 */ pps_u8                irisType;            // 光圈类型，0：自动，1：手动
    /* 50 */ pps_u8                res4[3];
    /* 52 */ pps_u8                alarminNum;         // 报警输入个数0,1,2,3,4,5,6,7,8
    /* 53 */ pps_u8                macAddr[2][6];      // 设备MAC地址
    /* 65 */ pps_u8                prodDate[8];        // 设备生产日期,ASCII
    /* 73 */ pps_u8                prodNo[9];          // 设备序列号
    /* 82 */ pps_u8                defVideoStandard;   // 默认输出制式
    /* 83 */ pps_u8                cpuFreq;            // CPU频率 1=229M|2=300M|3=337M|4=364M|5=450M|6=500M
    /* 84 */ pps_u8                dspFreq;            // DSP频率 1=459M|2=600M|3=675M|4=729M|5=900M|6=1G
    /* 85 */ pps_u8                zone;               // 销售地区
    /* 86 */ pps_u8                audioInSupport;     // 支持音频输入
    /* 87 */ pps_u8                sensorType;         // 支持sensor类型
    /* 88 */ pps_u8                usbNums;            // USB个数
    /* 89 */ pps_u8                resetSupport;       // 支持reset
    /* 90 */ pps_u8                alarmoutNums;       // 报警输出: 0,1,2,3,4
    /* 91 */ pps_u8                sensorVersion;      // sensor板版本
    /* 92 */ pps_u8                audiooutSupport;    // 支持音频输出：0 -- 无，1--支持
    /* 93 */ pps_u8                videooutType;       // 视频输出类型：0 -- 无，1 -- CVBS，2 -- HDMI
    /* 94 */ pps_u8                videoinType;        // 视频输入类型 0 -- 9d131, 1-- 9d136,2 --656,
    /* 95 */ pps_u8                FPGAType;           // FPGA类型
    /* 96 */ pps_u8                HWVersion;          // FPGA板版本
    /* 97 */ pps_u8                IRSupport;          // 支持红外功能 0不支持；1支持
    /* 98 */ pps_u8                wifiSupport;        // 支持wifi功能 0不支持 1支持
    /* 99 */ pps_u8                eZoomLensSupport;   // 电可变镜头
    /*100 */ pps_u32               devType;            // 设备类型，4个字节 -- chg 2->4,160306
    /*104 */ pps_u32               ubootAdrs;          // uboot存放flash地址
    /*108 */ pps_u32               ubootSize;          // uboot大小
    /*112 */ pps_u32               ubootCheckSum;      // uboot校验值
    /*116 */ pps_u32               tinyKernelAdrs;     // tinyKernel存放flash地址
    /*120 */ pps_u32               tinyKernelSize;     // tinyKernel大小
    /*124 */ pps_u32               tinyKernelCheckSum; // tinyKernel校验值
    /*128 */ pps_u8                devModel[64];       // 产品型号:考虑国标型号，扩充到64字节
    /*192 */ pps_u8                writeDate[8];       // 设备信息更新日期,ASCII
    /*200 */ pps_u32               crypto;             // 是否加密过 1：是，0：否
    /*204 */ pps_u32               civil_campany_type; // test_ly:民用厂家定义:VVEYE-1， TUTK-2， PPSTRONG-3， DANALE-4
    /*208 */ HAL_FLASH_DEMO_INFO_T demo_info;          // sizeof(pps_boot_params_t) is 28 + 48 BYTEs
} HAL_FLASH_BOOT_PARAMS_T, *HAL_FLASH_BOOT_PARAMS_PTR;

/** @struct  product_info
 * @brief   <产品信息>
 * @note    总共 512 Bytes
 */
typedef struct hal_flash_product_info {
    HAL_FLASH_BOOT_PARAMS_T boot_params; // boot参数    /* 256 + 28 Bytes */
    pps_u32                 year;        // 当前时间：年、月、日、时、分、秒
    pps_u32                 month;
    pps_u32                 day;
    pps_u32                 hour;
    pps_u32                 minute;
    pps_u32                 second;
    pps_u32                 dayofweek;
    pps_u32                 dog_id;      // 设置人员的ID(加密狗的流水号)
    pps_u32                 formatFlash; // 0---不格式化，1---格式化
    pps_u32                 irewrite;    // 0---不重写，  1---重写
    pps_u8                  oem_uuid[64];
    pps_u8                  oem_authkey[64];
    pps_u32                 uuid_licence_switch; // use oem uuid or licence 0 --tuya uuid 1- meari licence and we do not use the p2p id in civilcode
    pps_u32                 licence_type;        // licence type //resv now
    pps_u8                  lens_info[32];
    pps_u8                  res[20];
} HAL_FLASH_PRODUCT_INFO_T, *HAL_FLASH_PRODUCT_INFO_PTR;

/** @struct  hal_flash_kernel_args
 * @brief   <kernel 参数信息>
 * @note    总共 1024 Bytes
 */
typedef struct hal_flash_kernel_args {
    pps_s32  magic;
    pps_s32  kernel_args_len;
    pps_char kernel_args[1016];
} HAL_FLASH_KERNEL_ARGS_T, *HAL_FLASH_KERNEL_ARGS_PTR;

/** @struct  hal_flash_other_info
 * @brief   <设备其他参数信息>
 * @note    总共 512 Bytes
 * @note    ### 原来常电的定义 ###
 */
typedef struct hal_flash_other_info {
    pps_char identity_card[32];
    pps_char tp[128];
    pps_u32  oem_id;
    pps_char band_width[5];
    pps_char freq_point[128];
    pps_char optical_code[64];
    pps_char res[150];
    pps_char version;
} HAL_FLASH_OTHER_INFO_T, *HAL_FLASH_OTHER_INFO_PTR;

/** @struct  hal_flash_other_info2
 * @brief   <设备其他参数信息>
 * @note    总共 512 Bytes
 * @note    ### 原来低功耗的定义 ###
 */
typedef struct hal_flash_other_info2 {
    pps_char identity_card[32];
    pps_char tp[128];
    pps_u32  oem_id;
    pps_char ssid[64];
    pps_char password[64];
    pps_char freq_range[64];
    pps_char bandwidth[8];
    pps_char res[144];
    pps_char version;
} HAL_FLASH_OTHER_INFO2_T, *HAL_FLASH_OTHER_INFO2_PTR;

/** @struct  hal_flash_base_enc_info
 * @brief   <加密分区的基础加密信息>
 * @note    总共 2048 Bytes
 *          ### 基础加密分区兼容了之前的常电和低功耗版本 ###
 */
typedef struct hal_flash_base_enc_info {
    HAL_FLASH_PRODUCT_INFO_T product_info; // 512
    HAL_FLASH_OTHER_INFO_T   other_info;   // 512
    HAL_FLASH_KERNEL_ARGS_T  kernel_args;  // 1024
} HAL_FLASH_BASE_ENC_INFO_T, *HAL_FLASH_BASE_ENC_INFO_PTR;

/** @struct  hal_flash_enc_ex1_info1
 * @brief   <拓展加密分区的信息1>
 * @note    总共 1024 Bytes
 */
typedef struct hal_flash_enc_ex1_info1 {
    pps_u32  magic_number;
    pps_char res[1020]; // 预留字段, 客户可自定义加密
} HAL_FLASH_ENC_EX1_INFO1_T, *HAL_FLASH_ENC_EX1_INFO1_PTR;

/** @struct  hal_flash_ex1_enc_info2
 * @brief   <拓展加密分区的信息2>
 * @note    总共 1024 Bytes
 */
typedef struct hal_flash_enc_ex1_info2 {
    pps_s32  enable;
    pps_s32  version;
    pps_s32  auth_license_len;
    pps_char res[116];
    pps_char license_enc[896];
} HAL_FLASH_ENC_EX1_INFO2_T, *HAL_FLASH_ENC_EX1_INFO2_PTR;

/** @struct  hal_flash_enc_info_ex1
 * @brief   <拓展加密分区1的加密信息>
 * @note    总共 6144 Bytes
 *          ### 拓展加密分区1 和常电的版本不再对齐 ###
 */
typedef struct hal_flash_enc_info_ex1 {
    HAL_FLASH_ENC_EX1_INFO1_T info1;
    HAL_FLASH_ENC_EX1_INFO2_T info2;
    pps_char                  res[4096]; // 预留字段, 客户可自定义加密
} HAL_FLASH_ENC_INFO_EX1_T, *HAL_FLASH_ENC_INFO_EX1_PTR;

typedef struct hal_flash_enc_ex2_info {
    pps_u32  magic_number;
    pps_s32  enable;
    pps_s32  version;
    pps_char res[116];
} HAL_FLASH_ENC_EX2_INFO_T, *HAL_FLASH_ENC_EX2_INFO_PTR;

/** @struct  hal_flash_enc_info_ex2
 * @brief   <拓展加密分区2的加密信息>
 * @note    总共 8192 Bytes
 *          ### 拓展加密分区2 和常电的版本不再对齐 ###
 */
typedef struct hal_flash_enc_info_ex2 {
    HAL_FLASH_ENC_EX2_INFO_T info1;
    pps_char                 res[8064]; // 预留字段, 客户可自定义加密
} HAL_FLASH_ENC_INFO_EX2_T, *HAL_FLASH_ENC_INFO_EX2_PTR;

typedef enum hal_flash_sysflg_err_code {
    HAL_FLASH_SYSFLG_ERR_NULL,
    HAL_FLASH_SYSFLG_ERR_FILE_NUMS,
    HAL_FLASH_SYSFLG_ERR_FILE_LEN,
    HAL_FLASH_SYSFLG_ERR_PLATFORM,
    HAL_FLASH_SYSFLG_ERR_MAGIC,
    HAL_FLASH_SYSFLG_ERR_PKG_CHECK,
    HAL_FLASH_SYSFLG_ERR_FILE_CHECK,
    HAL_FLASH_SYSFLG_ERR_FLASH_CHECK,
    HAL_FLASH_SYSFLG_ERR_FLASH_READ,
    HAL_FLASH_SYSFLG_ERR_FLASH_WRITE,
} HAL_FLASH_SYSFLG_ERR_CODE_E;

typedef struct hal_falsh_sysflg_info {
    pps_s32  magic;
    pps_s32  checksum;
    pps_s32  length;
    pps_s32  version;
    pps_s32  up_osx;
    pps_s32  up_flag;
    pps_s32  err_flag;
    pps_char res[36];
} HAL_FLASH_SYSFLG_INFO_T, *HAL_FLASH_SYSFLG_INFO_PTR;

typedef enum hal_flash_opt {
    HAL_FLASH_OPT_READ,
    HAL_FLASH_OPT_WRITE,
    HAL_FLASH_OPT_ERASE
} HAL_FLASH_OPT_E;

typedef struct hal_mtd_info {
    pps_char name[MTD_NAME_MAX];
    pps_s32  mtd_idx;
    pps_s64  size;
    pps_s32  eb_size;
} HAL_MTD_INFO_T, *HAL_MTD_INFO_PTR;

typedef pps_s32 (*hal_flash_spinor_erase_f)(pps_ulong start, pps_ulong size);
typedef pps_s32 (*hal_flash_spinor_write_f)(pps_void *memaddr, pps_ulong start, pps_ulong size);
typedef pps_s32 (*hal_flash_spinor_read_f)(pps_void *memaddr, pps_ulong start, pps_ulong size);

typedef struct hal_flash_ops {
    hal_flash_spinor_erase_f flash_spinor_erase;
    hal_flash_spinor_write_f flash_spinor_write;
    hal_flash_spinor_read_f  flash_spinor_read;
} HAL_FLASH_OPS_T, *HAL_FLASH_OPS_PTR;

typedef pps_s32 (*hal_flash_init_f)(pps_void);
typedef pps_s32 (*hal_flash_read_f)(pps_s32 mtd_index, pps_ulong offset, pps_char *data, pps_ulong data_len);
typedef pps_s32 (*hal_flash_write_f)(pps_s32 mtd_index, pps_ulong offset, pps_char *data, pps_ulong data_len);
typedef pps_s32 (*hal_flash_enc_read_f)(pps_s32 enc_block_idx, pps_char *enc_data, pps_ulong enc_data_len);
typedef pps_s32 (*hal_flash_enc_write_f)(pps_char *enc_data, pps_s32 enc_data_len,
                                         pps_char *enc_ex_data, pps_s32 enc_ex_data_len,
                                         pps_char *enc_ex2_data, pps_s32 enc_ex2_data_len);
typedef pps_s32 (*hal_flash_erase_f)(pps_s32 enc_mtd_index, pps_s32 offset, pps_ulong size);
typedef pps_s32 (*hal_flash_get_ops_f)(HAL_FLASH_OPS_PTR ops);
typedef pps_s32 (*hal_flash_get_bootparam_f)(pps_void *boot_param, pps_u32 size);
typedef pps_s32 (*hal_flash_get_partition_info_f)(pps_s32 osx, pps_char *filename, pps_ulong *base, pps_ulong *size, pps_s32 *mtd_index);
typedef pps_s32 (*hal_flash_encrypt_read_f)(pps_s32 enc_block_idx, pps_char *enc_data, pps_s32 enc_data_len);
typedef pps_s32 (*hal_flash_encrypt_write_f)(pps_char *enc_data, pps_s32 enc_data_len,
                                             pps_char *enc_ex_data, pps_s32 enc_ex_data_len,
                                             pps_char *enc_ex2_data, pps_s32 enc_ex2_data_len);
typedef pps_s32 (*hal_flash_encrypt_show_f)(pps_char *enc_data, pps_s32 enc_data_len);

typedef struct hal_flash_obj {
    hal_flash_init_f               flash_init;
    hal_flash_read_f               flash_read;
    hal_flash_write_f              flash_write;
    hal_flash_enc_read_f           flash_enc_read;
    hal_flash_enc_write_f          flash_enc_write;
    hal_flash_erase_f              flash_erase;
    hal_flash_get_ops_f            flash_get_ops;
    hal_flash_get_bootparam_f      flash_get_bootparam;
    hal_flash_get_partition_info_f flash_get_partition_info;
    hal_flash_encrypt_read_f       flash_encrypt_read;
    hal_flash_encrypt_write_f      flash_encrypt_write;
    hal_flash_encrypt_show_f       flash_encrypt_show;
} HAL_FLASH_OBJ_T, *HAL_FLASH_OBJ_PTR;

#ifdef __cplusplus
}
#endif
#endif /* __HAL_FLASH_DEF_H */
