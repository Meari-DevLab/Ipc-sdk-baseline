/**
 * @file        dua_product.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/07/05
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_PRODUCT_H_
#define _DUA_PRODUCT_H_

#include "pps_osal_type.h"
#include "dua_event_def.h"
#include "dua_product_def.h"
#include "dua_common.h"
#ifdef __cplusplus
extern "C" {
#endif


pps_s32 dua_product_init(pps_void *dua_handler);

pps_s32 dua_product_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

pps_s32 dua_product_is_factory_mode(pps_void);  //判断设备是否产测模式，进入或者退出产测都为TRUE

pps_void dua_product_callback(DUA_PRODUCT_CALLBACK_PTR callback);

pps_void dua_product_deinit();

#ifdef __cplusplus
}
#endif
#endif /* _DUA_PRODUCT_H_ */
