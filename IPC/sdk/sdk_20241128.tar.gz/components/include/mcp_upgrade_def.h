#ifndef _MCP_UPGRADE_DEF_H_
#define _MCP_UPGRADE_DEF_H_

#include "pps_osal.h"
#include "dua_firmware_header_def.h"

#ifdef __cplusplus
extern "C" {
#endif

#define FIRM_VER   "firm_ver"
#define SYS_VER    "sys_ver"
#define APP_VER    "app_ver"
#define DEVCFG_VER "devcfg_ver"

#ifdef DUA_CONFIG_BATTERY_DEVICE
#define ROOTFS_VER "rootfs_ver"
#define TAG_VER    "tag_ver"
#define MCU_VER    "mcu_ver"
#else
#define RESRC_VER  "resrc_ver"
#define SENSOR_VER "sensor_ver"
#endif

#define BOOT_UPGRADE_SIZE (0xc00000)

#ifdef DUA_CONFIG_BATTERY_DEVICE
    #define DEVICE_NEED_PACKAGE_NUM 7
#else
    #if defined(DUA_CONFIG_T40_SUPPORT) && defined(DUA_CONFIG_DUAL_SENSOR)
        #define DEVICE_NEED_PACKAGE_NUM 7
    #else
        #define DEVICE_NEED_PACKAGE_NUM 6
    #endif
#endif

// 升级包ID
typedef enum mcp_device_pack_type {
#ifdef DUA_CONFIG_BATTERY_DEVICE
    UBOOT_PACK  = 0,
    ROOTFS_PACK = 1,
    APP_PACK    = 2,
    UIMAGE_PACK,
    DEV_CFG_PACK,
    TAG_PACK,
    MCU_PACK,
#else
    UBOOT_PACK  = 0,
    UIMAGE_PACK = 1,
    APP_PACK    = 2,
    RESOURCE_PACK,
    DEV_CFG_PACK,
    SENSOR_PACK,
#if defined(DUA_CONFIG_T40_SUPPORT) && defined(DUA_CONFIG_DUAL_SENSOR)
    RECOVE_PACK,
#endif

#endif
} MCP_DEVICE_PACK_TYPE_E;

// 设备需要的升级包信息
typedef struct {
    MCP_DEVICE_PACK_TYPE_E pack_id;
    pps_char               pack_name[128];
} MCP_DEVICE_UPGRADE_PACKAGE_T;

// 定义链表节点
typedef struct mcp_upgrade_package {
    pps_s32                         pack_id;
    pps_void                       *pack_paddr;
    pps_s32                         pack_size;
    DEVICE_UPGRADE_FILE_HEADER_V2_T file_header;
    struct mcp_upgrade_package     *next_package;
} MCP_UPGRADE_PACKAGE_T;

// 设备升级进度信息
typedef struct {
    pps_u32 upfiles_size;       // 所有需要升级的升级包的大小
    pps_u32 write_percent_size; // 已经升级的升级包大小
    pps_u32 download_percent;   // 已经下载的进度
} MCP_UPGRADE_PERCENT_T;

// 小包固件版本信息
typedef struct {
    pps_s32  pack_id;
    pps_char file_ver[64];
} MCP_SUBPACKAGES_VERSION_T;

// 设备固件版本信息
typedef struct {
    pps_char                  firmware_ver[64]; // 升级包总版本
    MCP_SUBPACKAGES_VERSION_T subpackages_ver[DEVICE_NEED_PACKAGE_NUM];
} MCP_UPGRADE_PACKAGE_VERSION_T;

// 升级模块信息结构体
typedef struct mcp_upgrade_info {
    pps_s32 upgrading;        // 升级标志
    pps_s32 upgrade_offset;   // 下载偏移
    pps_s32 download_percent; // 下载进度
} MCP_UPGRADE_INFO_T, *MCP_UPGRADE_INFO_PTR;

// 偏移拷贝结构体
typedef struct {
    pps_s32 offset_start;
    pps_s32 offset_end;
    pps_s32 pack_bytes_size;
} COPY_SLICE_OFFSET;

typedef struct {
    pps_s32           copy_slice_size; // 进入数据的总大小
    pps_s32           offset_num;      // 需要的包的个数
    pps_s32           use_rmem_size;  // rmem数据偏移
    pps_s32           header_len;     //所有包头大小
    pps_s32           header_regroup_flag; //包头重组标志
    COPY_SLICE_OFFSET pack_offset_obj[16]; //需要的包的偏移
} UPGRADE_COPY_INFO;

typedef struct {
    pps_void       *context;
    pps_void       *rsa_context;
} UPGRADE_TYPE_INFO;


#ifdef __cplusplus
}
#endif
#endif /* _DUA_UPGRADE_DEF_H_ */
