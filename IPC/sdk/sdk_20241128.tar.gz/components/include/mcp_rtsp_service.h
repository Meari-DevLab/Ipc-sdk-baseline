/**
 * @file        mcp_rtsp_service.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       rtsp serivce
 * @author      Shi Yanlin
 * @date        2023/05/23
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_RTSP_SERVICE_H_
#define _MCP_RTSP_SERVICE_H_

#define DUA_CONFIG_MAX_DEVICE_PASSWORD_LEN 64

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn     pps_s32 mcp_rtsp_service_set_password(pps_char *password, pps_s32 password_len);
 * @brief  <get rtsp password>
 * @param  [in] password: password addr
 * @param  [in] password_len: password len
 *
 * @return 0 - succeed | -1 - fail
 */
pps_s32 mcp_rtsp_service_set_password(pps_char *password, pps_s32 password_len);

/** @fn     pps_s32 mcp_rtsp_service_get_password(pps_char *password, pps_s32 *password_len);
 * @brief  <get rtsp password>
 * @param  [out] password: password addr
 * @param  [out] password_len: password len
 * @return 0 - succeed | -1 - fail
 */
pps_s32 mcp_rtsp_service_get_password(pps_char *password, pps_s32 *password_len);

/** @fn     pps_void mcp_rtsp_service_set_enable(pps_s32 enable);
 * @brief  <set rtsp status>
 * @param  [in] enable: 1 - enable  | 0 - disable
 * @return
 */
pps_void mcp_rtsp_service_set_enable(pps_s32 enable);

/** @fn     pps_s32 mcp_rtsp_service_get_status(pps_void);
 * @brief  <get rtsp status>
 * @return 0 - disable | 1 - enable
 */
pps_s32 mcp_rtsp_service_get_status(pps_void);

/** @fn     pps_s32 mcp_rtsp_service_init(pps_void *dua_handler);
 * @brief  <rtsp service init>
 * @param  [in] dua_handler: dua handle
 * @return 0 - succeed | -1 - fail
 */
pps_s32 mcp_rtsp_service_init(pps_void *dua_handler);

/** @fn     pps_s32 mcp_rtsp_service_deinit(pps_void);
 * @brief  <rtsp service deinit>
 * @return 0 - succeed | -1 - fail
 */
pps_s32 mcp_rtsp_service_deinit(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_RTSP_SERVICE_H_ */
