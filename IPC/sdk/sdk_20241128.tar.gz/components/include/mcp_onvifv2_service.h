/**
 * @file        mcp_onvifv2_service.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       onvif service
 * @author      Shi Yanlin
 * @date        2023/05/23
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_ONVIFV2_SERVICE_H_
#define _MCP_ONVIFV2_SERVICE_H_

#include "dua_common.h"
#include "pps_osal_type.h"
#include "mcp_ptz_service_def.h"

// ptz goto
typedef pps_s32 (*mcp_onvif_ptz_plug_goto)(pps_void *ptz_serv_handler, pps_s32 target_p_position, pps_s32 target_t_position);
// ptz cmd
typedef pps_s32 (*mcp_onvif_ptz_plug_move)(pps_void *dua_handler, pps_void *ptz_handler, DUA_PTZ_MOVE_CTRL_CMD_E cmd);
// ptz get position
typedef pps_s32 (*mcp_onvif_ptz_coordinates)(MCP_PTZ_POSITION_T *ptz_position);

typedef struct mcp_onvif_ptz_plug {
    mcp_onvif_ptz_plug_goto   ptz_goto;
    mcp_onvif_ptz_plug_move   ptz_move;
    mcp_onvif_ptz_coordinates get_ptz_position;
} MCP_ONVIF_PTZ_PLUG_T;

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 mcp_onvif_service_init(pps_void *dua_handler);
 * @brief   <onvif init >
 * @param   [in] dua_handler: dua handler
 * @return   0 - success | else - failure
 */
pps_s32 mcp_onvif_service_init(pps_void *dua_handler, pps_void *ptz_handler, MCP_ONVIF_PTZ_PLUG_T *ptz_plug);

/** @fn      pps_s32 mcp_onvif_service_enable(pps_void);
 * @brief   <onvif enable >
 * @return   0 - success | else - failure
 */
pps_s32 mcp_onvif_service_enable(pps_void);

/** @fn      pps_s32 mcp_onvif_service_disable(pps_void);
 * @brief   <onvif disable >
 * @return   0 - success | else - failure
 */
pps_s32 mcp_onvif_service_disable(pps_void);

/** @fn      pps_s32 mcp_onvif_service_set_password(pps_char *passwd);
 * @brief   <set onvif password >
 * @param   [in] passwd: onvif password
 * @return   0 - success | else - failure
 */
pps_s32 mcp_onvif_service_set_password(pps_char *passwd);

/** @fn      pps_s32 mcp_onvif_service_get_onvif_service_port(pps_void);
 * @brief   <get onvif service port >
 * @return   port
 */
pps_s32 mcp_onvif_service_get_onvif_service_port(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_ONVIFV2_SERVICE_H_ */
