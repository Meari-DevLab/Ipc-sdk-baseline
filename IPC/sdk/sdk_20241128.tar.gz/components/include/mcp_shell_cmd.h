#ifndef _MCP_SHELL_CMD_H_
#define _MCP_SHELL_CMD_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pps_osal_type.h"

typedef struct shell_cmd_buf {
    pps_char *buf;
    pps_u32   len;
    pps_u32   end;
} SHELL_CMD_BUF_T;

typedef pps_s32 (*shell_cmd_fun_t)(pps_s32 argc, pps_char *argv[], SHELL_CMD_BUF_T *buf);


/** @fn     pps_s32 mcp_shell_cmd_init(pps_void);
 * @brief   <dua shell cmd init>
 * @return  0 - succeed | else - fail
 */
pps_s32 mcp_shell_cmd_init(pps_void);

/** @fn     pps_s32 mcp_shell_cmd_server_open(pps_void);
 * @brief   <dua shell cmd server open>
 * @return  0 - succeed | else - fail
 */
pps_s32 mcp_shell_cmd_server_open(pps_void);

/** @fn     pps_s32 mcp_shell_cmd_init(pps_void);
 * @brief   <dua shell cmd init>
 * @return  0 - succeed | else - fail
 */
pps_s32 mcp_shell_cmd_deinit(pps_void);

/** @fn     pps_s32 mcp_shell_register_debug_cmd(pps_char *cmd_name, shell_cmd_fun_t cb);
 * @brief   <dua shell register debug cmd>
 * @param   [in] cmd_name,: cmd_name
 * @param   [in] cb: cmd handler
 * @return  0 - succeed | else - fail
 */
pps_s32 mcp_shell_register_debug_cmd(pps_char *cmd_name, shell_cmd_fun_t cb);

/** @fn     pps_s32 mcp_shell_unregister_debug_cmd(pps_char *cmd_name, shell_cmd_fun_t cb);
 * @brief   <dua shell unregister debug cmd>
 * @param   [in] cmd_name,: cmd_name
 * @param   [in] cb: cmd handler
 * @return  0 - succeed | else - fail
 */
pps_s32 mcp_shell_unregister_debug_cmd(pps_char *cmd_name, shell_cmd_fun_t cb);


#ifdef __cplusplus
}
#endif

#endif /* _MCP_SHELL_CMD_H_ */
