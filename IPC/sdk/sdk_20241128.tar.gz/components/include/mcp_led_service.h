/**
 * @file        mcp_led_service.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       led service
 * @author      Shi Yanlin
 * @date        2023/04/12
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_LED_SERVICE_H_
#define _MCP_LED_SERVICE_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum mcp_led_ctrl_type {
    MCP_LED_CTRL_RED_ON,
    MCP_LED_CTRL_BLUE_ON,
    MCP_LED_CTRL_RED_FLASH,
    MCP_LED_CTRL_BLUE_FLASH,
    MCP_LED_CTRL_RED_BLUE_FLASH,
    MCP_LED_CTRL_BLUE_RED_FLASH,
    MCP_LED_CTRL_RED_BLUE_OFF,
} MCP_LED_CTRL_TYPE_E;

// if led ctrl conndition is matched, then return 1, else return 0
typedef pps_s32 (*mcp_led_ctrl_condition_query_cb_f)(pps_void);

typedef struct mcp_led_ctrl_node {
    pps_char                          name[32];           // 控制节点名称
    pps_s32                           priority;           // 控制节点优先级
    MCP_LED_CTRL_TYPE_E               ctrl_type;          // 控制节点控灯模式
    pps_s32                           on_duration;        // led灯的亮灯时间 单位 毫秒
    pps_s32                           off_duration;       // led灯的灭灯时间 单位 毫秒
    pps_s32                           blue_times;         // 控制蓝灯闪烁次数
    pps_s32                           red_times;          // 控制红灯闪烁次数
    mcp_led_ctrl_condition_query_cb_f condition_query_cb; // 控制节点的状态条件查询
} MCP_LED_CTRL_NODE_T, *MCP_LED_CTRL_NODE_PTR;

pps_s32 mcp_led_service_init(pps_void *dua_handler);

pps_s32 mcp_led_service_deinit(pps_void);

pps_s32 mcp_led_service_insert_ctrl_node(MCP_LED_CTRL_NODE_PTR node);

pps_s32 mcp_led_service_delete_ctrl_node(pps_s32 priority);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_LED_SERVICE_H_ */
