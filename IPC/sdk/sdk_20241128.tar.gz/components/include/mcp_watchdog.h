/**
 * @file        hal_watchdog.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/05/08
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_WATCHDOG_H_
#define _MCP_WATCHDOG_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef pps_s32 (*mcp_software_dog_feed_timeout_f)(pps_u8 node_id);

/** @fn      pps_s32 mcp_software_watchdog_init(pps_void *dua_handler, pps_s32 interval_s);
 * @brief   <software dog init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] interval_s : timeout
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_init(pps_void *dua_handler, pps_s32 interval_s);

/** @fn      pps_s32 mcp_software_watchdog_deinit(pps_void);
 * @brief   <software watchdog deinit>
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_deinit(pps_void);

/** @fn      pps_s32 mcp_software_watchdog_node_register(pps_char *node_id);
 * @brief   <register software watchdog>
 * @param   [in] node_id    : node id
 * @param   [in] time_out_cb: feed dog timeout callback
 * @return  0 - success | else - failure
 * @note    once register dog, hardware dog will also be fed.
 */
pps_s32 mcp_software_watchdog_node_register(pps_u8 *node_id, mcp_software_dog_feed_timeout_f time_out_cb);

/** @fn      pps_s32 mcp_software_watchdog_node_unregister(pps_char *node_id);
 * @brief   <unregister software watchdog>
 * @param   [in] node_id: node id
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_node_unregister(pps_u8 node_id);

/** @fn      pps_s32 watchdog_feed(pps_char *node_id);
 * @brief   <feed software watchdog>
 * @param   [in] node_id: node id
 * @return  0 - success | else - failure
 */
pps_s32 mcp_software_watchdog_feed(pps_u8 node_id);

/** @fn      pps_void mcp_software_watchdog_set_feed_flag(pps_s32 flag);
 * @brief   <set feed dog flag>
 * @param   [in] flag: 0-hardware dog will not be fed | 1-hardware dog will not fed
 * @return
 */
pps_void mcp_software_watchdog_set_feed_flag(pps_s32 flag);

#ifdef __cplusplus
}
#endif
#endif /* __HAL_WATCHDOG_H */
