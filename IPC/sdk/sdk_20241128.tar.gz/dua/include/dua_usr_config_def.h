
/**
 * @file        dua_event_def.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua event
 * @author      Shi Yanlin
 * @date        2023/03/10
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_USR_CONFIG_DEF_H_
#define _DUA_USR_CONFIG_DEF_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CONFIG_FIRMWARE_MAGIC 0x5354524e

typedef struct usr_dev_header {
    pps_s32  magicnum;
    pps_u32  checksum;      // 配置信息的校验码
    pps_u16  cfg_len;       // 配置信息的长度
    pps_u8   major_version; /* 0-256 */
    pps_u8   minor_version; /* 0-256 */
    pps_u8   revision_version;
    pps_char res[11]; // 预留
} USR_DEV_HEADER_T, *USR_DEV_HEADER_PTR;

#ifdef __cplusplus
}
#endif
#endif /* _DUA_COMMON_INNER_H_ */
