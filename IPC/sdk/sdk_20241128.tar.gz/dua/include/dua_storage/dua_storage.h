/**
 * @file        dua_storage.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       record and playback
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_STORAGE_H_
#define _DUA_STORAGE_H_

#include "dua_media.h"
#include "dua_common.h"
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_recorder_init(pps_void *dua_handler, pps_char *sd_mount_dir, pps_void *ctx);
 * @brief   <The recording module is initialized>
 * @param   [in] dua_handler : dua handle
 * @param   [in] sd_mount_dir: The path of the SD card mount
 * @param   [in] job_name    : the name of record mp4 root path
 * @param   [in] ctx         : Multi-channel recording reservation parameters
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_init(pps_void *dua_handler, pps_char *sd_mount_dir, pps_char *job_name, pps_void *ctx);

/** @fn      pps_s32 dua_recorder_deinit(pps_void *dua_handler, pps_void *ctx);
 * @brief   <The recording module is deinitialized>
 * @param   [in] dua_handler: dua handle
 * @param   [in] ctx        : Multi-channel recording reservation parameters
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_deinit(pps_void *dua_handler, pps_void *ctx);

/** @fn      pps_s32 dua_recorder_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <Registration of recording event callbacks>
 * @param   [in] dua_handler: dua handle
 * @param   [in] event_cb   : Event callbacks
 * @return  0-succeed | else-fail
 * @note    DUA_EVENT_RECORDER_START              = 0x6000, //Start recording
 *          DUA_EVENT_RECORDER_STOP               = 0x6001, //Stop recording
 *          DUA_EVENT_RECORDER_NEW_SEGMENT        = 0x6002, //Start New Fragment parameter with filename of the new fragment
 *          DUA_EVENT_RECORDER_END_SEGMENT        = 0x6003, //End Fragment parameter with filename of the new fragment
 *          DUA_EVENT_RECORDER_DISK_NO_SPACE_LEFT = 0x6004, //sdcard is full
 *          DUA_EVENT_RECORDER_DISK_IO_ERROR      = 0x6005, //sdcard read and write failed
 */
pps_s32 dua_recorder_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_recorder_enable(pps_void *ctx, pps_s32 enable);
 * @brief   <enable recording>
 * @param   [in] ctx  : Multi-channel recording reservation parameters
 * @param   [in] start: 0 - enable recording | 1 - diable recording
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_enable(pps_void *ctx, pps_s32 enable);

/** @fn      pps_s32 dua_recorder_set_audio_enable(pps_void *ctx, pps_s32 enable);
 * @brief   <enable recording>
 * @param   [in] ctx  : Multi-channel recording reservation parameters
 * @param   [in] enable: 0 - recording without audio stream data | 1 - recording with audio stream data
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_set_audio_enable(pps_void *ctx, pps_s32 enable);

/** @fn      pps_s32 dua_recorder_start(pps_void *ctx, pps_s32 start);
 * @brief   <Start recording>
 * @param   [in] ctx  : Multi-channel recording reservation parameters
 * @param   [in] start: 0 - stop recording | 1 - start recording
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_start(pps_void *ctx, pps_s32 start);

/** @fn      pps_s32 dua_recorder_set_configs(pps_void *ctx, DUA_RECORD_TYPE_E record_type, pps_s32 duration);
 * @brief   <Set the recording configuration>
 * @param   [in] ctx        : Multi-channel recording reservation parameters
 * @param   [in] record_type: Recording type
 * @param   [in] duration   : Duration
 * @return  0 - succeed | else - fail
 * @note    If record_type = DUA_RECORD_TYPE_CONTINUE, duration sets the duration of the footage throughout the day
 *          If record_type = DUA_RECORD_TYPE_EVENT, duration sets the duration of the event video clip
 *          However, if the length of the event footage > the length of the full-day footage, it will be divided into multiple clips
 */
pps_s32 dua_recorder_set_configs(pps_void *ctx, DUA_RECORD_TYPE_E record_type, pps_s32 duration);

/** @fn      pps_s32 dua_recorder_get_configs(pps_void *ctx, DUA_RECORD_TYPE_E *record_type, pps_s32 *duration);
 * @brief   <Get the recording configuration>
 * @param   [in] ctx        : Multi-channel recording reservation parameters
 * @param   [in] record_type: Recording type
 * @param   [in] duration   : Duration
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_get_configs(pps_void *ctx, DUA_RECORD_TYPE_E *record_type, pps_s32 *duration);

/** @fn      pps_s32 dua_recorder_get_status(pps_void *ctx, pps_s32 *enable, pps_s32 *started);
 * @brief   <Get the recording configuration>
 * @param   [in] ctx    : Multi-channel recording reservation parameters
 * @param   [in] enable : Whether recording is enabled
 * @param   [in] started: Whether recording is being made
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_get_status(pps_void *ctx, pps_s32 *enable, pps_s32 *started);

/** @fn      pps_s32 dua_recorder_is_recording(pps_void *ctx, pps_s32 *is_recording)
 * @brief   <Get the recording configuration>
 * @param   [in] ctx    : Multi-channel recording reservation parameters
 * @param   [in] is_recording : Whether recording is recording
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_is_recording(pps_void *ctx, pps_s32 *is_recording);

/** @fn      pps_s32 dua_recorder_job_clear_chche(pps_void *ctx)
 * @brief   <Get the recording configuration>
 * @param   [in] job_id    : job_id
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_job_clear_chche(pps_void *ctx);

/** @fn      pps_s32 dua_recorder_write_avframe(pps_void *ctx, pps_s32 *enable, pps_s32 *started);
 * @brief   <Get the recording configuration>
 * @param   [in] ctx    : Multi-channel recording reservation parameters
 * @param   [in] enable : Whether recording is enabled
 * @param   [in] started: Whether recording is being made
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_write_avframe(pps_void *ctx, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 len);

/** @fn      pps_s32 dua_recorder_write_aovframe(pps_void *ctx, pps_s32 *enable, pps_s32 *started);
 * @brief   <Get the recording configuration>
 * @param   [in] ctx    : Multi-channel recording reservation parameters
 * @param   [in] enable : Whether recording is enabled
 * @param   [in] started: Whether recording is being made
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_write_aovframe(pps_void *ctx, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 len);

/** @fn      pps_s32 dua_playback_start(pps_void *ctx, pps_s32 *session_id, DUA_RECORD_TIME_T date_time);
 * @brief   <Start playback>
 * @param   [in] ctx       : Multi-channel recording reservation parameters
 * @param   [in] session_id: The recording playback session ID
 * @param   [in] date_time : The start date of recording playback
 * @return  0 - succeed | else - fail
 * @note    Multi-way query is supported according to session_id
 */
pps_s32 dua_playback_start(pps_void *ctx, pps_s32 *session_id, DUA_RECORD_TIME_T date_time);

/** @fn      pps_s32 dua_playback_stop(pps_void *ctx, pps_s32 session_id);
 * @brief   <End playback>
 * @param   [in] ctx       : Multi-channel recording reservation parameters
 * @param   [in] session_id: The session ID of the video playback
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_playback_stop(pps_void *ctx, pps_s32 session_id);

/** @fn      pps_s32 dua_playback_get_avframe(pps_void *ctx, pps_s32 session_id, DUA_PLAYBACK_AVFRAME_PTR avframe);
 * @brief   <End playback>
 * @param   [in] ctx       : Multi-channel recording reservation parameters
 * @param   [in] session_id: The session ID of the video playback
 * @param   [in] avframe   : One frame of data
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_playback_get_avframe(pps_void *ctx, pps_s32 session_id, DUA_PLAYBACK_AVFRAME_PTR avframe);

/** @fn      pps_s32 dua_record_delete(pps_s32 year, pps_s32 mouth, pps_s32 day);
 * @brief   <delete one day recorder>
 * @param   [in] year
 * @param   [in] mouth
 * @param   [in] day
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_record_delete(pps_s32 year, pps_s32 mouth, pps_s32 day);

/** @fn      pps_s32 dua_recorder_search_by_day(pps_void *ctx, DUA_RECORDER_DAY_SEARCH_PTR daysearch, DUA_RECORDER_DAY_LIST_PTR daylist);
 * @brief   <Query by day>
 * @param   [in] ctx       : Multi-channel recording reservation parameters
 * @param   [in] daysearch : Query by day
 * @param   [in] list      : Query results
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_search_by_day(pps_void *ctx, DUA_RECORDER_DAY_SEARCH_PTR daysearch, DUA_RECORDER_DAY_LIST_PTR daylist);

/** @fn      pps_s32 dua_recorder_search_by_month(pps_void *ctx, pps_record_month_search_t monthsearch, DUA_RECORDER_MONTH_LIST_PTR monthlist);
 * @brief   <Queries by month>
 * @param   [in] ctx        : Multi-channel recording reservation parameters
 * @param   [in] monthsearch: Queries by month
 * @param   [in] list       : Query results
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_search_by_month(pps_void *ctx, DUA_RECORDER_MONTH_SEARCH_PTR monthsearch, DUA_RECORDER_MONTH_LIST_PTR monthlist);

/** @fn      pps_s32 dua_recorder_search_by_time_slice(pps_void *ctx, DUA_RECORD_TIME_SEARCH_PTR start_time, DUA_RECORD_TIME_SEARCH_PTR end_time, DUA_RECORDER_DAY_LIST_PTR slicelist);
 * @brief   <Queries by time slice>
 * @param   [in] ctx        : Multi-channel recording reservation parameters
 * @param   [in] start_time  : start time
 * @param   [in] end_time    : end time
 * @param   [in] list        : Query results
 * @return  0 - succeed | else - fail
 */
pps_s32 dua_recorder_search_by_time_slice(pps_void *ctx, DUA_RECORD_TIME_SEARCH_PTR start_time, DUA_RECORD_TIME_SEARCH_PTR end_time, DUA_RECORDER_DAY_LIST_PTR slicelist);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_STORAGE_H_ */
