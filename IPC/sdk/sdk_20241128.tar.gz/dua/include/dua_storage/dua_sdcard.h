/**
 * @file        dua_sdcard.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       sdcard
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_SDCARD_H_
#define _DUA_SDCARD_H_

#include "dua_common.h"
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_sdcard_init(pps_void *dua_handler);
 * @brief   <The sdcard module is initialized>
 * @param   [in] dua_handler: dua handle
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_init(pps_void *dua_handler, pps_char *mount_dir);

/** @fn      pps_s32 dua_sdcard_deinit(pps_void *dua_handler);
 * @brief   <The sdcard module is deinitialized>
 * @param   [in] dua_handler: dua handle
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_deinit(pps_void *dua_handler);

/** @fn      pps_s32 dua_sdcard_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <Registration of the sdcard event callback>
 * @param   [in] dua_handler: dua handle
 * @param   [in] event_cb   : Event callbacks
 * @return  0-succeed | else-fail
 * @note    DUA_EVENT_SDCARD_FORMAT_START = 0x5000, //Start formatting sdcard
 *          DUA_EVENT_SDCARD_FORMATING    = 0x5001, //Format sdcard
 *          DUA_EVENT_SDCARD_FORMAT_DONE  = 0x5002, //Formatting sdcard is complete
 *          DUA_EVENT_SDCARD_MOUNT_START  = 0x5003, //Start mounting sdcard
 *          DUA_EVENT_SDCARD_MOUNT_DONE   = 0x5004, //Mount sdcard completes
 *          DUA_EVENT_SDCARD_UMOUNT_START = 0x5005, //Start uninstalling sdcard
 *          DUA_EVENT_SDCARD_UMOUNT_DONE  = 0x5006, //Uninstalling sdcard is complete
 *          DUA_EVENT_SDCARD_DISK_FULL    = 0x5007, //sdcard is full
 *          DUA_EVENT_SDCARD_FSCK_START   = 0x5008, //Start repairing sdcard
 *          DUA_EVENT_SDCARD_FSCK_FINISH  = 0x5009, //Repair sdcard complete
 */
pps_s32 dua_sdcard_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_sdcard_event_unregister(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <unregistration of the sdcard event callback>
 * @param   [in] dua_handler: dua handle
 * @param   [in] event_cb   : Event callbacks
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_event_unregister(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_sdcard_get_status(DUA_SDCARD_STATUS_PTR sd_status);
 * @brief   <Gets the status of the current sdcard>
 * @param   [out] status: sdcard status
 * @return 0-succeed | else-fail
 */
pps_s32 dua_sdcard_get_status(DUA_SDCARD_STATUS_PTR sd_status);

/** @fn      pps_s32 pps_device_get_sdcard_info(DUA_SDCARD_INFO_PTR sdcard_info);
 * @brief   <Gets the information of the current sdcard>
 * @param   [out] sdcard_info: Sdcard's information
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_get_info(DUA_SDCARD_INFO_PTR sdcard_info);

/** @fn      pps_s32 dua_sdcard_format(pps_void);
 * @brief   <Gets the status of the current sdcard>
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_format(pps_void);

/** @fn      pps_s32 dua_sdcard_get_format_percent(pps_void);
 * @brief   <Gets the progress of the current sdcard formatting>
 * @return  0-succeed | else-fail
 */
pps_s32 dua_sdcard_get_format_percent(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_SDCARD_H_ */
