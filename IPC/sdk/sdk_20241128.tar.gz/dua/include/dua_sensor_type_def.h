/**
 * @file        dua_event_def.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua event
 * @author      Shi Yanlin
 * @date        2023/03/10
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_SENSOR_TYPE_DEF_H_
#define _DUA_SENSOR_TYPE_DEF_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* sensor encrypt name */
#define DEVICE_SENSOR_GC2063MIPI                "gc2063mipi"
#define DEVICE_SENSOR_SP1405SMIPI               "sp1405smipi"
#define DEVICE_SENSOR_MIS2006MIPI               "mis2006mipi"
#define DEVICE_SENSOR_SOIF51MIPI                "soif51mipi"
#define DEVICE_SENSOR_GC2063TMIPI               "gc2063tmipi"
#define DEVICE_SENSOR_SC3335MIPI                "sc3335mipi"
#define DEVICE_SENSOR_SC3338MIPI                "sc3338mipi"
#define DEVICE_SENSOR_SC301IOTMIPI              "sc301iotmipi"
#define DEVICE_SENSOR_SC301IOTQMIPI             "sc301iotqmipi"
#define DEVICE_SENSOR_GC4653MIPI                "gc4653mipi"
#define DEVICE_SENSOR_GC5603MIPI                "gc5603mipi"
#define DEVICE_SENSOR_GC8613MIPI                "gc8613mipi"
#define DEVICE_SENSOR_MIS5001MIPI               "mis5001mipi"
#define DEVICE_SENSOR_MIS2008MIPI               "mis2008mipi"
#define DEVICE_SENSOR_MIS2008TMIPI              "mis2008tmipi"
#define DEVICE_SENSOR_MIS2009MIPI               "mis2009mipi"
#define DEVICE_SENSOR_MIS2009TMIPI              "mis2009tmipi"
#define DEVICE_SENSOR_MIS2032TMIPI              "mis2032tmipi"
#define DEVICE_SENSOR_MIS4001MIPI               "mis4001mipi"
#define DEVICE_SENSOR_GC4023FMIPI               "gc4023fmipi"
#define DEVICE_SENSOR_SC531AIMIPI               "sc531aimipi"
#define DEVICE_SENSOR_SC5338MIPI                "sc5338mipi"
#define DEVICE_SENSOR_GC3003MIPI                "gc3003mipi"
#define DEVICE_SENSOR_CV2003MIPI                "cv2003mipi"
#define DEVICE_SENSOR_CV2003TMIPI               "cv2003tmipi"
#define DEVICE_SENSOR_SOIF51TMIPI               "soif51tmipi"
#define DEVICE_SENSOR_SC3338MIPI_SC3338MIPI     "sc3338mipi-sc3338mipi"
#define DEVICE_SENSOR_MIS2009TMIPI_MIS2009MIPI  "mis2009tmipi-mis2009mipi"
#define DEVICE_SENSOR_MIS2009TMIPI_MIS2009TMIPI "mis2009tmipi-mis2009tmipi"
#define DEVICE_SENSOR_CV2003MIPI_CV2003MIPI     "cv2003mipi-cv2003mipi"

#ifdef __cplusplus
}
#endif
#endif /* _DUA_COMMON_INNER_H_ */
