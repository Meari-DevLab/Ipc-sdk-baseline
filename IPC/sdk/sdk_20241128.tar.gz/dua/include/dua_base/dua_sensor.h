/**
 * @file        dua_sensor.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/03/14
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_SENSOR_H_
#define _DUA_SENSOR_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_void dua_sensor_pir_event_trigger(pps_void *dua_handler);
 * @brief    <pir module init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_void dua_sensor_pir_event_trigger(pps_void *dua_handler);

/** @fn      pps_s32 dua_sensor_pir_init(pps_void *dua_handler);
 * @brief   <pir module init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_sensor_pir_init(pps_void *dua_handler);

/** @fn      pps_s32 dua_sensor_pir_deinit(pps_void);
 * @brief   <pir module deinit>
 * @return  0 - success | else - failure
 */
pps_s32 dua_sensor_pir_deinit(pps_void *dua_handler);

/** @fn      pps_s32 sensor_pir_event_register(pps_void *dua_handler,dua_event_callback_f event_cb);
 * @brief   <pir event callback register>
 * @param   [in] dua_handler: dua handler
 * @param   [in] event_cb   : callback
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_pir_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 sensor_pir_event_unregister(pps_void *dua_handler,dua_event_callback_f event_cb);
 * @brief   <pir event callback register>
 * @param   [in] dua_handler: dua handler
 * @param   [in] event_cb   : callback
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_pir_event_unregister(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_sensor_pir_enable(pps_void *dua_handler, pps_s32 sensor_id, pps_s32 enable);
 * @brief   <enable / disable pir sensor>
 * @param   [in] dua_handler: dua handler
 * @param   [in] enable     : 0 - disable | 1 - enable
 *          [in] sensor_id  : 0 - first | 1 - second | MAX - all sensor
 * @note    serial port pir enable special.
 *          enable : 0 - disable | 1 - left enable | 2 - right enable | 3 - all enalbe
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_pir_enable(pps_void *dua_handler, pps_s32 sensor_id, pps_s32 enable);

/** @fn      pps_s32 dua_sensor_pir_set_value(pps_void *dua_handler, pps_u8 sensit_lvl);
 * @brief   <set sensitivity of pir sensor>
 * @param   [in] dua_handler: dua handler
 * @param   [in] sensit_lvl : sensitivity value lvl 0 ~ 9
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_pir_set_value(pps_void *dua_handler, pps_u8 sensit_lvl);

/** @fn      pps_s32 dua_sensor_pir_set_alarm_interval(pps_void *dua_handler, pps_s32 alarm_timeval)
 * @brief   <set pir alarm timeval>
 * @param   [in] dua_handler  : dua handler
 * @param   [in] alarm_timeval: alarm timeval (seconds), in alarm_timeval seconds, pir only can be triggered once
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_pir_set_alarm_interval(pps_void *dua_handler, pps_s32 alarm_timeval);

/** @fn      pps_s32 dua_sensor_get_temperature(pps_void *dua_handler, pps_s32 *temperature);
 * @brief   <get temperature>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] temperature: temperature
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_get_temperature(pps_void *dua_handler, pps_s32 *temperature);

/** @fn      pps_s32 dua_sensor_get_humidity(pps_s32 *sensitivity);
 * @brief   <get humidity>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] humidity   : humidity
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_get_humidity(pps_void *dua_handler, pps_s32 *humidity);

/** @fn      ppps_s32 dua_sensor_radar_set_level(pps_void *dua_handler, pps_s32 level);
 * @brief   <set radar level>
 * @param   [in] dua_handler: dua handler
 * @param   [in] level      : level
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_radar_set_level(pps_void *dua_handler, pps_s32 level);

/** @fn      pps_s32 dua_sensor_set_photoresistor_value(pps_u8 threshold, pps_s32 threshold_max, pps_s32 threshold_min);
 * @brief   <set photoresistor threshold>
 * @param   [in] dua_handler  : dua handler
 * @param   [in] threshold    : the threshold of day night mode switch,
 *                              when device is powered on or wakeed up,
 *                              if >= threshold, the device will be switched to day mode,
 *                              else  thedevice will be switched to night mode.
 * @param   [in] threshold_max: photoresistor max threshold
 *                              the treshold that device switches to the day mode.
 *                              if device is night mode now and photoresistor value is larger than threshold_max, device switches to the day mode
 * @param   [in] threshold_min: photoresistor min threshold
 *                              the treshold that device switches to the night mode.
 *                              if device is day mode now and photoresistor value is less than threshold_min, device switches to the night mode
 * @return   0 - success | else - failure
 */
pps_s32 dua_sensor_set_photoresistor_value(pps_void *dua_handler, pps_u8 threshold, pps_s32 threshold_max, pps_s32 threshold_min);

/** @fn      pps_s32 dua_sensor_get_photoresistor_value(pps_void *dua_handler, pps_s32 channel);
 * @brief   <get photoresistor threshold>
 * @param   [in] dua_handler  : dua handler
 * @param   [in] channel      : channel, for now just use 0 channel
 * @return  lum
 * @note    put the device into dark box and adjust the luminance of light, use this func to get the photoresistor value
 *          usually, day night switched lum 2.5lux     threshold
 *          day mode switches to night mode is 0.8lux  threshold_min
 *          night mode switches to day mode is 7.5lux  threshold_max
 */
pps_s32 dua_sensor_get_photoresistor_value(pps_void *dua_handler, pps_s32 channel);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_SENSOR_H_ */
