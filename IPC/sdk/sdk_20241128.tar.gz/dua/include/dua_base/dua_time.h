/**
 * @file        dua_time.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       time/timezone configure
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_TIME_H_
#define _DUA_TIME_H_

#include <time.h>
#include <sys/time.h>
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

struct timezone_t {
    pps_s32 tz_dsttime;
    pps_s32 tz_minuteswest;
};

/** @fn      pps_s32 dua_time_get_rtctime(struct tm *tm);
 * @brief   <get rtc time>
 * @param   [out] tm: time
 * @return   0 - success | else - failure
 */
pps_s32 dua_time_get_rtctime(struct tm *tm);

/** @fn      pps_s32 dua_set_systime(time_t systime);
 * @brief   <set system time>
 * @param   [in] systime: system time
 * @return   0 - success | else - failure
 */
pps_s32 dua_time_set_systime(time_t curtime);

/** @fn      pps_s32 dua_set_day_time(DUA_DATE_TIME_T date_time);
 * @brief   <set timezone>
 * @param   [in] timezone: timezone info int TZ format
 * @param   [in] size    : timezone buffer len
 * @return   0 - success | else - failure
 */
pps_s32 dua_time_set_timezone(pps_char *timezone, pps_u32 size);

/** @fn      pps_s32 dua_get_day_time(struct timezone_t *tz)
 * @brief   <get timezone>
 * @param   [in] tz    : timezone buffer
 * @return   0 - success | else - failure
 */
pps_s32 dua_time_get_timezone(struct timezone_t *tz);

/** @fn      dua_get_sys_runtime
 * @brief   <get system runtime>
 * @param   pps_void
 * @return  current runtime, unit secound.
 * @note    the device runtime from poweron/wakeup to poweroff/standby
 */
time_t dua_get_sys_runtime(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_TIME_H_ */
