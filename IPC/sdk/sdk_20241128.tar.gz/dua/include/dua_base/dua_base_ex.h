/**
 * @file        dua_base_ex.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua_base 拓展
 * @author      Shi Yanlin
 * @date        2023/05/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_BASE_EX_H_
#define _DUA_BASE_EX_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_debug_mode_enable(pps_s32 enable);
 * @brief   <device debug mode>
 * @param   [in] enable: 0 - quit debug mode | 1 - enter debug mode
 * @return  0 - success | else - failure
 */
pps_s32 dua_debug_mode_enable(pps_s32 enable);

/** @fn      pps_s32 dua_base_get_oem_id(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get oem id>
 * @return  oemid
 */
pps_s32 dua_base_get_oem_id(pps_void *dua_handler);

/** @fn      pps_s32 dua_base_get_oem_uuid(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get oem uuid>
 * @return  oemid
 */
pps_u8 *dua_base_get_oem_uuid(pps_void *dua_handler);

/** @fn      pps_s32 dua_base_get_oem_authkey(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get oem authkey>
 * @return  oemid
 */
pps_u8 *dua_base_get_oem_authkey(pps_void *dua_handler);

/** @fn      pps_s32 dua_base_get_tp(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get tp>
 * @return  oemid
 */
pps_char *dua_base_get_tp(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_identity_card(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get identity_card>
 * @return  identity_card
 */
pps_char *dua_get_identity_card(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_optical_code(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get optical code>
 * @return  optical code
 */
pps_char *dua_get_optical_code(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_civil_campany_type(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get campany_type>
 * @return  campany_type
 */
pps_u32 dua_get_civil_campany_type(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_licence_type(pps_void *dua_handler);
 * @param   [in] dua_handler: handler:
 * @brief   <get licence_type>
 * @return  licence_type
 */
pps_u32 dua_get_licence_type(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_av_handler(pps_void *dua_handler,DUA_AVPROC_TYPE_E dua_av_type);
 * @param   [in] dua_handler: handler:dua_av_type :DUA_AVPROC_TYPE_E
 * @brief   <get licence_type>
 * @return  av handler
 */
pps_void *dua_get_av_handler(pps_void *dua_handler, DUA_AVPROC_TYPE_E av_type);

/** @fn      pps_s32 dua_get_firmware_version(pps_char *version,pps_s32 len);
 * @param   [out] version: firmware version
 * @param   [in] len: array length
 * @brief   <get firmware version>
 * @return  licence_type
 */
pps_s32 dua_get_firmware_version(pps_char *version, pps_s32 len);

/** @fn      MCP_LIST_PTR dua_base_get_event_cb_addr(pps_void);
 * @brief   <get dua base event callback addr>
 * @return
 */
MCP_LIST_PTR dua_base_get_event_cb_addr(pps_void);

/** @fn      pps_s32 dua_get_mcu_stats_data(pps_void *dua_handler, pps_void *stats_data, pps_s32 size);
 * @brief   <get mcu version>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] stats_data:
 * @return  0 - success | else - failure
 */
pps_s32 dua_get_mcu_stats_data(pps_void *dua_handler, pps_void *stats_data, pps_s32 size);

/** @fn      pps_s32 dua_set_mcu_stats_data(pps_void *dua_handler, pps_void *stats_data, pps_s32 size);
 * @brief   <get mcu version>
 * @param   [in] dua_handler: dua handler
 * @param   [in] stats_data:
 * @return  0 - success | else - failure
 */
pps_s32 dua_set_mcu_stats_data(pps_void *dua_handler, pps_void *stats_data, pps_s32 size);

/** @fn      pps_s32 dua_get_mcu_version(pps_void *dua_handler, pps_char *mcu_version, pps_s32 size);
 * @brief   <get mcu version>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] mcu_version:
 * @return  0 - success | else - failure
 */
pps_s32 dua_get_mcu_version(pps_void *dua_handler, pps_char *mcu_version, pps_s32 size);

/** @fn      DUA_EX_CAPABILITY_PTR dua_get_ex_device_capacity(pps_void *dua_handler)
 * @brief   <get device tool capa information>
 * @param   [in] dua_handler: dua handler
 * @return  NULL - failure | else return DUA_EX_CAPABILITY_PTR
 */
DUA_EX_CAPABILITY_PTR dua_get_ex_device_capacity(pps_void *dua_handler);

/** @fn     pps_s32 dua_get_mem_usage(pps_void *dua_handler)
 * @brief   <get mem info>
 * @return   mem useage
 */
pps_s32 dua_get_mem_usage(pps_void *dua_handler);

/** @fn     pps_s32 dua_get_cpu_usage(pps_void *dua_handler)
 * @brief   <get cpu info>
 * @return   cpu usage
 */
pps_s32 dua_get_cpu_usage(pps_void *dua_handler);

/** @fn     pps_s32 dua_get_bt_handler(pps_void *dua_handler)
 * @brief   <get bt handler>
 * @return  hander prt
 */
pps_void *dua_get_bt_handler(pps_void *dua_handler);

#ifndef DUA_CONFIG_BATTERY_DEVICE
/** @fn      dua_device_wifi_insmod(pps_s32 wifi_module);
 * @brief   <加载wifi驱动>
 *  * @param   [in]  dua_handler: dua handler
 * @param   [in] wifi_module:
 */
pps_void dua_device_wifi_insmod(pps_void *dua_handler, pps_s32 wifi_module);
#endif

#ifdef __cplusplus
}
#endif
#endif /* _DUA_BASE_EX_H_ */
