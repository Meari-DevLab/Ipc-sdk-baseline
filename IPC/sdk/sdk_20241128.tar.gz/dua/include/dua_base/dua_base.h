/**
 * @file        dua_board.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua board
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_BOARD_H_
#define _DUA_BOARD_H_

#include "pps_osal_type.h"
#include "dua_event_def.h"
#include "dua_common.h"
#include "mcp_list.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @struct  dua_init_param
 * @brief   <dua initialization parameter>
 */
typedef struct dua_init_param {
    pps_u8 *quick_start_info; // quick start buffer in json format
    pps_u8  res[64];
} DUA_INIT_PARAM_T, *DUA_INIT_PARAM_PTR;

/** @fn      const pps_void *dua_init(DUA_INIT_PARAM_PTR param);
 * @brief   <dua init>
 * @param   [in] param: quick start parameter for now it just input NULL
 * @return  NULL - init failure | else return DUA_BASE_HANDLER_PTR
 * @note    this api only can be initialized once.
 */
pps_void *dua_init(DUA_INIT_PARAM_PTR param);

/** @fn      pps_s32 dua_deinit(pps_void *dua_handler);
 * @brief   <dua deinit>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_deinit(pps_void *dua_handler);

/** @fn      DUA_BOARD_INFO_PTR dua_get_board_info(pps_void *dua_handler);
 * @brief   <get device board information>
 * @param   [in] dua_handler: dua handler
 * @return  NULL - failure | else return DUA_BOARD_INFO_PTR
 */
DUA_BOARD_INFO_PTR dua_get_board_info(pps_void *dua_handler);

/** @fn      pps_s32 dua_get_device_capacity(pps_void *dua_handler);
 * @brief   <get device capcacity>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
DUA_CAPABILITY_PTR dua_get_device_capacity(pps_void *dua_handler);

/** @fn      pps_s32 dua_watchdog_start(pps_void *dua_handler);
 * @brief   <hardware watchdog start>
 * @param   [in] dua_handler: dua handler
 * @param   [in] interval_s : time interval, unit in seconds
 * @return  0 - success | else - failure
 * @note    if the interval time between two continuous dua_watchdog_feed is larger than interval_s,
 *          the master chip will be rebooted.
 */
pps_s32 dua_watchdog_start(pps_void *dua_handler, pps_s32 interval_s);

/** @fn      pps_s32 dua_watchdog_deinit(pps_void*dua_handler);
 * @brief   <hardware watchdog stop>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 * @note    close the watchdog, the master chip will not be rebooted
 */
pps_s32 dua_watchdog_stop(pps_void *dua_handler);

/** @fn      pps_s32 dua_watchdog_feed(pps_void *dua_handler);
 * @brief   <hardware watchdog feed>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_watchdog_feed(pps_void *dua_handler);

/** @fn      pps_s32 dua_base_event_register(pps_void *dua_handler, dua_eventhub_callback_f callback);
 * @brief   <register dua base event callback>
 * @param   [in] dua_handler: dua handler
 * @param   [in] callback   : event callback
 * @return  0 - success | else - failure
 * @note    once register this base event register, the following will be throwed out.
 *          DUA_EVENT_BUTTION_RESET_KEYDOWN
 *              for both battery and plugin device, once reset button press keydown, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_RESET_KEYUP
 *              for both battery andplugin device, once reset button press keyup, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_RESET_KEYPRESS_SHORT
 *              for both battery and plugin device, once reset button press keydown, hold on within 4s and release the button, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_RESET_KEYPRESS_LONG
 *              for both battery and plugin device, once reset button press keydown and hold on larger 4s, this event will be throwed out every 100 ms.
 *
 *          DUA_EVENT_BUTTION_DOORBELL_KEYDOWN
 *              for battery device, this event is not supported to throw out.
 *              for plugin device, once doorbell button press keydown, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_DOORBELL_KEYUP
 *              for battery device, this event is not supported to throw out.
 *              for plugin device, once reset button press keyup, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_DOORBELL_KEYPRESS_SHORT, for battery device(not doorbell), this event also means power button keypress short.
 *              for battery device, once reset button press keydown, hold on within 3s and release the button, this event will be throwed out once.
 *              for plugin device, once reset button press keydown, hold on within 4s and release the button, this event will be throwed out once.
 *
 *          DUA_EVENT_BUTTION_DOORBELL_KEYPRESS_LONG, for battery device(not doorbell), this event also means power button keypress long.
 *              for battery device, if hold the button 3s, this event will be throwed out once.
 *              for plugin device, once reset button press keydown and hold on larger 4s, this event will be throwed out every 100 ms.
 *
 *          DUA_EVENT_TAMPER_ALARM, Demolition alarm
 */
pps_s32 dua_base_event_register(pps_void *dua_handler, dua_event_callback_f callback);

/** @fn      pps_s32 dua_base_event_unregister(pps_void *dua_handler, dua_eventhub_callback_f callback);
 * @brief   <unregister dua base event callback>
 * */
pps_s32 dua_base_event_unregister(pps_void *dua_handler, dua_event_callback_f callback);

/** @fn      pps_s32 dua_reboot(pps_void *dua_handler);
 * @brief   <device reboot>
 * @return  0 - success | else - failure
 * @param   [in] dua_handler: dua handler
 * @note    battery device also reboot the mcu
 */
pps_s32 dua_reboot(pps_void *dua_handler);

/** @fn      pps_s32 dua_shutdown(pps_void *dua_handler);
 * @brief   <mcu power shut down>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_shutdown(pps_void *dua_handler);

/** @fn      pps_s32 dua_standby(pps_void *dua_handler, DUA_DEVICE_STANDBY_PARAM_T standby_param);
 * @brief   <device standby mode>
 * @param   [in] dua_handler  : dua handler
 * @param   [in] standby_param: standby parameter settings
 * @return  0 - success | else - failure
 */
pps_s32 dua_standby(pps_void *dua_handler, DUA_DEVICE_STANDBY_PARAM_T standby_param);

/** @fn      pps_s32 dua_aov_mode_entry(pps_void *dua_handler, DUA_DEVICE_STANDBY_PARAM_T standby_param);
 * @brief   <device aov mode>
 * @param   [in] dua_handler  : dua handler
 * @param   [in] standby_param: standby parameter settings
 * @return  0 - success | else - failure
 */
pps_s32 dua_aov_mode_entry(pps_void *dua_handler, DUA_DEVICE_STANDBY_PARAM_T standby_param);

/** @fn      pps_s32 dua_aov_get_wakeup_status(pps_void *dua_handler);
 * @brief   <device aov mode get wakeup status>
 * @param   [in] dua_handler  : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_aov_get_wakeup_status(pps_void *dua_handler);

/** @fn      pps_void dua_aov_wakeup_mcu(pps_void *dua_handler);
 * @brief   <device aov mode wakeup mcu>
 * @param   [in] dua_handler  : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_aov_wakeup_mcu(pps_void *dua_handler);

/** @fn      pps_s32 dua_tamper_enable(pps_void *dua_handler, pps_u8 enable);
 * @brief   <prevention of disassembly alarm switch>
 * @param   [in] dua_handler: dua handler
 * @param   [in] enable     : alarm switch, 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 * @note    this api is only used for battery doorbell device
 */
pps_s32 dua_tamper_enable(pps_void *dua_handler, pps_u8 enable);

/** @fn      pps_s32 dua_tamper_get_state(pps_void *dua_handler, pps_u8 *state);
 * @brief   <prevention of disassembly status>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] status     : status 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 * @note    this api is only used for battery doorbell device
 */
pps_s32 dua_tamper_get_state(pps_void *dua_handler, pps_u8 *status);

/** @fn      pps_s32 dua_get_wakeup_type(pps_void *dua_handler, DUA_WAKEUP_TYPE_E *type);
 * @brief   <get device wakeup type>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] type       : wakeup type
 * @return  0 - success | else - failure
 */
pps_s32 dua_get_wakeup_type(pps_void *dua_handler, DUA_WAKEUP_TYPE_E *type);

/** @fn      pps_s32 dua_set_powersave_mdoe(pps_void *dua_handler, pps_u8 enable);
 * @brief   <set device power-save mode>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] enable     : power-save mode, 0-disable, 1-enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_set_powersave_mdoe(pps_void *dua_handler, pps_u8 enable);

/** @fn      pps_s32 dua_ircut_ctrl(DUA_IRCUT_ID_E id, pps_s32 on);
 * @brief   <控制ircut开关>
 * @param   [in] id: cnt，
 * @param   [in] on: on：1 - enable  0 - disable
 * @return  0 - 成功 | 非0 - 失败
 */
pps_s32 dua_ircut_ctrl(DUA_IRCUT_ID_E id, pps_s32 on);

/** @fn      pps_s32 dua_mcu_deinit(pps_void *dua_handler, pps_u8 enable);
 * @brief   <deinit mcu>
 * @return  0 - success | else - failure
 */
pps_s32 dua_mcu_deinit(pps_void);

/** @fn      pps_s32 dua_mcu_init(pps_void *dua_handler, pps_u8 enable);
 * @brief   <init mcu>
 * @return  0 - success | else - failure
 */
pps_s32 dua_mcu_init(pps_void);
#ifdef __cplusplus
}
#endif
#endif /* _DUA_BOARD_H_ */
