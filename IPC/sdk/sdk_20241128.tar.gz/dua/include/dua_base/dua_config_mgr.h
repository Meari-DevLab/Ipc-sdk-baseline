/**
 * @file        dua_config_mgr.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       configuration manager
 * @author      Shi Yanlin
 * @date        2023/05/23
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_CONFIG_MGR_H_
#define _DUA_CONFIG_MGR_H_
#include "dua_base.h"

#include "pps_osal_type.h"
#include "dua_config_def.h"
#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_usr_cfg_write(pps_void *dua_handler, pps_char *data, pps_s32 len);
 * @brief   <write config content>
 * @param   [in] dua_handler: dua handler
 * @param   [in] data : Configuration content that needs to be written
 * @param   [in] len : the len of data
 * @return  0 - success | else - failure
 * @note    only support with setup partition
 */
pps_s32 dua_usr_cfg_write(pps_void *dua_handler, pps_char *data, pps_s32 len);

/** @fn      pps_s32 dua_usr_cfg_read(pps_void *dua_handler, pps_char *data, pps_s32 len);
 * @brief   <read config content>
 * @param   [in] dua_handler: dua handler
 * @param   [out] data : Configuration content
 * @param   [in] len : the len of data
 * @return  0 - success | else - failure
 * @note    only support with setup partition
 */
pps_s32 dua_usr_cfg_read(pps_void *dua_handler, pps_char *data, pps_s32 len);

/** @fn      pps_s32 dua_usr_cfg_reset(pps_void *dua_handler);
 * @brief   <reset all config>
 * @return  0 - success | else - failure
 * @note    only support with setup partition
 */
pps_s32 dua_usr_cfg_reset(pps_void *dua_handler);

/** @fn      dua_dev_config_read(pps_void *dua_handler , DUA_DEVICE_CFG_PTR *dua_dev_cfg);
 * @brief   <read config content>
 * @param   [in] dua_handler: dua handler
 * @param   [in] app_usr_cfg : Place the read data into the structure
 * @return  0 - success | else - failure
 */
pps_s32 dua_dev_config_read(pps_void *dua_handler, DUA_DEVICE_CFG_PTR *dua_dev_cfg);

/** @fn      dua_custom_info_write(pps_void *dua_handler , DUA_DEVICE_CFG_PTR *dua_dev_cfg);
 * @brief   <read config content>
 * @param   [in] dua_handler: dua handler
 * @param   [in] data       : data
 * @param   [in] len        : data len maximum 4 * 1024 bytes
 * @return  0 - success | else - failure
 */
pps_s32 dua_custom_info_write(pps_void *dua_handler, pps_char *data, pps_s32 len);

/** @fn      dua_custom_info_read(pps_void *dua_handler , DUA_DEVICE_CFG_PTR *dua_dev_cfg);
 * @brief   <read config content>
 * @param   [in] dua_handler: dua handler
 * @param   [in] data       : data
 * @param   [in] len        : data len maximum 4 * 1024 bytes
 * @return  0 - success | else - failure
 */
pps_s32 dua_custom_info_read(pps_void *dua_handler, pps_char *data, pps_s32 len);

/** @fn      pps_s32 dua_flash_write(pps_void *dua_handler, pps_char *data, pps_s32 len, pps_char *filename)
 * @brief   <read config content>
 * @param   [in] dua_handler: dua handler
 * @param   [in] data       : data
 * @param   [in] len        : data len maximum 4 * 1024 bytes
 * @return  0 - success | else - failure
 */
pps_s32 dua_flash_write(pps_void *dua_handler, pps_char *data, pps_s32 len, pps_char *filename);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_CONFIG_MGR_H_ */
