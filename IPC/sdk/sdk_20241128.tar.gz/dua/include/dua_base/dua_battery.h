/**
 * @file        dua_battery.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       battery
 * @author      Shi Yanlin
 * @date        2023/03/11
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_BATTERY_H_
#define _DUA_BATTERY_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @fn      pps_s32 dua_battery_init(pps_void *dua_handler);
 * @brief   <init device battery module>
 * @param   [in] dua_handler : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_init(pps_void *dua_handler);

/** @fn      pps_s32 dua_battery_get_voltage(pps_s32 *voltage);
 * @brief   <get battery voltage>
 * @param   [in]  dua_handler : dua handler
 * @param   [out] voltage     : battery voltage
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_get_voltage(pps_void *dua_handler, pps_s32 *voltage);

/** @fn      pps_s32 dua_battery_get_capacity(pps_u32 *capacity);
 * @brief   <get battery capacity>
 * @param   [in]  dua_handler : dua handler
 * @param   [out] capacity    : battery capacity percent(uint:%, rang:0 - 100)
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_get_capacity(pps_void *dua_handler, pps_u32 *capacity);

/** @fn      pps_s32 dua_battery_get_status(pps_void *dua_handler, DUA_BATTER_STATUS_PTR status);
 * @brief   <get battery status>
 * @param   [in]  dua_handler : dua handler
 * @param   [out] status      : batter status
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_get_status(pps_void *dua_handler, DUA_BATTER_STATUS_PTR status);

/** @fn      pps_s32 dua_battery_lock(pps_void *dua_handler);
 * @brief   <battery lock>
 * @param   [in] dua_handler : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_lock(pps_void *dua_handler);

/** @fn      pps_s32 dua_battery_unlock(pps_vpps_void *dua_handleroid);
 * @brief   <battery unlock>
 * @param   [in] dua_handler : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_battery_unlock(pps_void *dua_handler);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_BATTERY_H_ */
