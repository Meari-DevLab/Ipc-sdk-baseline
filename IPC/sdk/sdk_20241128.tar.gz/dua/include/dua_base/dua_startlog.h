/**
 * @file        dua_startlog.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      rzq
 * @date        2023/06/08
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_START_LOG_H_
#define _DUA_START_LOG_H_

#include "pps_osal_type.h"


#ifdef __cplusplus
extern "C" {
#endif

pps_s32 dua_startup_init(pps_void *dua_handler);

pps_s32 dua_start_startup_log(pps_void *dua_handler);

pps_s32 dua_delete_startup_log(pps_void *dua_handler);

pps_s32 dua_update_startup_log(pps_void);

pps_s32 dua_finish_startup_log(pps_void *dua_handler);

pps_s32 dua_get_abnormal_boot_info(pps_void *dua_handler, int *count, char *logbuf, size_t size);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_START_LOG_H_ */
