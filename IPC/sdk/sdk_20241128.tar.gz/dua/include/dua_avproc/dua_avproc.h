/**
 * @file        dua_avproc.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       智能模块
 * @author      Shi Yanlin
 * @date        2023/03/11
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_AVPROC_H_
#define _DUA_AVPROC_H_

#include "dua_common.h"
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_void *dua_avproc_init(pps_void *dua_handler, DUA_AVPROC_CFG_PTR avproc_cfg);
 * @brief   <avproc init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] type       : type
 * @return  NULL - failure | else - success return avproc handler
 * @note    battery device not support to init DUA_AVPROC_MOTION_DETECTION avproc by using this methods
 *          check dua_sensor_pir_init methods
 */
pps_void *dua_avproc_init(pps_void *dua_handler, DUA_AVPROC_CFG_PTR avproc_cfg);

/** @fn      pps_s32 dua_avproc_deinit(pps_void *avproc_handler, pps_s32 sensor_nums);
 * @brief   <avproc deinit>
 * @param   [in] avproc_handler: avproc handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_deinit(pps_void *avproc_handler, pps_s32 sensor_nums);

/** @fn      pps_s32 dua_avproc_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <event callback register>
 * @param   [in] event_cb: event callback
 * @return  0 - success | else - failure
 * @note    DUA_EVENT_AVPROC_MD_IN_GIRD_ALARM   = 0x4000, //Motion detection alarm in the area
 *          DUA_EVENT_AVPROC_MD_IN_VISION_ALARM = 0x4001, //Motion detection alarm in field of view
 *          DUA_EVENT_AVPROC_PD_IN_GIRD_ALARM   = 0x4010, //Humanoid detection alarm in the area
 *          DUA_EVENT_AVPROC_PD_IN_VISION_ALARM = 0x4011, //Humanoid detection alarm in the field of vision
 *          DUA_EVENT_AVPROC_BCD_ALARM          = 0x4020, //Crying detection alarm
 *          DUA_EVENT_AVPROC_NOISE_ALARM        = 0x4030, //Noise decibel detection alarm
 *          DUA_EVENT_AVPROC_MD_TRACKING        = 0x4100, //Motion tracking
 *          DUA_EVENT_AVPROC_PD_TRACKING        = 0x4101, //Humanoid tracking
 */
pps_s32 dua_avproc_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_avproc_start(pps_void *avproc_handler, pps_s32 start, pps_s32 sensor_id);
 * @brief   <single model single avproc enable/disable>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] start         : 0 - stop | 1 - start
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_start(pps_void *avproc_handler, pps_s32 start, pps_s32 sensor_id);

/** @fn      pps_s32 dua_avproc_enable(pps_void *avproc_handler, pps_s32 enable, pps_s32 sensor_id);
 * @brief   <single model single avproc enable/disable>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] enable        : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_enable(pps_void *avproc_handler, pps_s32 enable, pps_s32 sensor_id);

/** @fn      pps_s32 dua_avproc_multi_enable(pps_void *avproc_handler, pps_s32 enable, pps_s32 sensor_id);
 * @brief   <single model multi avproc enable/disable>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] enable        : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_multi_enable(pps_void *avproc_handler, pps_s32 enable, pps_s32 sensor_id);

/** @fn      pps_s32 dua_avproc_set_detect_zone(pps_void *avproc_handler, pps_s32 zone_type, pps_void *zone, pps_s32 len, pps_s32 sensor_id);
 * @brief   <set people/motion detect zone info>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] zone_type     : detect zone type 0 - (int grid[144] 9 * 16 storage row data first)
 * @param   [in] zone          : detect zone info
 * @param   [in] len           : detect zone info length
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_set_detect_zone(pps_void *avproc_handler, pps_s32 zone_type, pps_void *zone, pps_s32 len, pps_s32 sensor_id);

/** @fn      pps_s32 dua_avproc_set_detect_sensitivity(pps_void *avproc_handler, pps_s32 value, pps_s32 sensor_id);
 * @brief   <set people/motion/nosie detect value>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] value         : people/motion detect sensitivity or noisy decibel
 * @return  0 - success | else - failure
 * @note    for people/motion detection, value means sensitivity 1: low level | 2: mid level | 3: high level
 * @note    for noise detection, value means decibel
 */
pps_s32 dua_avproc_set_detect_sensitivity(pps_void *avproc_handler, pps_s32 value, pps_s32 sensor_id);

/** @fn      pps_s32 dua_avproc_single_detect(pps_void *avproc_handler, pps_s32 sensor_id, pps_void *avbuf, pps_u32 buflen, pps_u8 *result);
 * @brief   <single model single avproc signle detect>
 * @param   [in] avproc_handler: avproc handler
 * @param   [in] avbuf         : detection resource data
 * @param   [in] buflen        : detection resource data's length
 * @param   [out] result       : detection result, 0: no result | 1: have result
 * @return  0 - success | else - failure
 */
pps_s32 dua_avproc_single_detect(pps_void *avproc_handler, pps_s32 sensor_id, pps_void *avbuf, pps_u32 buflen, pps_u8 *result);


#ifdef __cplusplus
}
#endif
#endif /* _DUA_AVPROC_H_ */
