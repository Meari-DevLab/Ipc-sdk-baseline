/**
 * @file        dua_event_def.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua event
 * @author      Shi Yanlin
 * @date        2023/03/10
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_FIRMWARE_HEADER_DEF_H_
#define _DUA_FIRMWARE_HEADER_DEF_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define UPGRADE_FIRMWARE_MAGIC (0x5354524e)

typedef struct device_upgrade_sensor_file_info {
    pps_char name[32];
    pps_u32  offset;
    pps_u32  size;
} DEVICE_UPGRADE_SENSOR_FILE_INFO_T, *DEVICE_UPGRADE_SENSOR_FILE_INFO_PTR;

typedef struct device_upgrade_sensors_file_header {
    pps_u32                           magic_num;
    pps_u32                           sensor_num;
    DEVICE_UPGRADE_SENSOR_FILE_INFO_T sensor_info[5];
    pps_char                          res[14];
} DEVICE_UPGRADE_SENSORS_FILE_HEADER_T, *DEVICE_UPGRADE_SENSORS_FILE_HEADER_PTR;

typedef struct dua_upgrade_info {
    pps_s32 mtd_index;               // 当前升级的分区
    pps_u32 file_write_size;         // 当前刷写的升级文件大小
    pps_u32 upgrade_file_write_size; // 刷写分区文件总大小
} DUA_UPGRADE_INFO_T, *DUA_UPGRADE_INFO_PTR;

/** @struct device_upgrade_file_header
 * @brief  <升级包文件头>
 */
typedef struct device_upgrade_file_header_v2 { /* 128 bytes */
    pps_u32  magic_number;                     /* 0x5354524e */
    pps_u8   file_name[96];
    pps_u8   major_version;    /* 0-256 */
    pps_u8   minor_version;    /* 0-256 */
    pps_u8   revision_version; /* 0-256 */
    pps_u8   res;
    pps_u32  offset;
    pps_u32  file_len;
    pps_u32  checksum;
    pps_char res2[12];
} DEVICE_UPGRADE_FILE_HEADER_V2_T, *DEVICE_UPGRADE_FILE_HEADER_V2_PTR;

/** @struct device_firmware_header
 * @brief  <固件包头>
 * @note   南向版本统一固件包头
 */
typedef struct device_firmware_header_v2 {            /* 64 bytes */
    pps_u32                         magic_number;     /* 0x5354524e */
    pps_u32                         header_check_sum; /* header check sum, from 12Bytes to (header_length - 12) Bytes */
    pps_u32                         header_length;    /* == firmwareHeader_t + N * upgrade_file_header_t */
    pps_u32                         file_nums;
    pps_u32                         language;
    pps_u32                         device_class;
    pps_u32                         oem;
    pps_u8                          version;          /* firmware format version: orignal=0xff, version 1: */
    pps_u8                          major_version;    /* 0-256 */
    pps_u8                          minor_version;    /* 0-256 */
    pps_u8                          revision_version; /* 0-256 */
    pps_u16                         platform_id;      /* enum platform: c2/c4/a2/b2/b21/b3, 防变砖, factory: tuya/meari/, 防串货  */
    pps_u16                         application_id;   /* enum */
    pps_u16                         factory_id;       /* enum */
    pps_u16                         res0;
    pps_u8                          debug;   /* for developer, bit0=允许降级升级 */
    pps_u8                          res[23]; /* 可以扩展成：Flash信息|内存信息|产品主类型|设备次类型|区域（语言）信息 */
    DEVICE_UPGRADE_FILE_HEADER_V2_T file_header[0];
} DEVICE_FIRMWARE_HEADER_V2_T, *DEVICE_FIRMWARE_HEADER_V2_PTR;

/** @struct device_upgrade_mcu_bin_header
 * @brief  <mcu固件包头>
 * @note   低功耗固件包头
 */

typedef struct device_upgrade_mcu_bin_header {
    pps_u32 magic;
    pps_u32 check_sum;
    pps_u32 head_size;
    pps_u32 date_size;
    pps_u8  version[64];
    pps_u32 dev_type; // 0-snap, 1-bell
    pps_u32 packver;
    pps_u8  res[40];
} DEVICE_UPGRADE_MCU_BIN_HEADER_T, *DEVICE_UPGRADE_MCU_BIN_HEADER_PTR;

#ifdef __cplusplus
}
#endif
#endif /* _DUA_EVENT_DEF_H_ */