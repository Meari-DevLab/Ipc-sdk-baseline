/**
 * @file        dua_media.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       media functions
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_MEDIA_H_
#define _DUA_MEDIA_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_media_init(pps_void *dua_handler, DUA_MEDIA_INIT_CFG_PTR init_cfg);
 * @brief   <media init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] init_cfg   : init config
 * @param   [in] audio_cfg  : audio config
 * @param   [in] sensor_cfg : sensor config
 * @param   [in] sensor_num : sensor number
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_init(pps_void *dua_handler, DUA_MEDIA_INIT_CFG_PTR init_cfg, DUA_MEDIA_AUDIO_INIT_CFG_PTR audio_cfg,
                       DUA_MEDIA_SENSOR_INIT_CFG_PTR sensor_cfg, pps_s32 sensor_num);

/** @fn      pps_s32 dua_media_deinit(pps_void *dua_handler);
 * @brief   <media deinit>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_deinit(pps_void *dua_handler);

/** @fn      pps_s32 dua_media_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <register media event>
 * @param   [in] dua_handler: dua handler
 * @param   [in] event_cb   : event callback
 * @return  0 - success | else - failure
 * @note    DUA_EVENT_MEDIA_DAY_NIGHT_SWITCHED  = 0x4500, //Day and night switching with parameters: DUA_DAYNIGHT_EVENT_INFO_PTR
 */
pps_s32 dua_media_event_register(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_media_event_unregister(pps_void *dua_handler, dua_event_callback_f event_cb);
 * @brief   <unregister media event>
 * @param   [in] dua_handler: dua handler
 * @param   [in] event_cb   : event callback
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_event_unregister(pps_void *dua_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_media_register_avstream(pps_s32 channel, dua_media_avstream_cb callback, pps_void *context);
 * @brief   <audio/video stream register>
 * @param   [in] channel : stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] callback: callback
 * @param   [in] context : default NULL
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_register_avstream(pps_s32 channel, dua_media_avstream_cb callback, pps_void *context);

/** @fn      pps_s32 dua_media_unregister_avstream(pps_s32 channel, dua_media_avstream_cb callback);
 * @brief   <audio/video stream unregister>
 * @param   [in] channel : stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] callback: callback
 * @param   [in] context : default NULL
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_unregister_avstream(pps_s32 channel, dua_media_avstream_cb callback);

/** @fn      pps_s32 dua_media_video_get_stream_info(pps_s32 channel, DUA_VIDEO_STREAM_INFO_PTR stream_info);
 * @brief   <get video stream info>
 * @param   [in]  channel    : stream channel DUA_STREAM_CHANNEL_E
 * @param   [out] stream_info: video stream info
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_get_stream_info(pps_s32 channel, DUA_VIDEO_STREAM_INFO_PTR stream_info);

/** @fn      pps_s32 dua_media_audio_get_stream_info(pps_s32 channel, DUA_AUDIO_STREAM_INFO_PTR stream_info);
 * @brief   <get audio stream channel>
 * @param   [in]  channel    : stream channel DUA_STREAM_CHANNEL_E
 * @param   [out] stream_info: audio stream info
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_audio_get_stream_info(pps_s32 channel, DUA_AUDIO_STREAM_INFO_PTR stream_info);

/** @fn      pps_s32 dua_media_video_force_iframe(pps_s32 channel);
 * @brief   <video stream force I frame>
 * @param   [in] channel: stream channel DUA_STREAM_CHANNEL_E
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_force_iframe(pps_s32 channel);

/** @fn     pps_s32 media_video_set_resolution(pps_s32 channel, DUA_VIDEO_RESOLUTION_E type);
 * @brief   <set video resolution>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] type   : video stream resolution type
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_resolution(pps_s32 channel, DUA_VIDEO_RESOLUTION_E type);

/** @fn      pps_s32 dua_media_video_set_encode_type(pps_s32 channel, DUA_VIDEO_TYPE_E type);
 * @brief   <get video stream encode type>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] type   : video stream encode type
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_encode_type(pps_s32 channel, DUA_VIDEO_TYPE_E type);

/** @fn      pps_s32 dua_media_video_get_img_quality(pps_s32 channel, DUA_VIDEO_QUALITY_E *ex_level);
 * @brief   <set img quality level>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [out] ex_level    : the origin level to restore
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_get_img_quality(pps_s32 channel, DUA_VIDEO_QUALITY_E *ex_level);

/** @fn      pps_s32 dua_media_video_set_img_quality(pps_s32 channel, DUA_VIDEO_QUALITY_E set_level);
 * @brief   <set img quality level>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] set_level    : level used to set
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_img_quality(pps_s32 channel, DUA_VIDEO_QUALITY_E set_level);

/** @fn      pps_s32 dua_media_video_set_bitrate_adjust(pps_s32 channel, pps_s32 level);
 * @brief   <set video stream level>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] level    : level
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_bitrate_adjust(pps_s32 channel, pps_s32 level);

/** @fn      pps_s32 dua_media_video_set_frame_rate(pps_s32 channel, pps_s32 fps);
 * @brief   <set video stream fps>
 * @param   [in] channel: video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] fps    : frame rate
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_frame_rate(pps_s32 channel, pps_s32 fps);

/** @fn      pps_s32 dua_media_video_set_bit_rate(pps_s32 channel, DUA_VIDEO_BITRATE_TYPE_E type, pps_s32 bit_rate);
 * @brief   <set video stream bit rate>
 * @param   [in] channel : video stream channel DUA_STREAM_CHANNEL_E
 * @param   [in] type    : type CBR or VBR
 * @param   [in] bit_rate: bit rate
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_bit_rate(pps_s32 channel, DUA_VIDEO_BITRATE_TYPE_E type, pps_s32 bit_rate);

/** @fn      pps_s32 dua_media_video_set_image_param(DUA_VIDEO_IMAGE_PARAM_PTR image_param);
 * @brief   <set image parameter>
 * @param   [in] sensor_id  : sensor id DUA_SENSOR_ID_E
 * @param   [in] image_param: set image parameter
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_image_param(pps_s32 sensor_id, DUA_VIDEO_IMAGE_PARAM_PTR image_param);

/** @fn      pps_s32 dua_media_video_set_image_flip_mirror_type(DUA_IMGAE_FLIP_MIRROR_PARAM_PTR flip_mirror_param);
 * @brief   <set image flip mirror>
 * @param   [in] sensor_id        : sensor id DUA_SENSOR_ID_E
 * @param   [in] flip_mirror_param: flip mirror parameter
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_image_flip_mirror_type(pps_s32 snesor_id, DUA_IMGAE_FLIP_MIRROR_PARAM_PTR flip_mirror_param);

/** @fn      pps_s32 dua_media_video_snapshot(pps_s32 type, pps_char *buffer, pps_s32 *len);
 * @brief   <抓图>
 * @param   [in] sensor_id: sensor id DUA_SENSOR_ID_E
 * @param   [in]    type  : type 0 - noramal | 1 - fastshot
 * @param   [in]    buffer: image buffer addr, buffer need malloc by user
 * @param   [inout] len   : in - malloc buffer size, out - snapshot picture size
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_snapshot(pps_s32 sensor_id, pps_s32 type, pps_char *buffer, pps_s32 *len);

/** @fn      pps_s32 dua_media_video_set_antiflicker_mode(DUA_ANTIFLICKER_MODE_E mode);
 * @brief   <set antiflicker mode>
 * @param   [in] sensor_id  : sensor id DUA_SENSOR_ID_E
 * @param   [in] mode: antiflicker mode
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_set_antiflicker_mode(pps_s32 sensor_id, DUA_ANTIFLICKER_MODE_E mode);

/** @fn      pps_s32 dua_media_video_set_antiflicker_mode(DUA_ANTIFLICKER_MODE_E *mode);
 * @brief   <get antiflicker mode>
 * @param   [in] sensor_id  : sensor id DUA_SENSOR_ID_E
 * @param   [out] mode: antiflicker mode
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_video_get_antiflicker_mode(pps_s32 sensor_id, DUA_ANTIFLICKER_MODE_E *mode);

/** @fn      pps_s32 dua_media_audio_enable_aec(pps_s32 enable);
 * @brief   <eco cancel enable switch>
 * @param   [in] enable: 0 - diabel | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_audio_enable_aec(pps_s32 enable);

/** @fn      pps_s32 dua_media_audio_is_aec_enable(pps_s32 *enable);
 * @brief   <eco cancel enable switch status>
 * @param   [out] enable: 0 - diabel | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_audio_is_aec_enable(pps_s32 *enable);

/** @fn      pps_s32 dua_media_microphone_enable(pps_s32 *enable);
 * @brief   <set microphone enable>
 * @param   [in] enable: 0 - diabel | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_microphone_enable(pps_s32 enable);

/** @fn      pps_s32 dua_media_microphone_set_volume(pps_u32 volume);
 * @brief   <set microphone volume>
 * @param   [in] volume: volume 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_microphone_set_volume(pps_u32 volume);

/** @fn      pps_s32 dua_media_spkear_get_volume(pps_u32 *volume);
 * @brief   <get microphone volume>
 * @param   [out] volume: volume 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_microphone_get_volume(pps_u32 *volume);

/** @fn      pps_s32 dua_media_speaker_init(DUA_AUDIO_TYPE_E audio_type);
 * @brief   <speaker initialization>
 * @param   [in] audio_type: audio type
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_speaker_init(DUA_AUDIO_TYPE_E audio_type);

/** @fn      pps_s32 dua_media_speaker_set_volume(pps_u32 volume);
 * @brief   <set speaker volume>
 * @param   [in] volume: volume 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_speaker_set_volume(pps_u32 volume);

/** @fn      pps_s32 dua_media_speaker_get_volume(pps_u32 *volume);
 * @brief   <get speaker volume>
 * @param   [out] volume: volume 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_speaker_get_volume(pps_u32 *volume);

/** @fn      pps_s32 (DUA_SPEAKER_AUDIO_DATA_PTR data);
 * @brief   <play audio by buffer data>
 * @param   [in] data: audio data
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_speaker_play_buffer(DUA_SPEAKER_AUDIO_DATA_PTR data);

/** @fn      pps_s32 dua_media_clear_speaker_buffer(pps_void *dua_handler);
 * @brief   <clear play buffer>
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_clear_speaker_buffer(pps_void);

/** @fn      pps_s32 dua_media_osd_enable(DUA_STREAM_CHANNEL_E channel, pps_s32 enable);
 * @brief   <OSD enable/disable>
 * @param   [in] channel: only video channel
 * @param   [in] enable : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_osd_enable(DUA_STREAM_CHANNEL_E channel, pps_s32 enable);

/** @fn      pps_s32 dua_media_configure_osd(DUA_STREAM_CHANNEL_E channel, DUA_OSD_CONFIG_PTR osd_config);
 * @brief   <set osd configure>
 * @param   [in] channel   : only video channel
 * @param   [in] osd_config: osd configure
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_configure_osd(DUA_STREAM_CHANNEL_E channel, DUA_OSD_CONFIG_PTR osd_config);

/** @fn      pps_s32 dua_media_get_osd_configuration(DUA_STREAM_CHANNEL_E channel, DUA_OSD_CONFIG_PTR osd_config, pps_s32 *enable);
 * @brief   <get osd configure>
 * @param   [in]  channel   : only video channel
 * @param   [out] osd_config: osd configure
 * @param   [out] enable    : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_get_osd_configuration(DUA_STREAM_CHANNEL_E channel, DUA_OSD_CONFIG_PTR osd_config, pps_s32 *enable);

/** @fn      pps_s32 dua_media_logo_enable(DUA_STREAM_CHANNEL_E channel, pps_s32 enable);
 * @brief   <logo enable/disable>
 * @param   [in] channel: only video channel
 * @param   [in] enable : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_logo_enable(DUA_STREAM_CHANNEL_E channel, pps_s32 enable);

/** @fn      pps_s32 dua_media_configure_logo(DUA_STREAM_CHANNEL_E channel, DUA_LOGO_CONFIG_PTR logo_config);
 * @brief   <set logo configure>
 * @param   [in] channel    : only video channel
 * @param   [in] logo_config: logo configure
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_configure_logo(DUA_STREAM_CHANNEL_E channel, DUA_LOGO_CONFIG_PTR logo_config);

/** @fn      pps_s32 dua_media_get_logo_configuration(DUA_STREAM_CHANNEL_E channel, DUA_LOGO_CONFIG_PTR logo_config, pps_s32 *enable);
 * @brief   <get logo configure>
 * @param   [in]  channel    : only video channel
 * @param   [out] logo_config: osd configure
 * @param   [out] enable     : 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_get_logo_configuration(DUA_STREAM_CHANNEL_E channel, DUA_LOGO_CONFIG_PTR logo_config, pps_s32 *enable);

/** @fn      pps_s32 dua_media_set_daynight_mode(DUA_DAYNIGHT_MODE_E mode);
 * @brief   <set day night mode>
 * @param   [in] sensor_id  : sensor id DUA_SENSOR_ID_E (Media multi-sensors are set at the same time, and it will not take effect for now)
 * @param   [in] mode: day night mode
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_set_daynight_mode(pps_s32 sensor_id, DUA_DAYNIGHT_MODE_E mode);

/** @fn      pps_s32 dua_media_get_daynight_mode(DUA_DAYNIGHT_MODE_E *mode);
 * @brief   <get day night mode>
 * @param   [in]  sensor_id  : sensor id DUA_SENSOR_ID_E (Media multi-sensors are set at the same time, and it will not take effect for now)
 * @param   [out] mode: day night mode
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_get_daynight_mode(pps_s32 sensor_id, DUA_DAYNIGHT_MODE_E *mode);

/** @fn      pps_s32 dua_media_get_daynight_status(pps_s32 *is_night);
 * @brief   <get ircut status>
 * @param   [in]  sensor_id  : sensor id DUA_SENSOR_ID_E (Media multi-sensors are set at the same time, and it will not take effect for now)
 * @param   [out] is_day: day night status   0 - day | 1 - night
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_get_daynight_status(pps_s32 sensor_id, pps_s32 *is_night);

/** @fn      pps_s32 dua_media_set_intelligent_mode(pps_s32 mode);
 * @brief   <set intelligent_mode>
 * @param   [in] sensor_id  : sensor id DUA_SENSOR_ID_E (TMedia multi-sensors are set at the same time, and it will not take effect for now)
 * @param   [in] mode: intelligent_mode  Reference enum DUA_DAYNIGHT_MODE_PROC_E
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_set_intelligent_mode(pps_s32 sensor_id, pps_s32 mode);

/** @fn      pps_s32 dua_qrcode_scanner_enable(pps_s32 enable);
 * @brief   <qrcode scanner enable/disable>
 * @param   [in] enable: 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_qrcode_scanner_enable(pps_s32 enable);

/** @fn      pps_s32 dua_qrcode_scanner_is_enable(pps_s32 *enable);
 * @brief   <is scanner enable/disable>
 * @param   [out] enable: 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_qrcode_scanner_is_enable(pps_s32 *enable);

/** @fn      pps_void dua_register_qrcode_data_process_cb(dua_qrcode_get_result_cb cb);
 * @brief   <register scanner result callback >
 * @param   [in] cb: scanner result callback
 * @return  0 - success | else - failure
 */
pps_void dua_register_qrcode_data_process_cb(pps_void *dua_handler, dua_qrcode_get_result_cb cb);

/** @fn      pps_void media_get_version(pps_char *version, pps_s32 len);
 * @brief   <get media version >
 * @param   [in] version string reserve
 * @return
 */
pps_void dua_media_get_version(pps_char *version, pps_s32 len);

/** @fn      pps_void dua_media_get_init_status(pps_s32 *state);
 * @brief   <get media version >
 * @param   [out] state 1 - Initialized | 0 - Uninitialized
 * @return
 */
pps_void dua_media_get_init_status(pps_void *dua_handler, pps_s32 *state);

/** @fn      dua_media_aov_mode_entry(pps_s32* wkup_mode);
 * @brief   <entry aov mode>
 * @return
 */
pps_s32 dua_media_aov_mode_entry(pps_void);

/** @fn      dua_media_aov_mode_exit(pps_void);
 * @brief   <exit aov mode>
 * @return
 */
pps_s32 dua_media_aov_mode_exit(pps_void);

/** @fn      media_aov_mode_suspend(pps_s32 fps, DUA_MEDIA_WAKEUP_MODE_E *wakeup_mode);
 * @brief   <system suupend in aov mode>
 * @param   [in] fps: set frame rate
 * @param   [out] wakeup_mode: get wakeup mode
 * @return  0 - success | else - failure
 * @note
 */
pps_s32 dua_media_aov_mode_suspend(pps_s32 fps, DUA_MEDIA_WAKEUP_MODE_E *wakeup_mode);

/** @fn      pps_s32 dua_media_aov_get_avstream(pps_s32 channel, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 *len);
 * @brief   <get one audio/video frame>
 * @param   [in] channel : stream channel DUA_STREAM_CHANNEL_E
 * @param   [out] header: frame information
 * @param   [out] data : frame buffer
 * @param   [inout] len : frame buffer's length
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_aov_get_avstream(pps_s32 channel, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 *len);

/** @fn      pps_s32 dua_set_media_log_level(pps_s32 loglevel)
 * @brief   <set meida log level>
 * @param   [in] loglevel : stream channel DUA_MEDIA_PRT_LEVEL_E
 * @return  0 - success | else - failure
 */
pps_s32 dua_set_media_log_level(DUA_MEDIA_PRT_LEVEL_E loglevel);

/** @fn      pps_s32 dua_media_aac_clean_data(pps_void)
 * @brief   <clean aac buffer>
 * @return  0 - success | else - failure
 */
pps_s32 dua_media_aac_clean_data(pps_void);

#ifdef __cplusplus
}
#endif

#endif /* _DUA_MEDIA_H_ */
