/**
 * @file        dua_acodec_fdkaac_codec.h
 *
 * @copyright   2024 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      liping
 *
 * @date        2024/04/09
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __DUA_ACODEC_FDKAAC_CODEC_H
#define __DUA_ACODEC_FDKAAC_CODEC_H

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AAC_PACKET_MAX_SIZE (2048)

typedef struct dua_acodec_fdkaac_encode {
    pps_char *in_buf;                      // Need to encode audio data
    pps_s32 in_buf_size;                    // in_buf length
    pps_char out_buf[AAC_PACKET_MAX_SIZE];  // Encoded audio data
    pps_s32 out_buf_size;                   // Encoded audio data size
}DUA_ACODEC_FDKAAC_ENCODE_T, *DUA_ACODEC_FDKAAC_ENCODE_PTR;

typedef struct dua_acodec_fdkaac_decode {
    pps_char *in_buff;                          // Decoded audio data
    pps_u32 in_buff_len;                        // Decoded audio data len
    pps_char *out_buff;                         // Output pcm audio
    pps_u32 out_buff_len;                       // Output pcm audio len
}DUA_ACODEC_FDKAAC_DECODE_T, *DUA_ACODEC_FDKAAC_DECODE_PTR;

/** @fn      pps_s32 dua_fdkaac_enc_init(pps_s32 sample_rate);
 * @brief   <fdk aac encode init>
 * @param   [in] sample_rate: The audio sampling rate to be encoded;
 * @return  0 - succeed | -1 - fail
 */
pps_s32 dua_fdkaac_enc_init(pps_s32 sample_rate);

/** @fn      pps_s32 dua_fdkaac_enc_deinit(pps_void);
 * @brief   <fdk aac encode deinit>
 * @return  0 - succeed | -1 - fail
 */
pps_s32 dua_fdkaac_enc_deinit(pps_void);

/** @fn      pps_s32 dua_fdkaac_enc_init(pps_s32 sample_rate);
 * @brief   <fdk aac encode>
 * @param   [in] encode_info: encode audio info;
 * @return  encode len - succeed | minus - fail
 */
pps_s32 dua_fdkaac_encode(DUA_ACODEC_FDKAAC_ENCODE_PTR encode_info);

/** @fn      pps_s32 dua_fdkaac_dec_init(pps_void);
 * @brief   <fdk aac decode init>
 * @return  0 - succeed | -1 - fail
 */
pps_s32 dua_fdkaac_dec_init(pps_void);

/** @fn      pps_s32 dua_fdkaac_dec_deinit(pps_void);
 * @brief   <fdk aac decode deinit>
 * @return  0 - succeed | -1 - fail
 */
pps_s32 dua_fdkaac_dec_deinit(pps_void);

/** @fn      pps_s32 dua_fdkaac_dec_deinit(pps_void);
 * @brief   <fdk aac decode deinit>
 * @param   [in] encode_info: decode audio info;
 * @return   < 0 - output audio data size | -1 - fail
 */
pps_s32 dua_fdkaac_decode(DUA_ACODEC_FDKAAC_DECODE_PTR decode_info);

/** @fn      dua_fdkaac_audio_resample_s16(const pps_s16 *src, pps_s32 src_count, pps_s32 src_samplerate,
                                  pps_s16 *dst, pps_s32 *dst_count, pps_s32 dst_samplerate);
 * @brief   <pcm audio resample>
 * @param   [in] src: pcm audio;
 * @param   [in] src_count: pcm audio data len;
 * @param   [in] src_samplerate: pcm audio samplerate;
 * @param   [in] dst:resample pcm audio;
 * @param   [in] dst_count:resample pcm audio data len;
 * @param   [in] dst_samplerate:resample pcm audio samplerate;
 * @return  encode len - succeed | minus - fail
 */
pps_s32 dua_fdkaac_audio_resample_s16(const pps_s16 *src, pps_s32 src_count, pps_s32 src_samplerate,
                                  pps_s16 *dst, pps_s32 *dst_count, pps_s32 dst_samplerate);

#ifdef __cplusplus
}
#endif
#endif /* __DUA_ACODEC_FDKAAC_CODEC_H */


