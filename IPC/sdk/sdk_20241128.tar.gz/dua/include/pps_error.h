/**
 * @file        pps_error.h
 *
 * @copyright   2022 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      liping
 *
 * @date        2022/09/14
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __PPS_ERROR_H
#define __PPS_ERROR_H

#ifdef __cplusplus
extern "C" {
#endif

#define PPS_SUCCESS     (0) // suceess
#define PPS_ERR_SUCCESS (0) // suceess

/* 扩展错误码 */
/* 通用 */
#define PPS_ERR_FAIL       (-0x0010001) // general failed
#define PPS_ERR_MALLOCFAIL (-0x0010002)
#define PPS_ERR_INVALARG   (-0x0010003) /* invalid argument */
#define PPS_ERR_OPENFAIL   (-0x0010004) /* device or resource open failed */
#define PPS_ERR_READFAIL   (-0x0010005) /* device or resource read failed */
#define PPS_ERR_WRITEFAIL  (-0x0010006) /* device or resource write failed */
#define PPS_ERR_DELFAIL    (-0x0010007) /* device or resource delete failed */
#define PPS_ERR_NOTSUPPORT (-0x0010008)

#define PPS_ERR_INNER    (-0x0010009) /* internal error */
#define PPS_ERR_POINTER  (-0x001000A) /* invalid pointer */
#define PPS_ERR_NOTINIT  (-0x001000B) /* object not init */
#define PPS_ERR_INITFAIL (-0x001000C) /* object init failed */
#define PPS_ERR_NOTEXIST (-0x001000D) /* object not exist */
#define PPS_ERR_FULL     (-0x001000E) /* device or resource full */
#define PPS_ERR_EMPTY    (-0x001000F) /* device or resource empty */

#define PPS_ERR_NOTIMPL (-0x0010010)

#define PPS_ERR_OUTOFMEM (-0x0010011) /* out of memory */
#define PPS_ERR_BUFERROR (-0x0010012) /* buffer error */
// #define PPS_ERR_PERM                        (-0x0010013) /* permission denied */
#define PPS_ERR_TIMEOUT (-0x0010014) /* time out */
#define PPS_ERR_ALREADY (-0x0010015) /* operation already in progress */
// #define PPS_ERR_INPROGRESS                  (-0x0010016) /* operation now in progress */
#define PPS_ERR_EXIST (-0x0010015) /* object exist */
#define PPS_ERR_BUSY  (-0x0010017) /* device or resource busy */
// #define PPS_ERR_NOT_EXIST                   (-0x0010018)
#define PPS_ERR_DISABLE (-0x0010019) /* disable */

/* 消息队列 */
#define PPS_ERR_MQUEUE_CREATE_FAIL       (-0x0010100) /* mqueue create fail */
#define PPS_ERR_MQUEUE_DELETE_FAIL       (-0x0010101) /* mqueue delete fail */
#define PPS_ERR_MQUEUE_SEND_FAIL         (-0x0010102) /* mqueue send fail */
#define PPS_ERR_MQUEUE_WAIT_FAIL         (-0x0010103) /* mqueue wait fail */
#define PPS_ERR_MQUEUE_INVALID_PARAMETER (-0x0010104)

/* 录像组件 */
#define PPS_ERR_RECORD_LIST_EMPTY        (-0x0010200)
#define PPS_ERR_RECORD_IO_SPACE_ERROR    (-0x0010201)
#define PPS_ERR_RECORD_INVALID_PARAMETER (-0x0010202)

/* thread */
#define PPS_ERR_THREAD_CREATE_FAIL       (-0x0010300) /* thread create fail */
#define PPS_ERR_THREAD_INVALID_PARAMETER (-0x0010301)

/* data check */
#define PPS_ERR_DATE_CHECK_FAIL (-0x0010400) /* data check fail */

/* config */
#define PPS_ERR_FIRST_READ_CFG       (-0x0010500)   // suceess
#define PPS_ERR_CFG_PARTITION_BROKEN (-0x0010501)   /* all the usr_partitions are broken */

/**upgrade*/
#define PPS_ERR_UPGRADE_FIRM_HANDER_FAIL        (-0x0010600) //
#define PPS_ERR_UPGRADE_FIRM_READ_FAIL          (-0x0010601) //
#define PPS_ERR_UPGRADE_FIRM_WRITE_FAIL         (-0x0010602) //
#define PPS_ERR_UPGRADE_VERSION_WRITE_FAIL      (-0x0010603) //
#define PPS_ERR_UPGRADE_NO_UPGREADE_REQUIRED    (-0x0010604) //
#define PPS_ERR_UPGRADE_FIRM_VALIDATION_FAIL    (-0x0010605) // verify_rsa_signature or checksum error

/* PTZ组件 */
#define PPS_ERR_PTZ_NEED_CALIBRATION       (-0x0010700)
#define PPS_ERR_PTZ_TIME_CHECK_INTERRUPTED (-0x0010701)


#ifdef __cplusplus
}
#endif
#endif /* __PPS_ERROR_H */
