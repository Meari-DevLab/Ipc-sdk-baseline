/**
 * @file        pps_osal_mutex.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer mutex module
 *
 * @author      jim
 *
 * @date        2020/3/24
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef _PPS_OSAL_MUTEX_H_
#define _PPS_OSAL_MUTEX_H_

#include "pps_osal_type.h"
#include "pps_osal_errno.h"
#include "pps_osal_define.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef CONFIG_POSIX
#include <pthread.h>
#define pps_mutex_t           pthread_mutex_t
#define PPS_MUTEX_INITIALIZER PTHREAD_MUTEX_INITIALIZER

static inline int pps_mutex_init(pps_mutex_t *mutex)
{
    return pthread_mutex_init(mutex, NULL);
}

static inline int pps_mutex_destroy(pps_mutex_t *mutex)
{
    return pthread_mutex_destroy(mutex);
}

static inline int pps_mutex_lock(pps_mutex_t *mutex)
{
    return pthread_mutex_lock(mutex);
}

static inline int pps_mutex_trylock(pps_mutex_t *mutex)
{
    return pthread_mutex_trylock(mutex);
}

static inline int pps_mutex_timedlock(pps_mutex_t *mutex, int timeout_ms)
{
    return -PPS_OSAL_ERROR_NOTSUPPORT;
}

static inline int pps_mutex_unlock(pps_mutex_t *mutex)
{
    return pthread_mutex_unlock(mutex);
}
#else
typedef struct pps_mutex_t {
    void *p;
} pps_mutex_t;

#define PPS_MUTEX_INITIALIZER \
    {                         \
        NULL                  \
    }

typedef struct pps_mutex_attr_t {
    int type; /* reserved, please set it to 0 by default */
} pps_mutex_attr_t;

int pps_mutex_init(pps_mutex_t *mutex);
int pps_mutex_destroy(pps_mutex_t *mutex);
int pps_mutex_lock(pps_mutex_t *mutex);
int pps_mutex_trylock(pps_mutex_t *mutex);
int pps_mutex_timedlock(pps_mutex_t *mutex, int timeout_ms);
int pps_mutex_unlock(pps_mutex_t *mutex);
#endif

#ifdef __cplusplus
}
#endif
#endif /* _PPS_OSAL_MUTEX_H_ */
