/**
 * @file        pps_osal_type.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       int types and print types
 *
 * @author
 *
 * @date        2019/7/5
 *
 * @version     0.1.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_OSAL_TYPE_H_
#define _PPS_OSAL_TYPE_H_

#include "pps_osal_define.h"

#ifdef __cplusplus
extern "C" {
#endif

#define pps_true  1
#define pps_false 0

typedef void pps_void;
typedef int                pps_bool;
typedef unsigned char      pps_u8;
typedef unsigned short     pps_u16;
typedef unsigned int       pps_u32;
typedef unsigned long long pps_u64;
typedef unsigned long      pps_ulong;

typedef char        pps_char;
typedef signed char pps_s8;
typedef short       pps_s16;
typedef int         pps_s32;
typedef long long   pps_s64;
typedef long        pps_slong;

typedef float  pps_float;
typedef double pps_double;

/* 64Bits */
#if CONFIG_PPS_WORDSIZE == 64 || __WORDSIZE == 64
typedef signed long pps_intptr_t;
typedef unsigned long pps_uintptr_t;
typedef unsigned long pps_size_t;
#else /* 32Bits */
typedef int          pps_intptr_t;
typedef unsigned int pps_uintptr_t;
typedef unsigned int pps_size_t;
#endif

/* Please use these macros to replace printf macros */
#if CONFIG_PPS_WORDSIZE == 64
#define PPS_PRIu64 "llu"
#define PPS_PRIu32 "u"
#define PPS_PRIu16 "u"
#define PPS_PRIu8  "u"

#define PPS_PRId64 "lld"
#define PPS_PRId32 "d"
#define PPS_PRId16 "d"
#define PPS_PRId8  "d"

#define PPS_PRIx64 "llx"
#define PPS_PRIx32 "x"
#define PPS_PRIx16 "x"
#define PPS_PRIx8  "x"

#else

#define PPS_PRIu64 "lu"
#define PPS_PRIu32 "u"
#define PPS_PRIu16 "u"
#define PPS_PRIu8  "u"

#define PPS_PRId64 "ld"
#define PPS_PRId32 "d"
#define PPS_PRId16 "d"
#define PPS_PRId8  "d"

#define PPS_PRIx64 "lx"
#define PPS_PRIx32 "x"
#define PPS_PRIx16 "x"
#define PPS_PRIx8  "x"
#endif

#define __PPS_UNUSED__ __attribute__((unused))
#define __PPS_PACKED__ __attribute__((packed))

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_TYPE_H_ */
