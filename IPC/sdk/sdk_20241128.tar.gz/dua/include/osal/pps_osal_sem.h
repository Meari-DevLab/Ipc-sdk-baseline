/**
 * @file        pps_osal_sem.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer semaphore module
 *
 * @author      zxc
 *
 * @date        2020/4/30
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef _PPS_OSAL_SEM_H_
#define _PPS_OSAL_SEM_H_

#include "pps_osal_type.h"
#include "pps_osal_define.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef CONFIG_POSIX
#include <semaphore.h>
#define pps_sem_t sem_t
#else
#define pps_sem_t void *
#endif

/**
 * @brief init semaphore
 *
 * @param sem [IN] pps_sem_t pointer
 *
 * @param value [IN] semaphore value
 *
 * @return 0 on success, -1 on error
 */
int pps_sem_init(pps_sem_t *sem, unsigned int value);

/**
 * @brief wait semaphore
 *
 * @param sem [IN] pps_sem_t pointer
 *
 * @return 0 on success, -1 on error
 */
int pps_sem_wait(pps_sem_t *sem);

/**
 * @brief post semaphore
 *
 * @param sem [IN] pps_sem_t pointer
 *
 * @return 0 on success, -1 on error
 */
int pps_sem_post(pps_sem_t *sem);

/**
 * @brief destroy semaphore
 *
 * @param sem [IN] pps_sem_t pointer
 *
 * @return void
 */
void pps_sem_destroy(pps_sem_t *sem);

/**
 * @brief   try to pend a semaphore,Attention to pps_semaphore_init's brief.
 * @param   sem [IN] the created semaphore
 * @return  on success, return 0. on error, return errno.
 */
pps_s32 pps_sem_trywait(pps_sem_t *sem);

/**
 * @brief   try to pend a semaphore in some time,Attention to pps_semaphore_init's brief.
 * @param   sem [IN] the created semaphore
 * @param   timeout_ms [IN] the timeout in miniseconds
 * @return  on success, return 0. on error, return errno.
 */
pps_s32 pps_sem_timedwait(pps_sem_t *sem, pps_u32 timeout_ms);

#ifdef __cplusplus
}
#endif
#endif /* _PPS_OSAL_SEM_H_ */
