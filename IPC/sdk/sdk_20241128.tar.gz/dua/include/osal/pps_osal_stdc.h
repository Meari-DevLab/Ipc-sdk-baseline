/**
 * @file        pps_osal_stdc.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       standard C APIs List, should only use these listed APIs in your application code.
 *
 * @author      jim
 *
 * @date        2020/5/8
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef _PPS_OSAL_STDC_H_
#define _PPS_OSAL_STDC_H_

/* Suppose all platform support these basic APIs */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

/* imported types and definitions from standard library */

/*
 * Safely used in your application code:
 *   size_t
 *   int
 *   char
 *   void
 *   NULL
 *   STDERR,
 *   STDIN,
 *   STDOUT,
 */

/* imported APIs from standard library */

/*********************************************************************
 * Standard IO APIs List
 *   Note: you can use these APIs directly in your application code.
 */
#if 0
int printf(const char *format, ...);
int sprintf(char *str, const char *format, ...);
int snprintf(char *str, size_t size, const char *format, ...);

int vprintf(const char *format, va_list ap);
int vsprintf(char *str, const char *format, va_list ap);
int vsnprintf(char *str, size_t size, const char *format, va_list ap);

int scanf(const char *format, ...);
int sscanf(const char *str, const char *format, ...);

int vscanf(const char *format, va_list ap);
int vsscanf(const char *str, const char *format, va_list ap);

/* NOTE: mode should always add 'b' */
FILE *fopen(const char *path, const char *mode);
int fclose(FILE *stream);
size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);
#endif

/*********************************************************************
 * String APIs List
 *   Note: you can use these APIs directly in your application code.
 */
#if 0
void *memcpy(void *dest, const void *src, size_t n);
void *memset(void *s, int c, size_t n);
void *memmove(void *dest, const void *src, size_t n);

int memcmp(const void *s1, const void *s2, size_t n);

size_t strlen(const char *s);

/* Unsafe APIs */
char *strcpy(char *dest, const char *src);
/* Recommend to use this API always */
char *strncpy(char *dest, const char *src, size_t n);

char *strcat(char *dest, const char *src);
char *strncat(char *dest, const char *src, size_t n);

int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);

char *strstr(const char *s1, const char *s2);
char *strtok_r(char *s1, const char *s2, char **s3);

char *strchr(const char *s1, int chr);
char *strrchr(const char *s1, int chr);
#endif

/*********************************************************************
 * Memory APIs List
 *  Warnning: Do not use these APIs in your application code,
 *    please use pps_malloc(), pps_free(), pps_calloc() instead,
 */
/*
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);
*/

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_STDC_H_ */
