/**
 * @file        pps_osal_msgq.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer msg queue module
 *
 * @author      zxc
 *
 * @date        2020/4/30
 *
 * @version     0.1.0
 *
 * @note        Something you must take care...
 */

#ifndef __PPS_OSAL_MSGQ_H_
#define __PPS_OSAL_MSGQ_H_

#include "pps_osal_mutex.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct pps_msg_queue_s {
    int pktsiz;
    int nbpkts;
    int head;   /* read pointer, pop */
    int tail;   /* write pointer, push */
    int *pktlen;
    char *buf;
    pps_mutex_t lock;
} pps_msg_queue_t;

/**
 * @brief new a msg queue
 *
 * @param pktsiz [IN] single packet size
 *
 * @param nbpkts [IN] packet count
 *
 * @return pps_msg_queue_t pointer on success, NULL on error
 */
pps_msg_queue_t *pps_msg_queue_new(int pktsiz, int nbpkts);

/**
 * @brief free a msg queue
 *
 * @param q [IN] pps_msg_queue_t pointer
 *
 * @return void
 */
void pps_msg_queue_free(pps_msg_queue_t *q);

/**
 * @brief send packet
 *
 * @param q [IN] send packt address
 * @param q [IN] packt length
 *
 * @return the operation result, 0 on success, other on error
 */
int pps_msg_queue_send(pps_msg_queue_t *q, void *packet, int len);

/**
 * @brief  receive packet
 *
 * @param q [OUT] receive packt address
 * @param q [IN] packt length
 *
 * @return the operation result, 0 on success, other on error
 */
int pps_msg_queue_recv(pps_msg_queue_t *q, void *packet, int len);

/**
 * @brief adjust if msg queue is full
 *
 * @param q [IN] pps_msg_queue_t pointer
 *
 * @return 1 for msg queue is full, 0 for not full
 */
int pps_msg_queue_is_full(pps_msg_queue_t *q);

/**
 * @brief get msg queue packet count used
 *
 * @param q [IN] pps_msg_queue_t pointer
 *
 * @return used count
 */
int pps_msg_queue_get_msg_num(pps_msg_queue_t *q);

/**
 * @brief get msg queue total packet count
 *
 * @param q [IN] pps_msg_queue_t pointer
 *
 * @return total count
 */
int pps_msg_queue_get_msg_total(pps_msg_queue_t *q);

#ifdef __cplusplus
}
#endif

#endif /* __PPS_OSAL_MSGQ_H_ */
