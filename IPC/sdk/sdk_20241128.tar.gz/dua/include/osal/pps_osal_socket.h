/**
 * @file        pps_osal_socket.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       socket abstract layer
 *
 * @author      jim
 *
 * @date        2020/05/27
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_OSAL_SOCKET_H_
#define _PPS_OSAL_SOCKET_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PPS_SOCKET_INADDR_ANY ((pps_u32)0x00000000)

typedef int          pps_socket_t;
typedef int          pps_socket_size_t;
typedef unsigned int pps_socklen_t;

typedef enum PPS_SOCKET_ADDR_FAMILY {
    PPS_SOCKET_AF_INET  = 0, /* IPV4 */
    PPS_SOCKET_AF_INET6 = 1, /* IPV6 */
} PPS_SOCKET_ADDR_FAMILY_E;

typedef enum PPS_SOCKET_TYPE {
    PPS_SOCKET_STREAM,
    PPS_SOCKET_DGRAM,
} PPS_SOCKET_TYPE_E;

typedef enum PPS_SOCKET_PROTOCOL {
    PPS_SOCKET_IPPROTO_TCP,
    PPS_SOCKET_IPPROTO_UDP,
} PPS_SOCKET_PROTOCOL_E;

typedef enum PPS_SOCKET_BLOCK_TYPE {
    PPS_SOCKET_BLOCK,
    PPS_SOCKET_NONBLOCK,
} PPS_SOCKET_BLOCK_TYPE_E;

typedef enum PPS_SOCKET_LEVEL {
    PPS_SOCKET_SOL_SOCKET,
} PPS_SOCKET_LEVEL_E;

typedef enum PPS_SOCKET_OPT {
    PPS_SOCKET_SO_REUSEADDR, /* pps_bool */
    PPS_SOCKET_SO_BROADCAST, /* pps_bool */
    PPS_SOCKET_SO_LINGER,    /* pps_socket_linger_t */
    PPS_SOCKET_SO_KEEPALIVE, /* pps_bool */
    PPS_SOCKET_SO_SNDTIMEO,  /* int, seconds */
    PPS_SOCKET_SO_RCVTIMEO,  /* int, seconds */
    PPS_SOCKET_SO_SNDBUF,    /* int, bytes */
    PPS_SOCKET_SO_RCVBUF,    /* int bytes */
} PPS_SOCKET_OPT_E;

typedef struct pps_sockaddr {
    pps_u16 family; /* see PPS_SOCKET_ADDR_FAMILY_E */
    union {
        char sa_data[14];
        struct {
            pps_u16 port;
            pps_u32 inaddr;
            pps_u8  reserved[8];
        } ipv4;
        /*
        struct {

        } ipv6;
        */
    } saddr;
} pps_sockaddr_t;

typedef struct pps_socket_linger {
    int on_off; /* 1=on, 0=off */
    int linger; /* 0=close TCP immediately, >0=wait kernel to send remaining data, then send RST to peer, timeout equals to linger seconds */
} pps_socket_linger_t;

typedef struct pps_socket_fd_set {
#ifdef CONFIG_RTTHREAD
    pps_u32 fds_bits[128];
#else
    pps_u32 fds_bits[1024 / 8 * sizeof(pps_u32)];
#endif
} pps_fd_set_t;

/**
 * @brief create a socket
 *
 * @param addr_family [IN] addr family in PPS_SOCKET_ADDR_FAMILY_E
 *
 * @param sock_type [IN] scoket type in PPS_SOCKET_TYPE_E
 *
 * @param sock_proto [IN] socket protocol in PPS_SOCKET_PROTOCOL_E
 *
 * @return pps_socket_t pointer on success, NULL on error
 */
pps_socket_t *pps_socket_socket(PPS_SOCKET_ADDR_FAMILY_E addr_family, PPS_SOCKET_TYPE_E sock_type, PPS_SOCKET_PROTOCOL_E sock_proto);

/**
 * @brief close socket
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_close(pps_socket_t *sock);

/**
 * @brief set socket block type
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param type [IN] block type in PPS_SOCKET_BLOCK_TYPE_E
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_set_block_type(pps_socket_t *sock, PPS_SOCKET_BLOCK_TYPE_E type);

/**
 * @brief set socket option
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param socket_level [IN] socket level in PPS_SOCKET_LEVEL_E
 *
 * @param socket_opt [IN] socket option in PPS_SOCKET_OPT_E
 *
 * @param optval [IN] pointer tosocket option value
 *
 * @param len [IN] pointer to socket option value length
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_setsockopt(pps_socket_t *sock, PPS_SOCKET_LEVEL_E socket_level, PPS_SOCKET_OPT_E socket_opt, void *optval, pps_socklen_t len);

/**
 * @brief get socket option
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param socket_level [IN] socket level in PPS_SOCKET_LEVEL_E
 *
 * @param socket_opt [IN] socket option in PPS_SOCKET_OPT_E
 *
 * @param optval [IN] pointer tosocket option value
 *
 * @param len [IN] pointer to socket option value length
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_getsockopt(pps_socket_t *sock, PPS_SOCKET_LEVEL_E socket_level, PPS_SOCKET_OPT_E socket_opt, void *optval, pps_socklen_t *len);

/**
 * @brief receive messages from a socket (TCP)
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param buf [IN] pointer to buffer for the incoming data
 *
 * @param len [IN] receive buffer length
 *
 * @return return bytes received, or other if error occurred
 */
int pps_socket_recv(pps_socket_t *sock, void *buf, pps_socket_size_t len);

/**
 * @brief sends data on a connected socket (TCP)
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param buf [IN] pointer to buffer containing the data to be transmitted
 *
 * @param len [IN] send buffer length
 *
 * @return return bytes sent, or other if error occurred
 */
int pps_socket_send(pps_socket_t *sock, void *buf, pps_socket_size_t len);

/**
 * @brief receive messages from a socket (UDP)
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param buf [IN] pointer to buffer for the incoming data
 *
 * @param len [IN] receive buffer length
 *
 * @param addr [IN] pointer to buffer in pps_sockaddr_t that will hold the source address
 *
 * @param sock_len [IN] pointer to source address length
 *
 * @return return bytes received, or other error occurred
 */
int pps_socket_recvfrom(pps_socket_t *sock, void *buf, pps_socket_size_t len, pps_sockaddr_t *addr, pps_socklen_t *sock_len);

/**
 * @brief sends data to a specific destination (UDP)
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param buf [IN] pointer to buffer containing the data to be transmitted
 *
 * @param len [IN] send data length
 *
 * @param addr [IN] pointer to pps_sockaddr_t that contains the address of the target socket
 *
 * @param sock_len [IN] pointer to address length
 *
 * @return return bytes sent, or other if error occurred
 */
int pps_socket_sendto(pps_socket_t *sock, void *buf, pps_socket_size_t len, pps_sockaddr_t *addr, pps_socklen_t *sock_len);

/**
 * @brief create a connection to the specified destination (TCP)
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param host [IN] connect host
 *
 * @param port [IN] connect port
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_connect(pps_socket_t *sock, const char *host, int port);

/**
 * @brief bind a address with a socket
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param addr [IN] pointer to a pps_sockaddr_t of address to assign to the socket
 *
 * @param sock_len [IN] pointer to address length
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_bind(pps_socket_t *sock, pps_sockaddr_t *addr, pps_socklen_t *sock_len);

/**
 * @brief must call pps_socket_listen before pps_socket_accept
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param backlog [IN] max connetion count
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_listen(pps_socket_t *sock, int backlog);

/**
 * @brief accept an incoming connection attempt on a socket
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param addr [IN] a pointer to received connection address
 *
 * @param sock_len [IN] a pointer to address length
 *
 * @return return a pps_socket_t pointer to new connnection, or NULL on error
 */
pps_socket_t *pps_socket_accept(pps_socket_t *sock, pps_sockaddr_t *addr, pps_socklen_t *sock_len);

/**
 * @brief converts host name address into an string in internet standard dotted-decimal format
 *
 * @param name [IN] host name string
 *
 * @param host [IN] a pointer to converted string
 *
 * @param host_len [IN] converted string max length
 *
 * @return the operation result, PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_gethostbyname(char *name, char *host, pps_socket_size_t host_len);

/**
 * @brief converts the unsigned integer from host byte order to network byte order.
 *
 * @param host_long [IN] unsigned integer in host byte order
 *
 * @return return unsigned integer in network byte order, or other on error
 */
pps_u32 pps_socket_htonl(pps_u32 host_long);

/**
 * @brief converts the unsigned short integer from host byte order to network byte order.
 *
 * @param host_short [IN] unsigned short integer in host byte order
 *
 * @return return unsigned short integer in network byte order, or other on error
 */
pps_u16 pps_socket_htons(pps_u16 host_short);

/**
 * @brief clear a fd_set
 *
 * @param sock_fd_set [IN] a pointer to pps_socket_fd_set_t
 *
 * @return return PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_fd_zero(pps_fd_set_t *sock_fd_set);

/**
 * @brief add file descriptor from a set
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param sock_fd_set [IN] pointer to pps_socket_fd_set_t
 *
 * @return return PPS_OSAL_SUCCESS on success, other on error
 */
int pps_socket_fd_set(pps_socket_t *sock, pps_fd_set_t *sock_fd_set);

/**
 * @brief tests to see if file descriptor is part of the set
 *
 * @param sock [IN] pps_socket_t pointer
 *
 * @param sock_fd_set [IN] pointer to pps_socket_fd_set_t
 *
 * @return return non-zero if file descriptor in set, zero for not
 */
int pps_socket_fd_isset(pps_socket_t *sock, pps_fd_set_t *sock_fd_set);

/**
 * @brief get max socket for pps_socket_select
 *
 * @param sock1 [IN] pps_socket_t pointer
 *
 * @param sock2 [IN] pps_socket_t pointer
 *
 * @return return a pps_socket_t pointer, or NULL on error
 */
pps_socket_t *pps_socket_max(pps_socket_t *sock1, pps_socket_t *sock2);

/**
 * @brief monitor multiple file descriptors, waiting until one or more of the file
 *        descriptors I/O operation evnet happens
 *
 * @param sock [IN] pointer to pps_socket_t for monitor
 *
 * @param rd_set [IN] pointer to pps_socket_fd_set_t to be watched to see if characters become available for read
 *
 * @param wr_set [IN] pointer to pps_socket_fd_set_t to be watched to see if characters become available for write
 *
 * @param ex_set [IN] a pointer to pps_socket_fd_set_t to be watched for exceptional conditions
 *
 * @param timeout_ms [IN] specifies interval(millisecond) block waiting for a file descriptor I/O operation evnet happens
 *
 * @return return the number of file descriptors contained in three sets, return zero if timeout, return -1 on error
 */
int pps_socket_select(pps_socket_t *sock, pps_fd_set_t *rd_set, pps_fd_set_t *wr_set, pps_fd_set_t *ex_set, int timeout_ms);

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_SOCKET_H */
