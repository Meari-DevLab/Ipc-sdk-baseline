/**
 * @file        pps_osal_timer.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer timer module
 *
 * @author      zxc
 *
 * @date        2020/5/7
 *
 * @version     0.1.0
 *
 * @note
 */
#ifndef _PPS_OSAL_TIMER_H_
#define _PPS_OSAL_TIMER_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C"{
#endif

#ifdef CONFIG_OS_WINDOWS
typedef void (*pps_timer_callback_f)(void *arg, pps_u8 timer_or_wait_fired);
#else
typedef union timer_sigval {
	int sival_int;
	void *sival_ptr;
} pps_timer_arg;
typedef void (*pps_timer_callback_f)(pps_timer_arg arg);
#endif

typedef void pps_timer_t;

typedef enum {
    PPS_TIMER_TYPE_ONCE,
    PPS_TIMER_TYPE_PERIOD,
    PPS_TIMER_TYPE_MAX
} PPS_TIMER_TYPE;

/**
 * @brief new a timer
 *
 * @param void
 *
 * @return pps_timer_t pointer on success, NULL on error
 */
pps_timer_t *pps_timer_new(void);

/**
 * @brief start timer
 *
 * @param timer [IN] pps_timer_t pointer
 *
 * @param type [IN] timer type in PPS_TIMER_TYPE
 *
 * @param expire [IN] timer expire
 *
 * @param timer_func [IN] timer call back function
 *
 * @param timer_func [IN] timer function arg
 *
 * @return the operation result, 0 on success, other on error
 */
int pps_timer_start(pps_timer_t *timer, PPS_TIMER_TYPE type, int expire,
                    pps_timer_callback_f timer_func, void *arg);

/**
 * @brief stop timer
 *
 * @param timer [IN] pps_timer_t pointer
 *
 * @return the operation result, 0 on success, other on error
 */
int pps_timer_stop(pps_timer_t *timer);

/**
 * @brief delete timer
 *
 * @param timer [IN] pps_timer_t pointer
 *
 * @return void
 */
void pps_timer_free(pps_timer_t *timer);

#ifdef __cplusplus
}
#endif
#endif /* _PPS_OSAL_TIMER_H_ */
