/**
 * @file        pps_osal_log.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer debug module
 *
 * @author      ysg
 *
 * @date        2019/7/4
 *
 * @version     0.1.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_OSAL_LOG_H_
#define _PPS_OSAL_LOG_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef enum _PPS_OSAL_LOG_LEVEL_E {
    PPS_LOG_LEVEL_NULL    = -1,
    PPS_LOG_LEVEL_ERROR   = 0,
    PPS_LOG_LEVEL_WARN    = 1,
    PPS_LOG_LEVEL_INFO    = 2,
    PPS_LOG_LEVEL_DEBUG   = 3,
    PPS_LOG_LEVEL_VERBOSE = 4,
    /* limitation */
    PPS_LOG_LEVEL_NR,
} PPS_LOG_LEVEL_E;

void pps_log_msg(PPS_LOG_LEVEL_E debug_level, const char *filename, int line, const char *format, ...);

int pps_log_copy(char *dst, int len);

void pps_log_set_level(PPS_LOG_LEVEL_E log_level);

int pps_log_get_level(void);

/**
 * @brief  设置日志文件名称
 *
 * @param filename [in] 要设置的日志文件名称
 *
 * @return the operation result, 0 on success, other on error
 */
int pps_log_set_file(const char *filename);

/**
 * @brief  清除日志文件名称
 */
void pps_log_clean_file(void);

void pps_log_enable_color(int color_enable);

/***
 * @brief: 用户设置日志缓冲区大小，最大不能超过10M（会将预留缓冲区的数据拷贝到当前缓冲区）
 * @param bufsize [in] 要设置的大小
 * @return 0 on success, other on error
 */
int pps_log_set_osal_buf(int bufsize);

/***
 * @brief: 获取缓冲区地址，以及日志长度
 * @param **buf [out] 存放缓冲区地址
 * @return 日志长度
 */
int pps_log_get_osal_buf(char **buf);

/***
 * @brief: 清除日志缓冲区
 * @return 0 on success, other on error
 */
int pps_log_clean_osal_buf(void);

#define PPS_VERBOSE(...) pps_log_msg(PPS_LOG_LEVEL_VERBOSE, __FILE__, __LINE__, ##__VA_ARGS__)
#define PPS_DEBUG(...)   pps_log_msg(PPS_LOG_LEVEL_DEBUG, __FILE__, __LINE__, ##__VA_ARGS__)
#define PPS_INFO(...)    pps_log_msg(PPS_LOG_LEVEL_INFO, __FILE__, __LINE__, ##__VA_ARGS__)
#define PPS_WARN(...)    pps_log_msg(PPS_LOG_LEVEL_WARN, __FILE__, __LINE__, ##__VA_ARGS__)
#define PPS_ERROR(...)   pps_log_msg(PPS_LOG_LEVEL_ERROR, __FILE__, __LINE__, ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_LOG_H_ */
