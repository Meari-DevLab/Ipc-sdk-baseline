#ifndef _DUA_PRODUCST_DEF_H_
#define _DUA_PRODUCST_DEF_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DUA_CFG_PRODUCT_LIB_FILE_PATH "/home/cfg/libpps_product_test.so"
#define DUA_FACTORY_CHECK_INFO_FILE   "/mnt/mmc01/ppsFactoryTool.txt"

#define FACTORY_MODE "FACTORY_MODE"
#define FACTORY_MODE_INIT "init_product"
#define FACTORY_MODE_DEINIT "deinit_product"

#define PRODUCT_MODE "PRODUCT_MODE"
#define TARGET_STRING "product_mode="
#define TARGET_MODE_SEMI "semi"
#define TARGET_MODE_FINISH "finish"
#define TARGET_MODE_TESTING "autotest"

#define PTZ_CAL_MODE "PTZ_CAL_MODE"
#define PTZ_CAL_MODE_STRING "ptz_cal_mode="
#define PTZ_CAL_MODE_CAL "calibration"
#define PTZ_CAL_MODE_NOT_CAL "not_calibration"

typedef pps_s32 (*dua_product_get_qrcode_result)(pps_char *token, pps_char *ssid, pps_char *psw);
typedef struct dua_product_callback {
    dua_product_get_qrcode_result get_qrcode_result;
} DUA_PRODUCT_CALLBACK_T, *DUA_PRODUCT_CALLBACK_PTR;

#ifdef __cplusplus
}
#endif
#endif /* _DUA_PRODUCT_DEF_H_ */
