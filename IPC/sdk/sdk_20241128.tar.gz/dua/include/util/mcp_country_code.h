

/**
 * @file        pps_region_code.h
 *
 * @copyright   2016-2020 Meari technology Co., Ltd
 *
 * @brief       osal software region code interfaces
 *
 * @author      TangMinjie
 *
 * @date        2023/6/1
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _MCP_COUNTRY_CODE_H_
#define _MCP_COUNTRY_CODE_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MCP_DEFAULT_COUNTRY_CODE "00"

typedef enum mcp_country_id {
    MCP_COUNTRY_DEFAULT     = 0,  // default
    MCP_COUNTRY_CHINA       = 1,  // China
    MCP_COUNTRY_AMERICA     = 2,  // United States
    MCP_COUNTRY_EUROPE      = 3,  // Europe
    MCP_COUNTRY_JAPAN       = 4,  // Japan
    MCP_COUNTRY_BRAZIL      = 5,  // Brazil
    MCP_COUNTRY_AUSTRALIA   = 6,  // Australia
    MCP_COUNTRY_ARGENTINA   = 7,  // Argentina
    MCP_COUNTRY_INDIA       = 8,  // India
    MCP_COUNTRY_MALAYSIA    = 9,  // Malaysia
    MCP_COUNTRY_SINGAPORE   = 10, // Singapore
    MCP_COUNTRY_THAILAND    = 11, // Thailand
    MCP_COUNTRY_RUSSIA      = 12, // Russia
    MCP_COUNTRY_CANADA      = 13, // Canada
    MCP_COUNTRY_KOREA       = 14, // Korea
    MCP_COUNTRY_INDONESIA   = 15, // Indonesia
    MCP_COUNTRY_UAE         = 16, // U.A.E
    MCP_COUNTRY_UKRAINE     = 17, // Ukraine
    MCP_COUNTRY_CAMBODIA    = 18, // Cambodia
    MCP_COUNTRY_MEXICO      = 19, // Mexico
    MCP_COUNTRY_PHILIPPINE  = 20, // Philippines
    MCP_COUNTRY_TAIWAN      = 21, // Taiwan
    MCP_COUNTRY_MADAGASCAR  = 22, // Madagascar
    MCP_COUNTRY_PERU        = 23, // Peru
    MCP_COUNTRY_CHILE       = 24, // Chile
    MCP_COUNTRY_ECUADOR     = 25, // Ecuador
    MCP_COUNTRY_PANAMA      = 26, // Panama
    MCP_COUNTRY_COSTA_RICA  = 27, // Costa Rica
    MCP_COUNTRY_MOROCCO     = 28, // Morocco
    MCP_COUNTRY_EGYPT       = 29, // Egypt
    MCP_COUNTRY_SOUTH_AFRIC = 30, // South Africa
    MCP_COUNTRY_ALGERIA     = 31, // Algeria
    MCP_COUNTRY_VIETNAM     = 32, // Vietnam
    MCP_COUNTRY_LITHUANIA   = 33, // Lithuania
    MCP_COUNTRY_BELARUS     = 34, // Belarus
    MCP_COUNTRY_LATVIA      = 35, // Latvia
    MCP_COUNTRY_SERBIA      = 36, // Serbia
    MCP_COUNTRY_ROMANIA     = 37, // Romanian
    MCP_COUNTRY_BULGARIA    = 38, // Bulgaria
    MCP_COUNTRY_COLUMBIA    = 39, // Colombia
    MCP_COUNTRY_HONDURAS    = 40, // Honduras
    MCP_COUNTRY_MAURITIUS   = 41, // Mauritius
    MCP_COUNTRY_AD          = 42,
    MCP_COUNTRY_AF          = 43,
    MCP_COUNTRY_AI          = 44,
    MCP_COUNTRY_AL          = 45,
    MCP_COUNTRY_AM          = 46,
    MCP_COUNTRY_AN          = 47,
    MCP_COUNTRY_AS          = 48,
    MCP_COUNTRY_AT          = 49,
    MCP_COUNTRY_AW          = 50,
    MCP_COUNTRY_AZ          = 51,
    MCP_COUNTRY_BA          = 52,
    MCP_COUNTRY_BB          = 53,
    MCP_COUNTRY_BD          = 54,
    MCP_COUNTRY_BE          = 55,
    MCP_COUNTRY_BF          = 56,
    MCP_COUNTRY_BH          = 57,
    MCP_COUNTRY_BL          = 58,
    MCP_COUNTRY_BM          = 59,
    MCP_COUNTRY_BN          = 60,
    MCP_COUNTRY_BO          = 61,
    MCP_COUNTRY_BS          = 62,
    MCP_COUNTRY_BT          = 63,
    MCP_COUNTRY_BZ          = 64,
    MCP_COUNTRY_CF          = 65,
    MCP_COUNTRY_CH          = 66,
    MCP_COUNTRY_CI          = 67,
    MCP_COUNTRY_CU          = 68,
    MCP_COUNTRY_CX          = 69,
    MCP_COUNTRY_CY          = 70,
    MCP_COUNTRY_CZ          = 71,
    MCP_COUNTRY_DE          = 72,
    MCP_COUNTRY_DK          = 73,
    MCP_COUNTRY_DM          = 74,
    MCP_COUNTRY_DO          = 75,
    MCP_COUNTRY_EE          = 76,
    MCP_COUNTRY_ES          = 77,
    MCP_COUNTRY_ET          = 78,
    MCP_COUNTRY_FI          = 79,
    MCP_COUNTRY_FM          = 80,
    MCP_COUNTRY_FR          = 81,
    MCP_COUNTRY_GB          = 82,
    MCP_COUNTRY_GD          = 83,
    MCP_COUNTRY_GE          = 84,
    MCP_COUNTRY_GF          = 85,
    MCP_COUNTRY_GH          = 86,
    MCP_COUNTRY_GL          = 87,
    MCP_COUNTRY_GP          = 88,
    MCP_COUNTRY_GR          = 89,
    MCP_COUNTRY_GT          = 90,
    MCP_COUNTRY_GU          = 91,
    MCP_COUNTRY_GY          = 92,
    MCP_COUNTRY_HK          = 93,
    MCP_COUNTRY_HR          = 94,
    MCP_COUNTRY_HT          = 95,
    MCP_COUNTRY_HU          = 96,
    MCP_COUNTRY_IE          = 97,
    MCP_COUNTRY_IL          = 98,
    MCP_COUNTRY_IR          = 99,
    MCP_COUNTRY_IS          = 100,
    MCP_COUNTRY_IT          = 101,
    MCP_COUNTRY_JM          = 102,
    MCP_COUNTRY_JO          = 103,
    MCP_COUNTRY_KE          = 104,
    MCP_COUNTRY_KN          = 105,
    MCP_COUNTRY_KP          = 106,
    MCP_COUNTRY_KW          = 107,
    MCP_COUNTRY_KY          = 108,
    MCP_COUNTRY_KZ          = 109,
    MCP_COUNTRY_LB          = 110,
    MCP_COUNTRY_LC          = 111,
    MCP_COUNTRY_LI          = 112,
    MCP_COUNTRY_LK          = 113,
    MCP_COUNTRY_LS          = 114,
    MCP_COUNTRY_LU          = 115,
    MCP_COUNTRY_MC          = 116,
    MCP_COUNTRY_MD          = 117,
    MCP_COUNTRY_ME          = 118,
    MCP_COUNTRY_MF          = 119,
    MCP_COUNTRY_MH          = 120,
    MCP_COUNTRY_MK          = 121,
    MCP_COUNTRY_MN          = 122,
    MCP_COUNTRY_MO          = 123,
    MCP_COUNTRY_MP          = 124,
    MCP_COUNTRY_MQ          = 125,
    MCP_COUNTRY_MR          = 126,
    MCP_COUNTRY_MT          = 127,
    MCP_COUNTRY_MV          = 128,
    MCP_COUNTRY_MW          = 129,
    MCP_COUNTRY_NG          = 130,
    MCP_COUNTRY_NI          = 131,
    MCP_COUNTRY_NL          = 132,
    MCP_COUNTRY_NO          = 133,
    MCP_COUNTRY_NP          = 134,
    MCP_COUNTRY_NZ          = 135,
    MCP_COUNTRY_OM          = 136,
    MCP_COUNTRY_PF          = 137,
    MCP_COUNTRY_PG          = 138,
    MCP_COUNTRY_PK          = 139,
    MCP_COUNTRY_PL          = 140,
    MCP_COUNTRY_PM          = 141,
    MCP_COUNTRY_PR          = 142,
    MCP_COUNTRY_PT          = 143,
    MCP_COUNTRY_PW          = 144,
    MCP_COUNTRY_PY          = 145,
    MCP_COUNTRY_QA          = 146,
    MCP_COUNTRY_RE          = 147,
    MCP_COUNTRY_RW          = 148,
    MCP_COUNTRY_SA          = 149,
    MCP_COUNTRY_SE          = 150,
    MCP_COUNTRY_SI          = 151,
    MCP_COUNTRY_SK          = 152,
    MCP_COUNTRY_SN          = 153,
    MCP_COUNTRY_SR          = 154,
    MCP_COUNTRY_SV          = 155,
    MCP_COUNTRY_SY          = 156,
    MCP_COUNTRY_TC          = 157,
    MCP_COUNTRY_TD          = 158,
    MCP_COUNTRY_TG          = 159,
    MCP_COUNTRY_TN          = 160,
    MCP_COUNTRY_TR          = 161,
    MCP_COUNTRY_TT          = 162,
    MCP_COUNTRY_TZ          = 163,
    MCP_COUNTRY_UG          = 164,
    MCP_COUNTRY_UY          = 165,
    MCP_COUNTRY_UZ          = 166,
    MCP_COUNTRY_VC          = 167,
    MCP_COUNTRY_VE          = 168,
    MCP_COUNTRY_VI          = 169,
    MCP_COUNTRY_VU          = 170,
    MCP_COUNTRY_WF          = 171,
    MCP_COUNTRY_WS          = 172,
    MCP_COUNTRY_YE          = 173,
    MCP_COUNTRY_YT          = 174,
    MCP_COUNTRY_ZW          = 175,
    MCP_COUNTRY_MAX,
} MCP_COUNTRY_ID_E;

typedef enum mcp_region {
    MCP_REGION_CN = 0,
    MCP_REGION_SG,
    MCP_REGION_EU,
    MCP_REGION_US,
    MCP_REGION_NONE
} MCP_REGION_E;

typedef struct mcp_sales_territory {
    pps_s32  country_id;
    pps_char country_code[16];
} MCP_SALES_TERRITORY_T, *MCP_SALES_TERRITORY_PTR;


pps_void mcp_get_country_code(pps_s32 country_id, pps_char *country_code);

pps_s32 mcp_get_region_by_country_code(pps_char *country_code);

pps_s32 mcp_get_region_by_country_id(pps_s32 country_id);
#ifdef __cplusplus
}
#endif

#endif // _PPS_TIMER_H_
