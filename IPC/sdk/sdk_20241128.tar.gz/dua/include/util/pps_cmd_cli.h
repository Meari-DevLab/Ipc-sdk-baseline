/**
 * @file        pps_cmd_cli.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zengyaowu
 *
 * @date        2021/04/15
 *
 * @version     0.1.0
 *
 * @note
 */
#ifndef __PPS_CMD_CLI_H
#define __PPS_CMD_CLI_H

#ifdef __cplusplus
extern "C" {
#endif

int pps_system_cmd(char *cmd);

#ifdef __cplusplus
}
#endif
#endif /* __PPS_CMD_CLI_H */
