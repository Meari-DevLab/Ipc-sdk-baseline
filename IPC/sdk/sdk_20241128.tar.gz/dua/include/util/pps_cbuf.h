/**
 * @file        pps_cbuf.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zengyaowu
 *
 * @date        2021/04/15
 *
 * @version     0.1.0
 *
 * @note
 */
#ifndef __PPS_CBUF_H
#define __PPS_CBUF_H

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum PPS_CBUF_MODE {
    PPS_CBUF_MODE_RAW,      /* raw data, no more data to append */
    PPS_CBUF_MODE_STANDARD, /* append Channel and Size for each packet */
    PPS_CBUF_MODE_TEMP,     /* 非循环缓冲区, 临时缓冲用, 常用于网络IO缓冲时用 */
} PPS_CBUF_MODE_E;

typedef struct pps_cbuf {
    unsigned int    size;
    int             head; /* 写指针 */
    int             tail; /* 读指针 */
    PPS_CBUF_MODE_E mode; /* 模式 */
    char *          buf;  /* put in the tail always */
} pps_cbuf_t;

typedef struct pps_cbuf_head {
    unsigned char channel;
    unsigned char size[3]; // 0|1|2, From High Bytes to Low Bytes
} pps_cbuf_head_t;

/* bufsize最好是 */
pps_cbuf_t *pps_cbuf_new(unsigned int bufsize, PPS_CBUF_MODE_E mode);
int         pps_cbuf_free(pps_cbuf_t *cbuf);

/* 注意剩余空间需要大于一个pps_cbuf_head_t头的时候，才允许写入数据 */
int pps_cbuf_space(pps_cbuf_t *cbuf);
int pps_cbuf_count(pps_cbuf_t *cbuf);
/* 返回缓冲区使用率: 0-100 */
int pps_cbuf_usage(pps_cbuf_t *cbuf);

int pps_cbuf_count2end(pps_cbuf_t *cbuf);
int pps_cbuf_space2end(pps_cbuf_t *cbuf);

/* 获取连续地址数据的指针及长度，不进行读指针的更新，需要调用pps_cbuf_read_forward来主动更新*/
int pps_cbuf_point2end(pps_cbuf_t *cbuf, void **buf);

/* 仅支持RAW模式的时候使用, 会发生一次拷贝,
 * 从外界的缓冲区到内部的循环缓冲区，如果想要减少拷贝可以尝试使用query接口直接拿到内部地址进行操作 */
int pps_cbuf_write(pps_cbuf_t *cbuf, char *buf, int size);
int pps_cbuf_read(pps_cbuf_t *cbuf, char *buf, int size);
/* 只是读取，不进行读指针的更新，需要调用pps_cbuf_read_forward来主动更新 */
int pps_cbuf_read_fake(pps_cbuf_t *cbuf, char *buf, int size);
/* 快速前进读指针 */
int pps_cbuf_read_forward(pps_cbuf_t *cbuf, int size);

/* 仅支持STANDARD模式使用 */
int pps_cbuf_write_packet(pps_cbuf_t *cbuf);
int pps_cbuf_read_packet(pps_cbuf_t *cbuf);
int pps_cbuf_read_packet_fake(pps_cbuf_t *cbuf);


#ifdef __cplusplus
}
#endif
#endif /* __PPS_CBUF_H */
