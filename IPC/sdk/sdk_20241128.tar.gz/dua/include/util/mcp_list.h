/**
 * @file        linked_list.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      liping
 *
 * @date        2023/06/12
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __LINKED_LIST_H
#define __LINKED_LIST_H

#include <stdio.h>
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct mcp_list {
    pps_void *       callback;
    struct mcp_list *next;
} MCP_LIST_T, *MCP_LIST_PTR;

MCP_LIST_PTR mcp_list_init(pps_void);

MCP_LIST_PTR mcp_list_add(MCP_LIST_PTR linked_list_head, pps_void *callback);

pps_s32 mcp_list_delete(MCP_LIST_PTR linked_list_head, pps_void *callback);

pps_s32 mcp_list_deinit(MCP_LIST_PTR linked_list_head);

#ifdef __cplusplus
}
#endif
#endif /* __LINKED_LIST_H */
