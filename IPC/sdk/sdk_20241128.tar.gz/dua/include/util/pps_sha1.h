/**
 * @file re_sha.h  Interface to SHA (Secure Hash Standard) functions
 *
 * Copyright (C) 2010 Creytiv.com
 */

#ifndef _PPS_SHA_H
#define _PPS_SHA_H

#include <stdint.h>

/* public api for steve reid's public domain SHA-1 implementation */
/* this file is in the public domain */

/** SHA-1 Context */
typedef struct {
    uint32_t state[5];
    /**< Context state */
    uint32_t count[2];
    /**< Counter       */
    uint8_t buffer[64]; /**< SHA-1 buffer  */
} pps_sha1_ctx;

/** SHA-1 Context (OpenSSL compat) */
typedef pps_sha1_ctx pps_SHA_CTX;

/** SHA-1 Digest size in bytes */
#define SHA1_DIGEST_SIZE 20
/** SHA-1 Digest size in bytes (OpenSSL compat) */
#define SHA_DIGEST_LENGTH SHA1_DIGEST_SIZE

void pps_sha1_init(pps_sha1_ctx *context);

void pps_sha1_update(pps_sha1_ctx *context, const void *p, size_t len);

void pps_sha1_final(uint8_t digest[SHA1_DIGEST_SIZE], pps_sha1_ctx *context);

unsigned char *pps_sha1(const unsigned char *d, size_t n, unsigned char *md);

#endif /* _PPS_SHA_H */
