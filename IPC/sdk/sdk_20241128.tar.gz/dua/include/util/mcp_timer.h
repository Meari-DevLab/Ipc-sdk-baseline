/**
 * @file        pps_timer.h
 *
 * @copyright   2016-2020 Meari technology Co., Ltd
 *
 * @brief       osal software timer interfaces
 *
 * @author
 *
 * @date        2020/5/19
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_TIMER_H_
#define _PPS_TIMER_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Specifies the type of the timer to be created
 */
typedef enum mcp_timer_type {
    MCP_TIMER_TYPE_ONCE,         /**< Single-period timer */
    MCP_TIMER_TYPE_PERIOD,       /**< Periodic timer */
    MCP_TIMER_TYPE_NOSELFDELETE, /**< Single-period timer, but not self-delete */
    MCP_TIMER_TYPE_MAX           /**< Maximum value, which cannot be used */
} MCP_TIMER_TYPE_E;

/**
 * @brief    defines the type of the timer callback function
 * @param    data[in] callback input parameter
 * @return   void
 */
typedef pps_void (*mcp_timer_callback_f)(pps_u32 data);

typedef struct pps_timer {
    pps_u32 timer_handle;
} MCP_TIMER_T, *MCP_TIMER_PTR;

/**
 * @func    mcp_timer_create
 * @brief   create a software timer
 *
 * @param   timer[out] timer handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_create(MCP_TIMER_PTR timer);

/**
 * @func    mcp_timer_delete
 * @brief   delete a software timer
 *
 * @param   timer[in] timer handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_delete(MCP_TIMER_PTR timer);

/**
 * @func    mcp_timer_start
 * @brief   start a software timer
 *
 * @param   timer[in] timer handle context
 * @param   type[in] timer type, Single-period or Periodic
 * @param   expire[in] timeout period of the timer (unit: ms)
 * @param   timer_func[in] timer callback function
 * @param   data[in] callback input parameter
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_start(MCP_TIMER_PTR timer, MCP_TIMER_TYPE_E type, pps_u32 expire, mcp_timer_callback_f timer_func,
                        pps_u32 data);

/**
 * @func    mcp_timer_refresh
 * @brief   refresh a software timer
 *
 * @param   timer[in] timer handle context
 * @param   time[in] timeout period of the timer (unit: ms)
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_refresh(MCP_TIMER_PTR timer, pps_u32 time);

/**
 * @func    mcp_timer_stop
 * @brief   stop a software timer
 *
 * @param   timer[in] timer handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_stop(MCP_TIMER_PTR timer);

/**
 * @func    mcp_timer_remain_time
 * @brief   get the number of remaining ms
 *
 * @param   timer[in] timer handle context
 * @param   ms[out] timer remain ms
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_timer_remain_time(MCP_TIMER_PTR timer, pps_u32 *ms);

/**
 * @func    mcp_timer_is_start
 * @brief   get the timer is started
 *
 * @param   timer[in] timer handle context
 * @return  On success, return true/false. On error, return errno.
 */
pps_s32 mcp_timer_is_start(MCP_TIMER_PTR timer);

#ifdef __cplusplus
}
#endif

#endif // _PPS_TIMER_H_
