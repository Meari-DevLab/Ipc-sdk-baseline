/**
 * @file        pps_crypt.h
 *
 * @copyright   2016-2019 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author
 *
 * @date        2019/7/9
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_CRYPT_H
#define _PPS_CRYPT_H

#if defined(__APPLE__) || defined(__ANDROID__) || defined(__linux__)
#include <inttypes.h>
#endif

#if defined(__APPLE__) || defined(__linux__)
#ifndef CALLBACK
#define CALLBACK
#endif

#ifdef __cplusplus
#define PPSCRYPTAPI extern "C"
#else
#define PPSCRYPTAPI extern
#endif
#elif defined(_WIN32)
#ifndef CALLBACK
#define CALLBACK __stdcall
#endif
#ifdef __cplusplus
#define PPSCRYPTAPI extern "C" __declspec(dllexport)
#else
#define PPSCRYPTAPI
#endif
#endif

PPSCRYPTAPI int encode_uuid_enrtypt_B(char *inputData, char *outputData);

PPSCRYPTAPI int decode_uuid_dertypt_B(char *inputData, char *outputData);

#endif /* _PPS_CRYPT_H */
