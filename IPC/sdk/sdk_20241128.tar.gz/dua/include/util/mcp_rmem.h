/**
 * @file        rmem.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       rmem malloc and free， only valid when IMP SDK not working
 *
 * @author      jim
 *
 * @date        2021/06/24
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef _MCP_RMEM_H_
#define _MCP_RMEM_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 mcp_rmem_get_meminfo(pps_u32 *mem_size, pps_u32 *mcp_rmem_size);
 * @brief   <获取rmem和mem大小>
 * @param   [out] mem_size: mem大小
 * @param   [out] mcp_rmem_size: rmem大小
 * @return  0 - 成功 | else - 失败
 */
pps_s32 mcp_rmem_get_meminfo(pps_u32 *mem_size, pps_u32 *mcp_rmem_size);

/** @fn      pps_void *mcp_rmem_flush_malloc(size_t size);
 * @brief   <申请rmem空间>
 * @param   [in] size: 需要申请的空间大小
 * @return   buff地址 | else - NULL
 */
pps_void *mcp_rmem_flush_malloc(size_t size);

/** @fn      pps_void mcp_rmem_flush_free(pps_void *vaddr);
 * @brief   <释放rmem空间>
 * @param   [in] vaddr: rmem空间地址
 * @return
 */
pps_void mcp_rmem_flush_free(pps_void *vaddr);

/** @fn      pps_s32 mcp_rmem_flush_cache(pps_void *vaddr, size_t size);
 * @brief   <rmem空间缓存>
 * @param   [in] vaddr: rmem空间地址
 * @param   [in] size: 长度
 * @return
 */
pps_s32 mcp_rmem_flush_cache(pps_void *vaddr, size_t size);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_RMEM_H_ */
