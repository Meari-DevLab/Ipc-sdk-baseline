/**
 * @file        mcp_event.h
 *
 * @copyright   2016-2020 Meari technology Co., Ltd
 *
 * @brief       osal event interfaces
 *
 * @author
 *
 * @date        2020/4/28
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_MEVENT_H_
#define _PPS_MEVENT_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MCP_EVENT_WAIT_MASK 0xFFFFFF
#define MCP_EVENT_NUM       (10) // trigger/timedtask/...

typedef struct mcp_event_t {
    pps_u32 event_id;
} MCP_EVENT_T, *MCP_EVENT_PTR;

/**
 * @func    mcp_event_init
 * @brief   event resource init
 *
 * @param   pps_void
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_init(pps_void);

/**
 * @func    mcp_event_deinit
 * @brief   event resource deinit
 *
 * @param   pps_void
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_deinit(pps_void);

/**
 * @func    mcp_event_create
 * @brief   create a event object
 *
 * @param   event[out] event module handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_create(MCP_EVENT_PTR event);

/**
 * @func    mcp_event_create
 * @brief   delete a event object
 *
 * @param   event[in] event module handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_delete(MCP_EVENT_PTR event);

/**
 * @func    mcp_event_send
 * @brief   trigger a event
 *
 * @param   event[in] event module handle context
 * @param   type[in] event type
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_send(MCP_EVENT_PTR event, pps_u32 type);

/**
 * @func    mcp_event_wait
 * @brief   wait event to trigger
 *
 * @param   event[in] event module handle context
 * @param   type[out] event type
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_wait(MCP_EVENT_PTR event, pps_u32 *type);

/**
 * @func    mcp_event_clear
 * @brief   clear event flags
 *
 * @param   event[in] event module handle context
 * @param   type[out] event type
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_event_clear(MCP_EVENT_PTR event, pps_u32 type);

#ifdef __cplusplus
}
#endif

#endif // _PPS_EVENT_H_
