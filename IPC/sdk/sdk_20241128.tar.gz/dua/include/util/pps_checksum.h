/**
 * @file        pps_checksum.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zengyaowu
 *
 * @date        2021/04/19
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef __PPS_CHECKSUM_H
#define __PPS_CHECKSUM_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __GROUP_HEADER_defined
#define __GROUP_HEADER_defined
typedef struct GROUP_HEADER_STRU {
    unsigned int start_code;
    unsigned int frame_num;
    unsigned int time_stamp;
    unsigned int is_audio;
    unsigned int block_number;
    union {
        unsigned int picture_format;
        struct {
            unsigned short image_width;
            unsigned short image_height;
        } size;
    } image_size;
    unsigned int picture_mode;
    unsigned int frame_rate;

    union {
        struct {
            unsigned int I_quant_value;
            unsigned int P_quant_value;
            unsigned int B_quant_value;
        } mpeg4_quant;

        struct {
            unsigned short time_extension;
            unsigned short reserved[3];
            unsigned int   stream_crc;
        } H264_extension;
    } mpeg4_or_h264_info;

    unsigned int global_time;
} GROUP_HEADER;
#endif

int pps_check_vgh(GROUP_HEADER *pheader);

uint32_t pps_checksum_8u(uint8_t *pbuf, int len);
uint32_t pps_checksum_16u(uint16_t *pbuf, int len);

#ifdef __cplusplus
}
#endif
#endif /* __PPS_CHECKSUM_H */
