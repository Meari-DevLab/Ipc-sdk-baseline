#include "pps_osal.h"

#define PPS_STRERROR(err_code, ...) pps_strerror(err_code, __FILE__, __LINE__, ##__VA_ARGS__)

pps_void pps_strerror(pps_s32 err_code, const pps_char *file, pps_s32 line, const pps_char *format, ...);
