/**
 * @file        pps_media_common.h
 *
 * @copyright   2015-2020 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author      Agogo
 *
 * @date        2019/1/1
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef __PPS_MEDIA_COMMON_H__
#define __PPS_MEDIA_COMMON_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#include "pps_media_type.h"
#include "pps_media_errno.h"

#define PPS_MEDIA_MIN(a, b) ((a) > (b) ? (b) : (a))
#define PPS_MEDIA_MAX(a, b) ((a) > (b) ? (a) : (b))
#define PPS_MEDIA_ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

#define PPS_MEDIA_LOGO_NAME         32
#define PPS_MEDIA_OSD_STR_NAME      64

#define PPS_MEDIA_MD_GRID_COL       16
#define PPS_MEDIA_MD_GRID_ROW       9

#define PPS_MEDIA_FD_MAX_FACES_NR   8

#define PPS_MEDIA_VO_ZOOM_MAX_TIMES 15
#define PPS_MEDIA_VO_PRE_STOP_ALL   -1
#define PPS_MEDIA_VDEC_RECV_FRAM    -1

#define PPS_MEDIA_DETECTION_MAX_AREA  (6)
#define PPS_MEDIA_DETECTION_MAX_POINT (8)
#define PPS_MEDIA_PET_DIARY 10

#define PPS_MEDIA_EPSILON 1E-8

typedef double (*pps_media_corrd_t)[2];

typedef enum {
    PPS_MEDIA_MODULE_ID_AI,
    PPS_MEDIA_MODULE_ID_AO,
    PPS_MEDIA_MODULE_ID_VI,
    PPS_MEDIA_MODULE_ID_VO,
    PPS_MEDIA_MODULE_ID_IVS_MD,
    PPS_MEDIA_MODULE_ID_IVS_PD,
    PPS_MEDIA_MODULE_ID_ALL,
} pps_media_module_id_e;

/********************************************************
 *      data structure between medialib and app
 ********************************************************/
typedef struct {
    PPS_MEDIA_INT32 x;
    PPS_MEDIA_INT32 y;
} pps_media_point_t;

typedef struct {
    PPS_MEDIA_BOOL enable;
    PPS_MEDIA_INT32 x;
    PPS_MEDIA_INT32 y;
    PPS_MEDIA_UINT32 width;
    PPS_MEDIA_UINT32 height;
    float score;
    time_t pic_time;
    char pet_diary[PPS_MEDIA_PET_DIARY];
} pps_media_rect_t;

typedef struct {
    PPS_MEDIA_UINT width;
    PPS_MEDIA_UINT height;
} pps_media_size_t;

typedef struct {
    PPS_MEDIA_INT16 year;
    PPS_MEDIA_INT16 month;
    PPS_MEDIA_INT16 dayOfWeek;                  /* 0: Sunday, 6:Saturday */
    PPS_MEDIA_INT16 day;
    PPS_MEDIA_INT16 hour;
    PPS_MEDIA_INT16 minute;
    PPS_MEDIA_INT16 second;
    PPS_MEDIA_INT16 milliSecond;
} pps_media_date_time_t;

typedef enum {
    PPS_MEDIA_PIC_CIF = 0,
    PPS_MEDIA_PIC_360P = 1,    /* 640 * 360 */
    PPS_MEDIA_PIC_VGA = 2,     /* 640 * 480 */
    PPS_MEDIA_PIC_D1_PAL = 3,  /* 720 * 576 */
    PPS_MEDIA_PIC_D1_NTSC = 4, /* 720 * 480 */
    PPS_MEDIA_PIC_720P = 5,    /* 1280 * 720  */
    PPS_MEDIA_PIC_1080P = 6,   /* 1920 * 1080 */
    PPS_MEDIA_PIC_2304x1296 = 7,
    PPS_MEDIA_PIC_2560x1440 = 8,
    PPS_MEDIA_PIC_2592x1520 = 9,
    PPS_MEDIA_PIC_2592x1536 = 10,
    PPS_MEDIA_PIC_2592x1944 = 11,
    PPS_MEDIA_PIC_2688x1520 = 12,
    PPS_MEDIA_PIC_2716x1524 = 13,
    PPS_MEDIA_PIC_3840x2160 = 14,
    PPS_MEDIA_PIC_4096x2160 = 15,
    PPS_MEDIA_PIC_3000x3000 = 16,
    PPS_MEDIA_PIC_4000x3000 = 17,
    PPS_MEDIA_PIC_7680x4320 = 18,
    PPS_MEDIA_PIC_3840x8640 = 19,
    PPS_MEDIA_PIC_1536x1536 = 20,
    PPS_MEDIA_PIC_480x480 = 21,
    PPS_MEDIA_PIC_864x480 = 22,
    PPS_MEDIA_PIC_2048x1536 = 23,
    PPS_MEDIA_PIC_2880x1620 = 24,
    PPS_MEDIA_PIC_480x360 = 25,
    PPS_MEDIA_PIC_1984x1488 = 26,
    PPS_MEDIA_PIC_2272x1704 = 27,
    PPS_MEDIA_PIC_320x240 = 28,
    PPS_MEDIA_PIC_2880x1600 = 29,
    PPS_MEDIA_PIC_3840x2144 = 30,
    PPS_MEDIA_PIC_2944x1656 = 31,
    PPS_MEDIA_PIC_1728x1728 = 32,
    PPS_MEDIA_PIC_320x180 = 33,
    PPS_MEDIA_PIC_BUTT
} pps_media_pic_size_e;

typedef enum {
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_1,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_2,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_3,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_4,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_5,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_6,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_7,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_8,
    PPS_MEDIA_IMAGE_QUALITY_LEVEL_9,

    /* deprecated */
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_1 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_1,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_2 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_2,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_3 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_3,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_4 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_4,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_5 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_5,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_6 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_6,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_7 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_7,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_8 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_8,
    PPS_MEDIA_VIDEO_QUALITY_LEVEL_9 = PPS_MEDIA_IMAGE_QUALITY_LEVEL_9,
    PPS_MEDIA_VIDEO_QUALITY_CUSTOM,
} pps_media_video_quality_e;

typedef pps_media_video_quality_e pps_media_image_quality_e;

typedef enum {
    PPS_MEDIA_RC_INVALID = -1,
    PPS_MEDIA_RC_AVBR = 0,
    PPS_MEDIA_RC_VBR = 1,
    PPS_MEDIA_RC_CVBR = 2,
    PPS_MEDIA_RC_CBR = 3,
    PPS_MEDIA_RC_QPMAP = 4,
    PPS_MEDIA_RC_FIXQP = 5,
    PPS_MEDIA_RC_MAX,
} pps_media_rc_e;

typedef enum {
    PPS_MEDIA_H264_BASELINE = 0,
    PPS_MEDIA_H264_MAIN_PROFILE = 1,
    PPS_MEDIA_H264_HIGH_PROFILE = 2,
    PPS_MEDIA_H264_SVC_T = 3,
    PPS_MEDIA_H265_MAIN_PROFILE = 4,
    PPS_MEDIA_H265_MAIN10_PROFILE = 5,
    PPS_MEDIA_JPEG_MJPEG_BASELINE = 6,
} pps_media_codec_profile_e;


typedef enum {
    PPS_MEDIA_FONT_TYPE_BITMAP = 0,
    PPS_MEDIA_FONT_TYPE_TTF = 1,
} pps_media_font_type_e;

typedef enum {
    PPS_MEDIA_CACHE_FRAME_TYPE_NORMAL = 0,
    PPS_MEDIA_CACHE_FRAME_TYPE_NVR = 1,
}pps_media_cache_frame_type_e;

typedef enum {
    PPS_MEDIA_SOFT_CONTROL = 0, /* can be change by pps_media */
    PPS_MEDIA_HARD_CONTROL = 1, /* totally controled by app */
    PPS_MEDIA_LIGHT_CONTROL_MAX
} pps_media_led_ctrl_e;

typedef struct {
    /* for config file, font file, IQ file, etc. if no set, default is '.' */
    char *config_path;
    char *pps_nn_model_path; /* end the path with '/' */
    /* specify substream resolution. if size equal to zero, substream encoded with 360p
     * reolution as default. resolution setting is strictly relavant to plat ability. */
    PPS_MEDIA_UINT stream_count;
    pps_media_size_t mainstream;
    pps_media_size_t substream;
    pps_media_size_t thirdstream;
    pps_media_font_type_e font_type;
    PPS_MEDIA_UINT32 mainstream_osd_font_size;
    PPS_MEDIA_UINT32 substream_osd_font_size;
    pps_media_cache_frame_type_e cache_frame_type;
    PPS_MEDIA_BOOL led_control; /* true: disable media control, false: enable media control */
    PPS_MEDIA_UINT32 mem_reduce_level;
    PPS_MEDIA_BOOL infrared_support;
    PPS_MEDIA_UINT32 pps_nn_algo_sel; /* val == 1 use 4cls; val == 2 use pir filter */
    PPS_MEDIA_UINT32 ai_samplerate;
    PPS_MEDIA_UINT32 ao_samplerate;
} pps_media_option_t;

typedef struct pps_media_keyvalue {
    char *key;
    char *value;
} pps_media_keyvalue_t;

typedef enum {
    /* please use these definitions in new code*/
    PPS_MEDIA_DEV_TYPE_NONE = 0,
    PPS_MEDIA_DEV_TYPE_VENC = 1,
    PPS_MEDIA_DEV_TYPE_AENC = 2,
    PPS_MEDIA_DEV_TYPE_VDEC = 11,
    PPS_MEDIA_DEV_TYPE_ADEC = 12,
    PPS_MEDIA_DEV_TYPE_VI   = 21,
    PPS_MEDIA_DEV_TYPE_AI   = 22,
    PPS_MEDIA_DEV_TYPE_VO   = 31,
    PPS_MEDIA_DEV_TYPE_AO   = 32,
    PPS_MEDIA_DEV_TYPE_VMEM  = 41,
} pps_media_dev_type_e;

/* TODO: The following defines should be removed */
#define MAX_VIDEO_ENCODE_ID 5
#define MAX_AUDIO_ENCODE_ID 4
#define MAX_VIDEO_DECODE_ID 36
#define MAX_AUDIO_DECODE_ID 1
#define MAX_VIDEO_INPUT_ID 2

/* deprecated, do not use in new codes */
typedef int pps_media_venc_id_e;
typedef int pps_media_aenc_id_e;
typedef int pps_media_vdec_id_e;
typedef int pps_media_adec_id_e;

/* deprecated, do not use in new codes */
enum {
    /* specify for smart home camera */
    PPS_MEDIA_VENC_ID_MAIN_STREAM       = 0,
    PPS_MEDIA_VENC_ID_SUB_STREAM        = 1,
    PPS_MEDIA_VENC_ID_THIRD_STREAM      = 2,
    PPS_MEDIA_VENC_ID_SNAPSHOT          = 3,
    /* for all video encoder */
    PPS_MEDIA_VENC_ID_0                 = 4,
    PPS_MEDIA_VENC_ID_1                 = 5,
};

/* deprecated, do not use in new codes */
enum {
    /* audio encoder */
    PPS_MEDIA_AENC_ID_LQ                = 0,
    PPS_MEDIA_AENC_ID_HQ                = 1,
    PPS_MEDIA_AENC_ID_SQ                = 4,
    PPS_MEDIA_AENC_ID_RAW               = 2,
    PPS_MEDIA_AENC_ID_0                 = 3,
};

/* deprecated, do not use in new codes */
enum {
    /* video decoder */
    PPS_MEDIA_VDEC_ID_0         = 0,
    PPS_MEDIA_VDEC_ID_1         = 1,
    PPS_MEDIA_VDEC_ID_2         = 2,
    PPS_MEDIA_VDEC_ID_3         = 3,
    PPS_MEDIA_VDEC_ID_4         = 4,
    PPS_MEDIA_VDEC_ID_5         = 5,
    PPS_MEDIA_VDEC_ID_6         = 6,
    PPS_MEDIA_VDEC_ID_7         = 7,
    PPS_MEDIA_VDEC_ID_8         = 8,
    PPS_MEDIA_VDEC_ID_9         = 9,
    PPS_MEDIA_VDEC_ID_10        = 10,
    PPS_MEDIA_VDEC_ID_11        = 11,
    PPS_MEDIA_VDEC_ID_12        = 12,
    PPS_MEDIA_VDEC_ID_13        = 13,
    PPS_MEDIA_VDEC_ID_14        = 14,
    PPS_MEDIA_VDEC_ID_15        = 15,
    PPS_MEDIA_VDEC_ID_16        = 16,
    PPS_MEDIA_VDEC_ID_17        = 17,
    PPS_MEDIA_VDEC_ID_18        = 18,
    PPS_MEDIA_VDEC_ID_19        = 19,
    PPS_MEDIA_VDEC_ID_20        = 20,
    PPS_MEDIA_VDEC_ID_21        = 21,
    PPS_MEDIA_VDEC_ID_22        = 22,
    PPS_MEDIA_VDEC_ID_23        = 23,
    PPS_MEDIA_VDEC_ID_24        = 24,
    PPS_MEDIA_VDEC_ID_25        = 25,
    PPS_MEDIA_VDEC_ID_26        = 26,
    PPS_MEDIA_VDEC_ID_27        = 27,
    PPS_MEDIA_VDEC_ID_28        = 28,
    PPS_MEDIA_VDEC_ID_29        = 29,
    PPS_MEDIA_VDEC_ID_30        = 30,
    PPS_MEDIA_VDEC_ID_31        = 31,
    PPS_MEDIA_VDEC_ID_32        = 32,
    PPS_MEDIA_VDEC_ID_33        = 33,
    PPS_MEDIA_VDEC_ID_34        = 34,
    PPS_MEDIA_VDEC_ID_35        = 35,
    PPS_MEDIA_VDEC_ID_MAX       = 36,
};

enum {
    /* audio decoder */
    PPS_MEDIA_ADEC_ID_0         = 0,
    PPS_MEDIA_ADEC_ID_MAX       = 1,
};

/**
 * Some tips about packet, stream, frame
 * packet: compressed video data
 * stream: continuous packets of video/audio/snapshot
 * frame: decoded stream of video. For instance,original YUV/RGB images.
 */
typedef enum {
    PPS_MEDIA_PAYLOAD_TYPE_UNKNOWN = 0x0,
    PPS_MEDIA_PAYLOAD_TYPE_H264    = 0x1,
    PPS_MEDIA_PAYLOAD_TYPE_MPEG4   = 0x2,
    PPS_MEDIA_PAYLOAD_TYPE_JPEG    = 0x3,
    PPS_MEDIA_PAYLOAD_TYPE_H265    = 0x4,
    PPS_MEDIA_PAYLOAD_TYPE_MJPEG   = 0x5,

    PPS_MEDIA_PAYLOAD_TYPE_AAC     = 0x11,
    PPS_MEDIA_PAYLOAD_TYPE_G711U   = 0x12,
    PPS_MEDIA_PAYLOAD_TYPE_G711A   = 0x13,
    PPS_MEDIA_PAYLOAD_TYPE_PCM     = 0x14,
    PPS_MEDIA_PAYLOAD_TYPE_G726    = 0x15,
    PPS_MEDIA_PAYLOAD_TYPE_ADPCM   = 0x16,
    PPS_MEDIA_PAYLOAD_TYPE_AAC_ELD = 0x17,
    PPS_MEDIA_PAYLOAD_TYPE_OPUS    = 0x18,
} pps_media_payload_type_e;

typedef enum {
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_BASE = 0,
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_BSLICE = 1,          /*B SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_PSLICE = 2,          /*P SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_ISLICE = 3,          /*I SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_IDRSLICE = 4,        /*IDR SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_SEI = 5,             /*SEI types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_SPS = 6,             /*SPS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_PPS = 7,             /*PPS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H264E_BUTT,

    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_BASE = 10,
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_BSLICE = 11,          /*B SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_PSLICE = 12,          /*P SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_ISLICE = 13,          /*I SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_IDRSLICE = 14,        /*IDR SLICE types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_VPS = 15,             /*VPS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_SPS = 16,             /*SPS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_PPS = 17,             /*PPS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_SEI = 18,             /*SEI types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_H265E_BUTT,

    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_BASE = 20,
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_ECS = 21,             /*ECS types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_APP = 22,             /*APP types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_VDO = 23,             /*VDO types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_PIC = 24,             /*PIC types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_DCF = 25,             /*DCF types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_DCF_PIC = 26,         /*DCF PIC types*/
    PPS_MEDIA_VIDEO_PACKET_TYPE_JPEGE_BUTT,
} pps_media_video_packet_type_e;

typedef enum {
    PPS_MEDIA_AUDIO_PACKET_TYPE_BASE = 0,
    PPS_MEDIA_AUDIO_PACKET_TYPE_G711U = 1,
    PPS_MEDIA_AUDIO_PACKET_TYPE_G711A = 2,
    PPS_MEDIA_AUDIO_PACKET_TYPE_G726 = 3,
    PPS_MEDIA_AUDIO_PACKET_TYPE_AAC = 4,
    PPS_MEDIA_AUDIO_PACKET_TYPE_PCM = 5,
    PPS_MEDIA_AUDIO_PACKET_TYPE_ADPCM = 6,
    PPS_MEDIA_AUDIO_PACKET_TYPE_AAC_ELD = 7,
    PPS_MEDIA_AUDIO_PACKET_TYPE_OPUS = 8,
} pps_media_audio_packet_type_e;

typedef enum {
    PPS_MEDIA_AUDIO_SOUND_MODE_MONO = 0,
    PPS_MEDIA_AUDIO_SOUND_MODE_STEREO = 1,
} pps_media_audio_sound_mode_e;

typedef enum {
    PPS_MEDIA_MD_SENSITIVITY_LEVEL_LOW = 1,
    PPS_MEDIA_MD_SENSITIVITY_LEVEL_MID = 2,
    PPS_MEDIA_MD_SENSITIVITY_LEVEL_HIGH = 3,
} pps_media_md_sensitivity_level_e;

typedef struct {
    void *avbuf;                                            /* stream buf base */
    PPS_MEDIA_UINT32 len;                                   /* stream buf size */
    pps_media_payload_type_e payload;                       /* H264/H265/AAC/G711A/G711U/PCM */
    pps_media_video_packet_type_e packet_type;              /* video: I/P/B/SPS/PPS */
    pps_media_size_t pic_size;
    PPS_MEDIA_UINT64 pts;                                   /* stream timestamp, unit: ms */
    PPS_MEDIA_UINT64 dts;                                   /* stream timestamp, unit: ms. if no B frame, dts == pts */
    time_t date;                                            /* system utc time */
    PPS_MEDIA_UINT64 seq;                                   /* frame sequence number */
} __attribute__((packed)) pps_media_video_packet_t;

typedef struct {
    void *avbuf;                                            /* stream buf base */
    PPS_MEDIA_UINT32 len;                                   /* stream buf size */
    pps_media_payload_type_e payload;                       /* H264/H265/AAC/G711A/G711U/PCM */
    pps_media_audio_packet_type_e packet_type;              /* audio: G711, G726, ADPCM */
    time_t date;                                            /* system utc time */
    PPS_MEDIA_UINT64 pts;                                   /* stream timestamp, unit: ms */
    PPS_MEDIA_UINT64 seq;                                   /* sequence number */
    PPS_MEDIA_UINT32 bit_width;                             /* bit width of audio data */
    PPS_MEDIA_UINT32 sample_rate;                           /* sample rate of audio data */
} __attribute__((packed)) pps_media_audio_packet_t;

typedef struct {
    void *avbuf;                                            /* frame buf base */
    PPS_MEDIA_UINT32 len;                                   /* frame buf size */
    pps_media_size_t origin_size;                           /* the resolution of  decoded*/
    pps_media_size_t aligned_size;                          /* the real size after decoding sometimes differs from origin_size, because of alignment */
    PPS_MEDIA_UINT64 pts;                                   /* frame timestamp, unit: ms */
    PPS_MEDIA_UINT64 seq;                                   /* sequence number */
} __attribute__((packed)) pps_media_video_frame_t;

typedef struct {
    void *avbuf;                                            /* frame buf base */
    PPS_MEDIA_UINT32 len;                                   /* frame buf size */
    PPS_MEDIA_UINT64 pts;                                   /* frame timestamp, unit: ms */
    PPS_MEDIA_UINT64 seq;                                   /* sequence number */
    PPS_MEDIA_UINT32 bit_width;                             /* 8,16,32 */
    pps_media_audio_sound_mode_e sound_mode;                /* mono or stereo */
    PPS_MEDIA_UINT32 sample_rate;
} __attribute__((packed)) pps_media_audio_frame_t;

typedef struct {
    pps_media_payload_type_e payload;
    pps_media_pic_size_e pic_size;
    pps_media_size_t resolution;
    pps_media_image_quality_e quality;                      /* deprecated param */
    pps_media_codec_profile_e profile;                      /* snapshot no need to fill */
    PPS_MEDIA_UINT32 bit_rate;                              /* dynamic: Unit in kbps, snapshot no need to fill */
    pps_media_rc_e rc_mode;
    PPS_MEDIA_UINT32 fps;                                   /* set fps */
    PPS_MEDIA_UINT32 cur_fps;                               /* current fps */
    PPS_MEDIA_UINT32 min_qp;                                /* dynamic: */
    PPS_MEDIA_UINT32 max_qp;                                /* dynamic: */
    PPS_MEDIA_UINT32 gop_second;                            /* dynamic: */
    PPS_MEDIA_UINT32 cur_gop_sec;                           /* current gop second */
    PPS_MEDIA_UINT32 ref_frame_num;
} pps_media_video_codec_param_t;

typedef struct {
    pps_media_payload_type_e payload;
    PPS_MEDIA_UINT32 bit_width;
    PPS_MEDIA_UINT32 sample_rate;
    PPS_MEDIA_UINT32 sample_number;
    PPS_MEDIA_UINT32 channels;
} pps_media_audio_codec_param_t;

typedef enum {
    PPS_MEDIA_TYPE_INVALID = 0xffffffff,
    PPS_MEDIA_TYPE_VIDEO = 0,
    PPS_MEDIA_TYPE_AUDIO = 1,
} pps_media_type_media_e;

typedef struct {
    pps_media_type_media_e media;               /* RW */
    pps_media_dev_type_e bind_dev_type;
    int bind_dev_id;
    union {
        pps_media_video_codec_param_t vc;       /* RW */
        pps_media_audio_codec_param_t ac;       /* RW */
    };
    int pool_id;
} pps_media_avcodec_param_t;

typedef struct {
    PPS_MEDIA_UINT32 ai_gain;
    PPS_MEDIA_UINT32 ai_vol;
    PPS_MEDIA_UINT32 ai_bit_width;
    PPS_MEDIA_UINT32 ai_sample_rate;
    PPS_MEDIA_UINT32 ai_sample_number;
    PPS_MEDIA_UINT32 ai_channels;
    PPS_MEDIA_BOOL ai_nr_enable;
    PPS_MEDIA_UINT32 ai_nr_level;
    PPS_MEDIA_BOOL ai_agc_enable;
    PPS_MEDIA_UINT32 ai_agc_target_level;
    PPS_MEDIA_UINT32 ai_agc_max_gain;
    PPS_MEDIA_BOOL ai_hpf_enable;
    PPS_MEDIA_UINT32 ai_hpf_cofrequency;
    PPS_MEDIA_BOOL aec_enable;
    PPS_MEDIA_UINT32 ao_gain; /* reserved */
    PPS_MEDIA_UINT32 ao_vol; /* reserved */
    PPS_MEDIA_UINT32 ao_bit_width; /* reserved */
    PPS_MEDIA_UINT32 ao_sample_rate; /* reserved */
    PPS_MEDIA_UINT32 ao_sample_number; /* reserved */
    PPS_MEDIA_UINT32 ao_channels; /* reserved */
    PPS_MEDIA_BOOL ao_nr_enable; /* reserved */
    PPS_MEDIA_UINT32 ao_nr_level; /* reserved */
    PPS_MEDIA_BOOL ao_agc_enable; /* reserved */
    PPS_MEDIA_UINT32 ao_agc_target_level; /* reserved */
    PPS_MEDIA_UINT32 ao_agc_max_gain; /* reserved */
    PPS_MEDIA_BOOL ao_hpf_enable; /* reserved */
    PPS_MEDIA_UINT32 ao_hpf_cofrequency; /* reserved */
} pps_media_audio_device_attr_t;

typedef enum {
    PPS_MEDIA_VIDEO_INFO_MD = 0,            /* Motion detection info */
    PPS_MEDIA_VIDEO_INFO_PD = 1,            /* People detection info in the region retrained */
    PPS_MEDIA_VIDEO_INFO_FD = 2,            /* Face detection info */
    PPS_MEDIA_VIDEO_INFO_IR = 3,            /* Day and Night mode event, info_data: int, 0=day, 1=night */
    PPS_MEDIA_VIDEO_INFO_MOTION_TRACK = 4,  /* motion track info: pps_media_rect_t*N */
    PPS_MEDIA_VIDEO_INFO_BARCODE = 5,       /* barcode scan result */
    PPS_MEIDA_VIDEO_INFO_VO_RESOLUTION = 6, /* event of HDMI hot plug, info_data: pps_media_vo_resolution_e */
    PPS_MEDIA_VIDEO_INFO_PD_IN_VISION = 7,  /* People detection info in the field of vision */
    PPS_MEDIA_VIDEO_INFO_MD_IN_VISION = 8,  /* Moving detection info in the field of vision */
    PPS_MEDIA_VIDEO_INFO_CAR = 9,           /* Car detection info, only support in people detection*/
    PPS_MEDIA_VIDEO_INFO_PET = 10,          /* Pet detection info for 4cls*/
    PPS_MEDIA_VIDEO_INFO_PETD = PPS_MEDIA_VIDEO_INFO_PET,              /* pet detection info */
    PPS_MEDIA_VIDEO_INFO_PACKAGE = 11,      /* Package detection info, only support in people detection */
    PPS_MEDIA_VIDEO_INFO_CAR_IN_VISION = 12,           /* Car detection info info in the field of vision */
    PPS_MEDIA_VIDEO_INFO_PET_IN_VISION = 13,          /* Pet detection info info in the field of vision */
    PPS_MEDIA_VIDEO_INFO_PACKAGE_IN_VISION = 14,      /* Package detection info in the field of vision */
    PPS_MEDIA_VIDEO_INFO_PIR_REAL_ALARM,
} pps_media_video_info_type_e;

typedef enum {
    PPS_MEDIA_AVPROC_TYPE_MOTION_DETECT = 0,
    PPS_MEDIA_AVPROC_TYPE_PEOPLE_DETECT = 1,
    PPS_MEDIA_AVPROC_TYPE_BABYCRYING_DETECT = 2,
    PPS_MEDIA_AVPROC_TYPE_FACE_DETECT = 3,
    PPS_MEDIA_AVPROC_TYPE_FOUR_CLS_DETECT,
    PPS_MEDIA_AVPROC_TYPE_PIR_REAL_ALARM,
    PPS_MEDIA_AVPROC_TYPE_DOGBARK_DETECT,
    PPS_MEDIA_AVPROC_TYPE_PET_DETECT,
} pps_media_avproc_type_e;

typedef enum {
    PPS_MEDIA_IRCUT_LEVEL_NORMAL,
    PPS_MEDIA_IRCUT_LEVEL_LOW,
    PPS_MEDIA_IRCUT_LEVEL_HIGH,
    PPS_MEDIA_IRCUT_LEVEL_MAX
} pps_media_ircut_level_e;

typedef enum {
    PPS_MEDIA_AUDIO_INFO_BCD = 0,           /* Baby crying detection info, info data: NULL */
    PPS_MEDIA_AUDIO_INFO_DBD,               /* Dog Bark detection info, info data: NULL */
} pps_media_audio_info_type_e;

typedef enum {
    PPS_MEDIA_FONT_STYLE_PLAIN = 0,
    PPS_MEDIA_FONT_STYLE_CONTOUR = 1,
    PPS_MEDIA_FONT_STYLE_SHADOW = 2,
} pps_media_font_style_e;

typedef enum {
    PPS_MEDIA_DETECTION_REGION_TYPE_GRID = 0,
    PPS_MEDIA_DETECTION_REGION_TYPE_POLYGON = 1,
} pps_media_detection_region_type_e;

typedef enum {
    PPS_MEDIA_MISC_INFO_TYPE_IRCUT = 0,
    PPS_MEDIA_MISC_INFO_TYPE_CELSIUS = 1,
} pps_media_misc_info_type_e;

typedef struct {
    int (*led_ctrl)(int id, int mode);
    int (*ircut_ctrl)(int id, int mode);
    int (*infrared_ctrl)(int id, int mode);
} pps_media_strnio_ops_t;

typedef enum
{
    PPS_MEDIA_PD_DETECT_PERSON = 0,
    PPS_MEDIA_PD_DETECT_CAR = 1,
    PPS_MEDIA_PD_DETECT_PET = 2,
    PPS_MEDIA_PD_DETECT_PACKAGE = 3,
    PPS_MEDIA_PD_DETECT_CLASS_ID_BUFF = 4,
} pps_media_pd_detect_type_t;

typedef struct {
    /* deprecated, please use 'level' instead */
    PPS_MEDIA_BOOL pd_person_enable;
    PPS_MEDIA_BOOL pd_car_enable;
    PPS_MEDIA_BOOL pd_pet_enable;
    PPS_MEDIA_BOOL pd_package_enable;
    PPS_MEDIA_UINT sensitivity;
    pps_media_md_sensitivity_level_e level;
    PPS_MEDIA_BOOL md_grid_enabled;
    pps_media_detection_region_type_e region_type;
    int vertex[PPS_MEDIA_DETECTION_MAX_AREA];
    pps_media_corrd_t coordinate[PPS_MEDIA_DETECTION_MAX_AREA];
    PPS_MEDIA_BOOL md_grid[PPS_MEDIA_MD_GRID_ROW][PPS_MEDIA_MD_GRID_COL];
} pps_media_region_t;

typedef struct {
    /* common */
    PPS_MEDIA_BOOL enable_bbox;

    union {
        struct {
            pps_media_region_t region;
        } md;
        struct {
            pps_media_region_t region;
        } pd;
    } data;
    int score_threshold;
} pps_media_avproc_attr_t;

typedef struct {
    PPS_MEDIA_BOOL is_show;
    PPS_MEDIA_UINT32 transparency;          /* 0~100, unit: percent */
    pps_media_point_t start_pos;
    pps_media_size_t region_size;
    pps_media_font_style_e font_style;
    PPS_MEDIA_BOOL is_dextrorotation;
    PPS_MEDIA_UINT16 ttf_pixel;          /* ttf shadow pixels number */
    PPS_MEDIA_UINT16 ttf_alpha;          /* 0~100, alpha value for ttf shadow */
} pps_media_osd_disp_attr_t;

typedef enum {
    PPS_MEDIA_YYYY_MM_DD_24HOURS = 0,
    PPS_MEDIA_YYYY_S_MM_S_DD_12HOURS = 1,
    PPS_MEDIA_MM_S_DD_S_YYYY_12HOURS = 2,
    PPS_MEDIA_MM_DD_YYYY_12HOURS = 3,
    PPS_MEDIA_DD_MM_YYYY_24HOURS = 4,
    PPS_MEDIA_MM_DD_YYYY_24HOURS = 5,
    PPS_MEDIA_YYYY_MM_DD_12HOURS = 6,
    PPS_MEDIA_DD_MM_YYYY_12HOURS = 7,
    PPS_MEDIA_MM_S_DD_S_YYYY_24HOURS = 8,
} pps_media_osd_time_format_e;

typedef enum {
    PPS_MEDIA_OSD_TYPE_TIME = 0,
    PPS_MEDIA_OSD_TYPE_STRING = 1,
    PPS_MEDIA_OSD_TYPE_BITMAP = 2,
    PPS_MEDIA_OSD_TYPE_BUTT
} pps_media_osd_type_e;

typedef struct {
    char osd_str[PPS_MEDIA_OSD_STR_NAME];
    char logo_file[PPS_MEDIA_LOGO_NAME];
    time_t osd_time;
    char osd_time_prefix[16];
    char osd_time_subfix[16];
} pps_media_osd_content_t;

typedef struct {
    pps_media_osd_type_e osd_type;
    pps_media_osd_time_format_e osd_time_format;
    pps_media_venc_id_e attach_venc_id;
    pps_media_osd_content_t content;
    pps_media_osd_disp_attr_t disp_attr;
    PPS_MEDIA_BOOL osd_time_with_celsius;
} pps_media_osd_param_t;

typedef struct {
    PPS_MEDIA_BOOL is_mirror;
    PPS_MEDIA_BOOL is_flip;  /* turn upside down, doesn't means rotating 180 degree. */
} pps_media_video_image_orientation_t;

typedef enum {
    PPS_MEDIA_VIDEO_MODE_NORMAL     = 0x0,
    PPS_MEDIA_VIDEO_MODE_IR         = 0x1,
    PPS_MEDIA_VIDEO_MODE_AUTO       = 0x2,
    PPS_MEDIA_VIDEO_MODE_WARM_LIGHT = 0x3,
    PPS_MEDIA_VIDEO_MODE_FLOODLIGHT = 0x4,
    PPS_MEDIA_VIDEO_MODE_DUSK       = 0x5,
    PPS_MEDIA_VIDEO_MODE_DEEP_NIGHT = 0x6,
    PPS_MEDIA_VIDEO_MODE_BUTT,
} pps_media_video_mode_e;

typedef enum {
    PPS_MEDIA_FILL_LIGHT_TYPE_INFRARED = 0,
    PPS_MEDIA_FILL_LIGHT_TYPE_VISIBLE = 1,
    PPS_MEDIA_FILL_LIGHT_TYPE_NONE,
} pps_media_fill_light_type_e;

typedef enum {
    PPS_MEDIA_ANTIFLICKER_MODE_DISABLE = 0x0,
    PPS_MEDIA_ANTIFLICKER_MODE_AUTO = 1,
    PPS_MEDIA_ANTIFLICKER_MODE_50HZ = 2,
    PPS_MEDIA_ANTIFLICKER_MODE_60HZ = 3,
    PPS_MEDIA_ANTIFLICKER_MODE_BUTT
} pps_media_antiflicker_mode_e;

typedef struct {
    PPS_MEDIA_UINT32 luma;          /* [0, 0xFFFFFFFF] */
    PPS_MEDIA_UINT32 rgain;         /* [0, 0xFFFFFFFF] */
    PPS_MEDIA_UINT32 bgain;         /* [0, 0xFFFFFFFF] */
    PPS_MEDIA_UINT32 color_temp;   /* [0, 0xFFFFFFFF] */
} pps_media_isp_wb_info_t;

typedef struct {
    PPS_MEDIA_UINT32 exposure_time; /* [0, 0xFFFFFFFF] */
    PPS_MEDIA_UINT32 exposure_value; /* [0, 0xFFFFFFFF] */
    PPS_MEDIA_UINT32 frame_num;
    PPS_MEDIA_UINT32 frame_den; /* fps = frame_num / frame_den */
} pps_media_isp_exposure_info_t;

typedef struct {
    unsigned int min_fps;
    unsigned int max_fps;
} pps_media_fps_range_t;

typedef struct {
    PPS_MEDIA_BOOL auto_ctrl_enable;
    pps_media_fps_range_t day_fps_range;
    pps_media_fps_range_t night_fps_range;
} pps_media_auto_fps_ctrl_t;

typedef struct {
    PPS_MEDIA_UINT32 frm_num;
    PPS_MEDIA_UINT32 af_metrics;       /**< AF主统计值*/
    PPS_MEDIA_UINT32 af_metrics_alt;   /**< AF次统计值*/
    PPS_MEDIA_UINT32 af_h;
    PPS_MEDIA_UINT32 af_l;
} pps_media_isp_metrices_info_t;

typedef enum {
    PPS_MEDIA_ISP_INFO_TYPE_WB = 0x0,       /* pps_media_isp_wb_info_t */
    PPS_MEDIA_ISP_INFO_TYPE_EXPOSURE = 1,       /* pps_media_isp_exposure_info_t */
    PPS_MEDIA_ISP_INFO_TYPE_FORCUS = 2,         /* undefined */
    PPS_MEDIA_ISP_INFO_TYPE_AUTOFPS = 3,
    PPS_MEDIA_ISP_INFO_TYPE_METRICS = 4,        /* AF */
    PPS_MEDIA_ISP_INFO_TYPE_AF_INFO = 5,
    PPS_MEDIA_ISP_INFO_TYPE_BUTT
} pps_media_isp_info_type_e;

typedef struct {
    /* value range: [0, 100], 50 is default */
    PPS_MEDIA_UINT32 brightness;
    /* value range: [0, 100], 50 is default */
    PPS_MEDIA_UINT32 contrast;
    /* value range: [0, 100], 50 is default */
    PPS_MEDIA_UINT32 sharpness;
    /* value range: [0, 100], 50 is default */
    PPS_MEDIA_UINT32 saturation;
} pps_media_vi_image_param_t;

typedef struct {
    PPS_MEDIA_UINT32 luma;                     /* luminance:   0 ~ 100 default: 50 */
    PPS_MEDIA_UINT32 contrast;                 /* contrast :   0 ~ 100 default: 50 */
    PPS_MEDIA_UINT32 hue;                      /* hue      :   0 ~ 100 default: 50 */
    PPS_MEDIA_UINT32 saturation;               /* saturation:  0 ~ 100 default: 40 */
} pps_media_vo_csc_param_t;

typedef enum {
    PPS_MEDIA_VO_RESOLUTION_NULL = -1,
    PPS_MEDIA_VO_RESOLUTION_BEGIN   = 0x0,
    PPS_MEDIA_VO_RESOLUTION_800x600_60 = 0x0,
    PPS_MEDIA_VO_RESOLUTION_1024x768_60 = 1,
    PPS_MEDIA_VO_RESOLUTION_1280x1024_60 = 2,
    PPS_MEDIA_VO_RESOLUTION_1280x800_60 = 3,
    PPS_MEDIA_VO_RESOLUTION_1366x768_60 = 4,
    PPS_MEDIA_VO_RESOLUTION_1440x900_60 = 5,
    PPS_MEDIA_VO_RESOLUTION_1680x1050_60 = 6,
    PPS_MEDIA_VO_RESOLUTION_1600x1200_60 = 7,
    PPS_MEDIA_VO_RESOLUTION_2560x1440_30 = 8,
    PPS_MEDIA_VO_RESOLUTION_3840x2160_30 = 9,
    PPS_MEDIA_VO_RESOLUTION_720P30 = 10,
    PPS_MEDIA_VO_RESOLUTION_720P50 = 11,
    PPS_MEDIA_VO_RESOLUTION_720P60 = 12,
    PPS_MEDIA_VO_RESOLUTION_1080P30 = 13,
    PPS_MEDIA_VO_RESOLUTION_1080P50 = 14,
    PPS_MEDIA_VO_RESOLUTION_1080P60 = 15,
    PPS_MEDIA_VO_RESOLUTION_1920x1200_60 = 16,
    PPS_MEDIA_VO_RESOLUTION_3840x2160_60 = 17,
    PPS_MEDIA_VO_RESOLUTION_1080P60_TO_4K = 18,
    PPS_MEDIA_VO_RESOLUTION_2560x1440_30_TO_4K = 19,
    PPS_MEDIA_VO_RESOLUTION_3840x2160_50 = 20,
    PPS_MEDIA_VO_RESOLUTION_2560x1440_50_TO_4K = 21,
    PPS_MEDIA_VO_RESOLUTION_END,
} pps_media_vo_resolution_e;

typedef enum
{
    PPS_MEDIA_PIXEL_FMT_RGB_555 = 0x0,
    PPS_MEDIA_PIXEL_FMT_RGB_565 = 1,
    PPS_MEDIA_PIXEL_FMT_RGB_888 = 2,

    PPS_MEDIA_PIXEL_FMT_ARGB_1555 = 3,
    PPS_MEDIA_PIXEL_FMT_ARGB_4444 = 4,
    PPS_MEDIA_PIXEL_FMT_ARGB_8888 = 5,

    PPS_MEDIA_PIXEL_FMT_YUV_PLANAR_422 = 6,
    PPS_MEDIA_PIXEL_FMT_YUV_PLANAR_420 = 7,
    PPS_MEDIA_PIXEL_FMT_YUV_PLANAR_444 = 8,

    PPS_MEDIA_PIXEL_FMT_YUV_SEMIPLANAR_422 = 9,
    PPS_MEDIA_PIXEL_FMT_YUV_SEMIPLANAR_420 = 10,
    PPS_MEDIA_PIXEL_FMT_YUV_SEMIPLANAR_444 = 11,

    /* 1Byte for 1Pixel, black-white data info, >0 for white, =0 for black */
    PPS_MEDIA_PIXEL_FMT_MONO = 12,

    /* ssr621 GFX support */
    PPS_MEDIA_PIXEL_FMT_RGBA_5551 = 13,
    PPS_MEDIA_PIXEL_FMT_RGBA_4444 = 14,
    PPS_MEDIA_PIXEL_FMT_ABGR_8888 = 15,
    PPS_MEDIA_PIXEL_FMT_BGRA_5551 = 16,
    PPS_MEDIA_PIXEL_FMT_ABGR_1555 = 17,
    PPS_MEDIA_PIXEL_FMT_ABGR_4444 = 18,
    PPS_MEDIA_PIXEL_FMT_BGRA_4444 = 19,
    PPS_MEDIA_PIXEL_FMT_BGR_565 = 20,
    PPS_MEDIA_PIXEL_FMT_RGBA_8888 = 21,
    PPS_MEDIA_PIXEL_FMT_BGRA_8888 = 22,

    PPS_MEDIA_PIXEL_FMT_NV12 = 23
} pps_media_pixel_format_e;

typedef enum {
    PPS_MEDIA_IMAGE_FMT_RAW = 0,
    PPS_MEDIA_IMAGE_FMT_BMP = 1,
    PPS_MEDIA_IMAGE_FMT_JPEG = 2,
    PPS_MEDIA_IMAGE_FMT_PNG = 3,
} pps_media_image_format_e;

typedef enum {
    PPS_MEDIA_VO_VIDEO_LAYER_0 = 0x0,
    PPS_MEDIA_VO_VIDEO_LAYER_1 = 1,
    PPS_MEDIA_VO_VIDEO_LAYER_PIP = 2,
    PPS_MEDIA_VO_VIDEO_LAYER_MAX = 3,
} pps_media_vo_video_layer_e;

typedef enum {
    PPS_MEDIA_VO_GUI_LAYER_0 = 0,
    PPS_MEDIA_VO_GUI_LAYER_1,
    PPS_MEDIA_VO_GUI_LAYER_2,
    PPS_MEDIA_VO_GUI_LAYER_3,
    PPS_MEDIA_VO_GUI_LAYER_4,
    PPS_MEDIA_VO_GUI_LAYER_5,
    PPS_MEDIA_VO_GUI_LAYER_6,
    PPS_MEDIA_VO_GUI_LAYER_7,
    PPS_MEDIA_VO_GUI_LAYER_MAX,
} pps_media_vo_gui_layer_e;

/* windows on layer */
typedef enum {
    PPS_MEDIA_VO_WINDOW_0 = 0x0,
    PPS_MEDIA_VO_WINDOW_1,
    PPS_MEDIA_VO_WINDOW_2,
    PPS_MEDIA_VO_WINDOW_3,
    PPS_MEDIA_VO_WINDOW_4,
    PPS_MEDIA_VO_WINDOW_5,
    PPS_MEDIA_VO_WINDOW_6,
    PPS_MEDIA_VO_WINDOW_7,
    PPS_MEDIA_VO_WINDOW_8,
    PPS_MEDIA_VO_WINDOW_9,
    PPS_MEDIA_VO_WINDOW_10,
    PPS_MEDIA_VO_WINDOW_11,
    PPS_MEDIA_VO_WINDOW_12,
    PPS_MEDIA_VO_WINDOW_13,
    PPS_MEDIA_VO_WINDOW_14,
    PPS_MEDIA_VO_WINDOW_15,
    PPS_MEDIA_VO_WINDOW_16,
    PPS_MEDIA_VO_WINDOW_17,
    PPS_MEDIA_VO_WINDOW_18,
    PPS_MEDIA_VO_WINDOW_19,
    PPS_MEDIA_VO_WINDOW_20,
    PPS_MEDIA_VO_WINDOW_21,
    PPS_MEDIA_VO_WINDOW_22,
    PPS_MEDIA_VO_WINDOW_23,
    PPS_MEDIA_VO_WINDOW_24,
    PPS_MEDIA_VO_WINDOW_25,
    PPS_MEDIA_VO_WINDOW_26,
    PPS_MEDIA_VO_WINDOW_27,
    PPS_MEDIA_VO_WINDOW_28,
    PPS_MEDIA_VO_WINDOW_29,
    PPS_MEDIA_VO_WINDOW_30,
    PPS_MEDIA_VO_WINDOW_31,
    PPS_MEDIA_VO_WINDOW_32,
    PPS_MEDIA_VO_WINDOW_33,
    PPS_MEDIA_VO_WINDOW_34,
    PPS_MEDIA_VO_WINDOW_35,
    PPS_MEDIA_VO_WINDOW_MAX_PER_LAYER,
} pps_media_vo_window_e;

/* screen mode */
typedef enum {
    PPS_MEDIA_SCREEN_MODE_0_WIN = 0x0,
    PPS_MEDIA_SCREEN_MODE_1_WIN = 1,
    PPS_MEDIA_SCREEN_MODE_4_WIN = 2,
    PPS_MEDIA_SCREEN_MODE_6_WIN = 3,
    PPS_MEDIA_SCREEN_MODE_8_WIN = 4,
    PPS_MEDIA_SCREEN_MODE_9_WIN = 5,
    PPS_MEDIA_SCREEN_MODE_16_WIN = 6,
    PPS_MEDIA_SCREEN_MODE_13_WIN = 7,
    PPS_MEDIA_SCREEN_MODE_25_WIN = 8,
    PPS_MEDIA_SCREEN_MODE_36_WIN = 9,
    PPS_MEDIA_SCREEN_MODE_EX_4_WIN = 10,
    PPS_MEDIA_SCREEN_MODE_7_WIN = 11,
    PPS_MEDIA_SCREEN_MODE_MAX,
} pps_media_screen_mode_e;

typedef enum
{
    PPS_MEDIA_OPERATE_NONE = 0,
    PPS_MEDIA_OPERATE_QUICKCOPY,
    PPS_MEDIA_OPERATE_CLIP,
    PPS_MEDIA_OPERATE_MIRROR,
    PPS_MEDIA_OPERATE_RESIZE,
    PPS_MEDIA_OPERATE_OSD_BOX,
    PPS_MEDIA_OPERATE_ROTATE,
    PPS_MEDIA_OPERATE_CLIP_AND_RESIZE
} pps_media_operate_e;
typedef enum
{
    PPS_MEDIA_MIRROR_NONE = 0,
    PPS_MEDIA_MIRROR_HORIZONTAL,
    PPS_MEDIA_MIRROR_VERTICAL,
    PPS_MEDIA_MIRROR_BOTH,
    PPS_MEDIA_MIRROR_MAX
} pps_media_mirror_e;

typedef enum
{
    PPS_MEDIA_ROTATE_0 = 0,
    PPS_MEDIA_ROTATE_90,
    PPS_MEDIA_ROTATE_180,
    PPS_MEDIA_ROTATE_270,
    PPS_MEDIA_ROTATE_MAX
} pps_media_rotate_e;

typedef struct {
    PPS_MEDIA_BOOL is_alpha_enable;
    PPS_MEDIA_UINT8 alpha_value;
} pps_media_vo_gui_alpha_t;

typedef struct {
    PPS_MEDIA_BOOL is_key_enable;
    PPS_MEDIA_UINT8 red;
    PPS_MEDIA_UINT8 green;
    PPS_MEDIA_UINT8 blue;
} pps_media_vo_gui_colorkey_t;

typedef struct {
    PPS_MEDIA_VOID *vir_addr;
    PPS_MEDIA_UINT32 dma_addr;
    PPS_MEDIA_UINT32 size;
    PPS_MEDIA_UINT32 stride;
} pps_media_buffer_t;

typedef struct
{
    pps_media_image_format_e format;
    PPS_MEDIA_UINT32 size;
    PPS_MEDIA_UINT32 width;
    PPS_MEDIA_UINT32 height;
} pps_media_image_info_t;

typedef struct {
    pps_media_rect_t rect;
    pps_media_pixel_format_e format;
    pps_media_vo_gui_alpha_t alpha_param;
    pps_media_buffer_t buffer;
} pps_media_vo_gui_param_t;

typedef struct {
    pps_media_operate_e operate;
    pps_media_rect_t clip_rect;
    pps_media_mirror_e mirror;
    pps_media_rotate_e rotate;
    pps_media_rect_t osd_box_rect;
} pps_media_gui_opt_t;

typedef enum
{
    PPS_MEDIA_GUI_CURSOR_ATTR_MASK_ICON = 0x1,
    PPS_MEDIA_GUI_CURSOR_ATTR_MASK_POS = 0x2,
    PPS_MEDIA_GUI_CURSOR_ATTR_MASK_SHOW = 0x4,
    PPS_MEDIA_GUI_CURSOR_ATTR_MASK_HIDE = 0x8,
    PPS_MEDIA_GUI_CURSOR_ATTR_MASK_ALL = 0xF
} pps_media_gui_cursor_attr_mask_e;

typedef struct pps_media_gui_cursor_image_s
{
    unsigned int width;                 /* width, unit pixel */
    unsigned int height;                /* Height, unit pixel */
    unsigned int pitch;                 /* Pitch, unit pixel */
    pps_media_pixel_format_e color_fmt; /* Color format */
    char *data;                         /* Image raw data */
} pps_media_gui_cursor_image_t;

typedef struct pps_media_gui_cursor_attr_s
{
    pps_media_point_t pos;
    pps_media_point_t hotspot;
    PPS_MEDIA_BOOL is_show;
    pps_media_gui_cursor_image_t img_info;
    unsigned int attr_mask;
} pps_media_gui_cursor_attr_t;

typedef struct pps_media_pool_s {
    char *pool_name;
    int size;
    pps_media_dev_type_e attach_dev_type;
    pps_media_payload_type_e payload;
    pps_media_size_t pic_size;
    PPS_MEDIA_UINT32 ref_frame_num;
} pps_media_pool_t;

typedef int  (*pps_media_video_stream_cb)(int dev_id, pps_media_video_packet_t *f);
typedef int  (*pps_media_audio_stream_cb)(int dev_id, pps_media_audio_packet_t *f);

typedef int  (*pps_media_video_frame_cb)(int dev_id, int chn_id, pps_media_video_frame_t *f);
typedef int  (*pps_media_video_info_cb)(pps_media_video_info_type_e type, void *info_data, int info_len);
typedef int  (*pps_media_audio_info_cb)(pps_media_audio_info_type_e type, void *info_data, int info_len);
typedef void (*pps_media_print_cb)(int level, const char *filename, int line, const char *format, va_list ap);

#define video_stream_cb pps_media_video_stream_cb
#define audio_stream_cb pps_media_audio_stream_cb
#define video_info_cb   pps_media_video_info_cb
#define audio_info_cb   pps_media_audio_info_cb
#define video_frame_cb  pps_media_video_frame_cb

#define PPS_MEDIA_BARCODE_MAX_SIZE (1024)

typedef enum {
    PPS_MEDIA_BARCODE_TYPE_QR = 0x1,
    PPS_MEDIA_BARCODE_TYPE_C49 = 0x2,
    PPS_MEDIA_BARCODE_TYPE_C39 = 0x4,
} pps_media_barcode_type_e;

typedef struct {
    pps_media_barcode_type_e type;
    char code[PPS_MEDIA_BARCODE_MAX_SIZE];
    int code_len;
} pps_media_barcode_result_t;

#ifdef __cplusplus
}
#endif

#endif /* __PPS_MEDIA_COMMON_H__ */
