/**
 * @file        pps_media_errno.h
 *
 * @copyright   2015-2020 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author      Agogo
 *
 * @date        2019/1/1
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */
#ifndef _PPS_MEDIA_ERRNO_H
#define _PPS_MEDIA_ERRNO_H

#ifdef __cplusplus
extern "C" {
#endif

#define PPS_MEDIA_FAILURE           -1
#define PPS_MEDIA_SUCCESS           0

typedef enum {
    PPS_MEDIA_ERROR_BASE            = 15021100,
    PPS_MEDIA_ERROR_DEVOPEN         = PPS_MEDIA_ERROR_BASE + 1,
    PPS_MEDIA_ERROR_OPERATE         = PPS_MEDIA_ERROR_BASE + 2,
    PPS_MEDIA_ERROR_NO_DATA         = PPS_MEDIA_ERROR_BASE + 3,
    PPS_MEDIA_ERROR_NOT_EXIST       = PPS_MEDIA_ERROR_BASE + 4,
    PPS_MEDIA_ERROR_BAD_ADDR        = PPS_MEDIA_ERROR_BASE + 5,
    PPS_MEDIA_ERROR_NO_MEM          = PPS_MEDIA_ERROR_BASE + 6,
    PPS_MEDIA_ERROR_INVALID_PARAM   = PPS_MEDIA_ERROR_BASE + 7,
    PPS_MEDIA_ERROR_UNSUPPORT       = PPS_MEDIA_ERROR_BASE + 8,
    PPS_MEDIA_ERROR_NOT_CONFIG      = PPS_MEDIA_ERROR_BASE + 9,
    PPS_MEDIA_ERROR_ILL_ENCODEID    = PPS_MEDIA_ERROR_BASE + 10,
    PPS_MEDIA_ERROR_ILL_DECODEID    = PPS_MEDIA_ERROR_BASE + 11,
    PPS_MEDIA_ERROR_INVALID_CMD     = PPS_MEDIA_ERROR_BASE + 12,
    PPS_MEDIA_ERROR_NOT_PERMIT      = PPS_MEDIA_ERROR_BASE + 13,
    PPS_MEDIA_ERROR_EXIST           = PPS_MEDIA_ERROR_BASE + 14,
    PPS_MEDIA_ERROR_BUSY            = PPS_MEDIA_ERROR_BASE + 15,
} PPS_MEDIA_ERR_TYPE;

#ifdef __cplusplus
}
#endif

#endif /* _PPS_MEDIA_ERRNO_H */
