/**
 * @file        dua_common_inner.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua 内部头文件
 * @author      Shi Yanlin
 * @date        2023/03/17
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_COMMON_INNER_H_
#define _DUA_COMMON_INNER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "dua_common.h"
#include "dua_event_def.h"
#include "mcp_list.h"
#include "hal_flash_def.h"
#ifndef DUA_CONFIG_CROPPED_SDK
#include "pps_media_common.h"
#endif

#define DUA_HANDLER_MAGIC_NUMBER     0x565600ee
#define AVPROC_HANDLER_MAGIC_NUMBER  0x565601ee
#define NETWORK_HANDLER_MAGIC_NUMBER 0x565602ee
#define PIR_HANDLER_MAGIC_NUMBER     0x565603ee

#define UPGRADE_RECOVE_PARTATION "backup.img"
#define UPGRADE_UIMAGE_PARTATION "uImage"

#define ROI_BITMAP_SIZE (36)

typedef struct dua_network_handler {
    pps_char  if_name[32];
    pps_void *net_handler;
} DUA_NETWORK_HANDLER_T, *DUA_NETWORK_HANDLER_PTR;

typedef enum avproc_model_type{
    AVPROC_MODEL_VIDEO   = 0,
    AVPROC_MODEL_AUDIO   = 1,
    AVPROC_MODEL_MAX     = 2,
}AVPROC_MODEL_TYPE_E;

#ifdef DUA_CONFIG_CROPPED_SDK
typedef union avproc_union {
    DUA_BOARD_INFO_PTR board_info;
} AVPROC_UNION_T;
#else
// sensor_id + 结构体(套一个共用体)
typedef union avproc_union {
    pps_media_avproc_attr_t *attr;
    DUA_BOARD_INFO_PTR board_info;
} AVPROC_UNION_T;
#endif

typedef struct avproc_data {
    pps_s32             enable;         // 使能
    pps_s32             value;          // 灵敏度
    DUA_AVPROC_TYPE_E   type;           // 算法类型
    AVPROC_MODEL_TYPE_E av_model_type;  // veido/audio
    AVPROC_UNION_T      av_union;       // 特殊参数
} AVPROC_DATA_T;

typedef pps_s32 (*avproc_init_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data, MCP_LIST_PTR ev_cb);
typedef pps_s32 (*avproc_deinit_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_start_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_stop_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_enable_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_set_detect_value_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_set_detect_zone_func)(pps_s32 sensor_id, AVPROC_DATA_T av_data);
typedef pps_s32 (*avproc_single_detect_func)(pps_s32 sensor_id, pps_void *avbuf, pps_u32 buflen, pps_u8 *result);

#ifdef DUA_CONFIG_CROPPED_SDK
typedef struct avproc_handler {
    pps_s32 res;
} AVPROC_HANDLER_T, *AVPROC_HANDLER_PTR;
#else
typedef struct avproc_handler {
    pps_u8                       inited[DUA_SENSOR_MAX];
    pps_s32                      enable[DUA_SENSOR_MAX];
    DUA_AVPROC_TYPE_E            type;              // 算法类型
    AVPROC_MODEL_TYPE_E          model_type;        // 算法大类
    pps_media_avproc_attr_t      media_avproc_attr; // 媒体算法参数
    avproc_init_func             init_func;
    avproc_deinit_func           deinit_func;
    avproc_start_func            start_func;
    avproc_stop_func             stop_func;
    avproc_enable_func           enable_func;
    avproc_set_detect_zone_func  set_detect_zone_func;
    avproc_set_detect_value_func set_detect_value_func;
    avproc_single_detect_func    single_detect_func;
} AVPROC_HANDLER_T, *AVPROC_HANDLER_PTR;
#endif

/** @struct  dua_handler
 * @brief   <dua 总句柄>
 */
typedef struct dua_handler {
    pps_u32 magic;
    pps_u32 dev_auth_check_ok;
    // 加密信息
    HAL_FLASH_BASE_ENC_INFO_T base_enc_info;
    HAL_FLASH_ENC_INFO_EX1_T  enc_ex_info;
    HAL_FLASH_ENC_INFO_EX2_T  enc_ex2_info;

    // 能力集
    DUA_CAPABILITY_T capa;
    DUA_EX_CAPABILITY_T ex_capa;
    // 板级信息
    DUA_BOARD_INFO_T board_info;

    // 模块句柄
    DUA_NETWORK_HANDLER_PTR net_wireless1_handler;
    DUA_NETWORK_HANDLER_PTR net_wireless2_handler;
    DUA_NETWORK_HANDLER_PTR net_wire_handler;
    DUA_NETWORK_HANDLER_PTR net_4g_handler;
    DUA_NETWORK_HANDLER_PTR net_bt_handler;

    // AV句柄
    AVPROC_HANDLER_PTR avproc_md_handler;
    AVPROC_HANDLER_PTR avproc_video_handler;
    AVPROC_HANDLER_PTR avproc_audio_handler;
    AVPROC_HANDLER_PTR avproc_noise_handler;
    AVPROC_HANDLER_PTR avproc_bcd_handler;

    // 配置信息 需要
    pps_s32 is_media_init;  // 媒体是否初始化完成
    pps_s32 is_network_int; // 网络是否初始化完成
    pps_s32 is_sdcard_int;  // sdcard是否初始化完成

} DUA_HANDLER_T, *DUA_HANDLER_PTR;

typedef enum device_partition_plan {
    DEV_16M_FLASH_DUAL_PARTITION_RUN_OS_0 = 0, // 表示 16M flash, 双分区备份方案
    DEV_16M_FLASH_DUAL_PARTITION_RUN_OS_1 = 1, // 表示 16M flash, 双分区备份方案
    DEV_16M_FLASH_DUAL_PARTITION_RUN_OS_2 = 2, // 表示 16M flash, 双分区备份方案
    DEV_16M_FLASH_WITH_RECOVE             = 3, // 表示 16M flash, 有recove分区
    DEV_8M_FLASH_WITH_RECOVE              = 4, // 表示  8M flash, 有recove分区
    DEV_8M_FLASH_WITHOUT_RECOVE           = 5, // 表示  8M flash, 无recove分区
    DEV_16M_FLASH_WITHOUT_RECOVE          = 6, // 表示  16M flash, 无recove分区
} DEVICE_PARTITION_PLAN_E;

typedef enum device_upgrade_mode {
    PLUGIN_DEVICE_UPGRADE  = 0,
    BATTERY_DEVICE_UPGRADE = 1,
} DEVICE_UPGRADE_MODE_E;

/** @struct device_upgrade_status
 * @brief  <升级信息>
 */
typedef struct device_upgrade_status {
    pps_u8 is_upgrading; // 0 - not upgrading | 1 - upgrading
    pps_u8 progess;      // 0 ~ 100
    pps_u8 res[6];       // 字节对齐预留
} DEVICE_UPGRADE_STATUS_T, *DEVICE_UPGRADE_STATUS_PTR;

#define MEDIA_RESOLUTION_THREE_MILLION 3000000
#define MEDIA_RESOLUTION_FOUR_MILLION  4000000
#define MEDIA_RESOLUTION_FIVE_MILLION  5000000

typedef struct {
    pps_u32  preview_time[7];      // preview time
    pps_u32  wakeup_time[7];       // wakeup time 唤醒时长 从开机上电到业务启动
    pps_u16  alarm_times[7];       // pir 报警成功的次数
    pps_u16  false_alarm_times[7]; // pir 报警失败的次数
    time_t   timestamp;            // 当前时间戳
    pps_bool to_merge_flag;        // 客户并不关心，默认设置为PPS_TRUE
} DUA_MCU_STATS_DATA_T;


#ifdef __cplusplus
}
#endif
#endif /* _DUA_COMMON_INNER_H_ */
