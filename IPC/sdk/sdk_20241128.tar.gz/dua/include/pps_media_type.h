/**
 * @file        pps_media_type.h
 *
 * @copyright   2015-2020 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author      Agogo
 *
 * @date        2019/1/1
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_MEDIA_TYPE_H_
#define _PPS_MEDIA_TYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#define PPS_MEDIA_NULL ((void *)0)
#define PPS_MEDIA_OK 0
#define PPS_MEDIA_ERROR -1
#define PPS_MEDIA_TRUE 1
#define PPS_MEDIA_FALSE 0

typedef unsigned int PPS_MEDIA_ERR;
typedef int	PPS_MEDIA_BOOL;
typedef void PPS_MEDIA_VOID;

typedef unsigned char PPS_MEDIA_UINT8;
typedef unsigned short PPS_MEDIA_UINT16;
typedef unsigned int PPS_MEDIA_UINT;
typedef unsigned int PPS_MEDIA_UINT32;
typedef unsigned long long PPS_MEDIA_UINT64;

typedef char PPS_MEDIA_INT8;
typedef short PPS_MEDIA_INT16;
typedef int	PPS_MEDIA_INT;
typedef int	PPS_MEDIA_INT32;
typedef long long PPS_MEDIA_INT64;

#ifdef __cplusplus
}
#endif

#endif /* _PPS_MEDIA_TYPE_H_ */
