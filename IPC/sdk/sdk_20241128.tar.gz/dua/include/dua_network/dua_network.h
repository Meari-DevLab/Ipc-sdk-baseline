/**
 * @file        dua_network.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_NETWORK_H_
#define _DUA_NETWORK_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_network_init(pps_void *dua_handler, pps_char *if_name);
 * @brief   <network module init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] if_name    : network interface name
 * @return  NULL - failure | else - success
 */
pps_void *dua_network_init(pps_void *dua_handler, pps_char *if_name);

/** @fn      pps_s32 dua_network_deinit(pps_void *dua_handler, pps_void *if_handler);
 * @brief   <network module deinit>
 * @param   [in] dua_handler: dua handler
 * @param   [in] if_handler : network interface handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_deinit(pps_void *dua_handler, pps_void *if_handler);

/** @fn      pps_s32 dua_network_event_register(pps_void *if_handler, dua_event_callback_f event_cb)
 * @brief   <register network event callback>
 * @param   [in] if_handler: interface handler
 * @param   [in] event_cb: event callback
 * @return  0 - success | else - failure
 * @note    //WIFI
 *          DUA_EVENT_NETWORK_AP_MODE_ENTER     = 0x3001, //Enter AP mode
 *          DUA_EVENT_NETWORK_AP_MODE_EXIT      = 0x3002, //Exit AP mode
 *          DUA_EVENT_NETWORK_WIFI_CONNECTING   = 0x3003, //WiFi connected
 *          DUA_EVENT_NETWORK_WIFI_CONNECTED    = 0x3004, //The wifi connection is successful
 *          DUA_EVENT_NETWORK_WIFI_DISCONNECTED = 0x3005, //WiFi connection disconnected
 *          DUA_EVENT_NETWORK_WIFI_NET_ACCESS   = 0x3006, //wifi successfully obtained IP, access net
 *          //WIRE NET
 *          DUA_EVENT_NETWORK_WIRE_NET_CONNECTING   = 0x3100, //Wired network connection
 *          DUA_EVENT_NETWORK_WIRE_NET_CONNECTED    = 0x3101, //The wired network connection is successful
 *          DUA_EVENT_NETWORK_WIRE_NET_DISCONNECTED = 0x3102, //Wired network connection failed
 *          //4G
 *          DUA_EVENT_NETWORK_4G_NET_CONNECTING   = 0x3200, //4G network connection
 *          DUA_EVENT_NETWORK_4G_NET_CONNECTED    = 0x3201, //The 4G network connection is successful
 *          DUA_EVENT_NETWORK_4G_NET_DISCONNECTED = 0x3202, //The 4G network is disconnected
 *          //BULETOOTH
 *          DUA_EVENT_NETWORK_BT_MODE_ENTER   = 0x3301, //Enter BT mode
 *          DUA_EVENT_NETWORK_BT_MODE_EXIT    = 0x3302, //Exit BT mode
 *          DUA_EVENT_NETWORK_BT_CONNECTING   = 0x3303, //The wifi connection is successful
 *          DUA_EVENT_NETWORK_BT_DISCONNECTED = 0x3304, //WiFi connection disconnected
 */
pps_s32 dua_network_event_register(pps_void *if_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_network_event_unregister(pps_void *if_handler, dua_event_callback_f event_cb)
 * @brief   <unregister network event callback>
 * @param   [in] if_handler : network interface handler
 * @param   [in] event_cb: event callback
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_event_unregister(pps_void *if_handler, dua_event_callback_f event_cb);

/** @fn      DUA_NETWORK_STATUS_PTR dua_network_get_status(pps_void *if_handler);
 * @brief   <get network status>
 * @param   [in] if_handler: network interface handler
 * @param   [in] status    : network status
 * @return  network status
 */
pps_s32 dua_network_get_status(pps_void *if_handler, DUA_NETWORK_STATUS_PTR status);

/** @fn      pps_s32 dua_network_enter_ap_mode(pps_void *if_handler, pps_char *ssid, pps_char *psw);
 * @brief   <enter ap mode>
 * @param   [in] if_handler: network interface handler
 * @param   [in] ssid      : ap ssid
 * @param   [in] psw       : ap password
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_enter_ap_mode(pps_void *if_handler, pps_char *ssid, pps_char *psw);

/** @fn      pps_s32 dua_network_exit_ap_mode(pps_void *dua_handler);
 * @brief   <exit ap mode>
 * @param   [in] if_handler: network interface handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_exit_ap_mode(pps_void *if_handler);

/** @fn      pps_s32 dua_network_connect_wifi(pps_void *if_handler, DUA_NETWORK_WIFI_PARAM_PTR wifi_list, pps_s32 wifi_list_cnt, pps_s32 connect_wifi_idx);
 * @brief   <connect wifi>
 * @param   [in] if_handler       : network interface handler
 * @param   [in] wifi_list        : connect wifi info list
 * @param   [in] wifi_list_cnt    : connect wifi info list cnt
 * @param   [in] connect_wifi_idx : connect wifi info
 * @return  0 - success | else - failure
 * @note    for plugin device, this api allows add two connect wifi informations, one is first choice wifi, others are alternate wifi.
 *          if the signal of first choice wifi is lower, device will try to connect other wifi.
 *
 *          for battery device, this api only allows add one connect wifi information.
 */
pps_s32 dua_network_connect_wifi(pps_void *if_handler, DUA_NETWORK_WIFI_PARAM_PTR wifi_list);

/** @fn      pps_s32 dua_network_disconnect_wifi(pps_void * if_handler);
 * @brief   <disconnect wifi>
 * @param   [in] if_handler: network interface handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_disconnect_wifi(pps_void *if_handler);

/** @fn      pps_s32 dua_network_get_wifi_info(pps_void *if_handler, DUA_NETWORK_WIFI_INFO_PTR wifi_info);
 * @brief   <get connect wifi info>
 * @param   [in] if_handler: network interface handler
 * @param   [in] wifi_info : WIFI info
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_wifi_info(pps_void *if_handler, DUA_NETWORK_WIFI_PARAM_PTR wifi_info);

/** @fn      pps_s32 dua_network_get_ipaddr(pps_void *if_handler, pps_char *ipaddr, pps_s32 ipaddr_len);
 * @brief   <get connect network IP address>
 * @param   [in]  if_handler : network interface handler
 * @param   [out] ipaddr     : IP address buffer
 * @param   [in]  ipaddr_len : IP address buffer len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_ipaddr(pps_char *ipaddr, pps_s32 ipaddr_len);

/** @fn      pps_s32 dua_network_get_mac(pps_void *if_handler, pps_char *mac, pps_s32 mac_len);
 * @brief   <get mac address>
 * @param   [in] if_handler: network interface handler
 * @param   [in] mac       : mac address
 * @param   [in] mac_len   : mac address buffer len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_mac(pps_char *mac, pps_s32 mac_len);

/** @fn      pps_s32 dua_network_get_netfamily(pps_void *if_handler, pps_s32 *family4, pps_s32 *family6);
 * @brief   <get net family>
 * @param   [in] if_handler: network interface handler
 * @param   [in] family4   : family4
 * @param   [in] family6   : family6
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_netfamily(pps_s32 *family4, pps_s32 *family6);

/** @fn      pps_s32 dua_network_get_netmask(pps_void *if_handler, pps_char *netmask, pps_s32 netmask_len);
 * @brief   <get net mask>
 * @param   [in] if_handler  : network interface handler
 * @param   [in] netmask     : netmask
 * @param   [in] netmask_len : netmask len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_netmask(pps_char *netmask, pps_s32 netmask_len);

/** @fn      pps_s32 dua_network_get_gateway(pps_void *if_handler, pps_char *gateway, pps_s32 gateway_len);
 * @brief   <get gateway>
 * @param   [in] if_handler  : network interface handler
 * @param   [in] gateway     : gateway
 * @param   [in] gateway_len : gateway len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_gateway(pps_char *gateway, pps_s32 gateway_len);

/** @fn      pps_s32 dua_network_get_dns(pps_s32 dns_idx, pps_char *dns, pps_s32 dns_len);
 * @brief   <get dns>
 * @param   [in] dns_idx: dns idx
 * @param   [in] dns    : dns
 * @param   [in] dns_len: dns len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_dns(pps_s32 dns_idx, pps_char *dns, pps_s32 dns_len);

/** @fn      pps_s32 dua_network_scan_wifi_list(pps_void *if_handler);
 * @brief   <scan wifi list>
 * @param   [in]    if_handler: network interface handler
 * @param   [in]    wifi_info : WIFI list
 * @param   [inout] count     : WIFI num
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_scan_wifi_list(pps_void *if_handler);

/** @fn      pps_s32 dua_network_get_scan_wifi_list_result(pps_void *if_handler, DUA_NETWORK_AP_INFO_PTR *wifi_list,  pps_s32 *count);
 * @brief   <get wifi list result>
 * @param   [in]    if_handler: network interface handler
 * @param   [in]    wifi_info : WIFI list
 * @param   [inout] count     : WIFI num
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_scan_wifi_list_result(pps_void *if_handler, DUA_NETWORK_AP_INFO_PTR *wifi_list, pps_s32 *count);

/** @fn      pps_s32 dua_network_set_hostname(pps_void *if_handler, const pps_char *hostname, pps_s32 size);
 * @brief   <set hostname>
 * @param   [in] if_handler: net interface handler
 * @param   [in] hostname  : hostname
 * @param   [in] size      : hostname len
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_set_hostname(pps_void *if_handler, const pps_char *hostname, pps_s32 size);

/** @fn      pps_s32 dua_network_bt_init(pps_void *dua_handler, pps_void *if_hander);
 * @brief   <bluetooth init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] if_handler : wireless network interface handler
 * @return  0 - success | else - failure
 */
pps_void *dua_network_bt_init(pps_void *dua_handler, pps_void *if_handler);

/** @fn      pps_void dua_network_bt_deinit(pps_void *dua_handler);
 * @brief   <bluetooth deinit>
 * @param   [in] bt_handler : network interface handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_bt_deinit(pps_void *dua_handler);

/** @fn      pps_s32 dua_network_bt_enable(pps_s32 enable);
 * @brief   <bluetooth enable>
 * @param   [in] bt_handler : bt handler
 * @param   [in] enable     : 0-disable | 1-enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_get_bt_mac(pps_void *bt_handler, pps_u8 *mac, pps_u8 size);

/** @fn      pps_s32 dua_network_bt_enable(pps_void *bt_handler, pps_s32 enable);
  * @brief   <get bluetooth mac >
  * @return  0 - success | else - failure
  */
pps_s32 dua_network_bt_enable(pps_void *bt_handler, pps_s32 enable);

/** @fn      pps_s32 dua_network_set_ps_mode(pps_void *bt_handler, pps_s32 enable);
  * @brief   <bluetooth enable>
  * @param   [in] bt_handler : bt handler
  * @param   [in] enable     : 0-disable | 1-enable
  * @return  0 - success | else - failure
  */
pps_s32 dua_network_set_ps_mode(pps_void *bt_handler, pps_s32 enable);

/** @fn      pps_s32 dua_network_set_ps_mode(pps_void *bt_handler, pps_s32 enable);
 * @brief   <dsp pwoer enable>
  * @param   [in] bt_handler : bt handler
 * @param   [in] enable     : 0-disable | 1-enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_bt_event_register(pps_void *bt_handler, dua_event_callback_f event_cb);

/** @fn      pps_s32 dua_network_bt_send_data(pps_u32 exception, pps_char *description, pps_u32 size);
 * @brief   <bluetooth send data>
 * @param   [in] exception  : exception code
 * @param   [in] description: description
 * @param   [in] size       : size
 * @return  0 - success | else - failure
 */
pps_s32 dua_network_bt_send_data(pps_void *bt_handler, pps_u32 exception, pps_char *description, pps_u32 size);

/** @fn      dua_get_current_interface_changed(pps_void);
 * @brief   <retun current network link type>
 * @return   -1 disconnnect | 0 wifi | 1 eth
 */
pps_s32 dua_get_current_interface_changed(pps_void);

pps_s32 dua_remove_wifi_from_wpalist(pps_void *if_handler, DUA_NETWORK_WIFI_PARAM_PTR wifi_switch, pps_s32 wifi_count);

pps_s32 dua_add_wifi_from_wpalist(pps_void *if_handler, DUA_NETWORK_WIFI_PARAM_PTR wifi_switch, pps_s32 wifi_count);

pps_s32 dua_network_interface_is_used(pps_char *p_interface_name);


#ifdef __cplusplus
}
#endif
#endif /* _DUA_NETWORK_H_ */
