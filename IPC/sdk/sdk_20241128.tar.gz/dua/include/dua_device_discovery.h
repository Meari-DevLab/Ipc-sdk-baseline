#ifndef _DUA_DEVICE_DISCOVERY_H
#define _DUA_DEVICE_DISCOVERY_H

#include "pps_osal_type.h"

/** @fn     pps_s32 dua_device_discovery_init(pps_void *dua_handler, pps_void *if_handler, pps_char *version);
 * @brief   <dua device discovery init>
 * @param  [in] dua_handler         : dua handler
 * @param  [in] wireless_net_handler: wifi net handler
 * @param  [in] wire_net_handler    : wire net handler
 * @param  [in] version             : firmware version xx.xx.xx
 * @return 0 - success | else - failure
 */
pps_s32 dua_device_discovery_init(pps_void *dua_handler, pps_void *wireless_net_handler, pps_void *wire_net_handler, pps_char *version);

pps_s32 dua_device_interface_is_used(pps_char *p_interface_name);

#endif /* _DUA_DEVICE_DISCOVERY_H */
