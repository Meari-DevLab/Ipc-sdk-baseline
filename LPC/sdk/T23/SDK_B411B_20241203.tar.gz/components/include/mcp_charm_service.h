/**
 * @file        mcp_charm_service.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      hhl
 *
 * @date        2023/04/20
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __DUA_CHARM_SERVICE_H
#define __DUA_CHARM_SERVICE_H

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum pps_charm_state_e {
    PPS_CHARM_CALL_START,
    PPS_CHARM_CALL_END,
} PPS_CHARM_STATE_E;

typedef void (*pps_charm_state_cb_f)(PPS_CHARM_STATE_E state);

/** @fn     pps_s32 mcp_charm_service_init(pps_void *dua_handler, DUA_RF_MODE_E rf_mode);
 * @brief  <charm service init>
 * @param  [in] dua_handler: dua handle
 * @param  [in] rf_mode    : rf_mode
 * @return 0 - success or notsupport | else - failure
 */
pps_s32 mcp_charm_service_init(pps_void *dua_handler, DUA_RF_MODE_E rf_mode);

/** @fn     pps_s32 mcp_charm_service_deinit(pps_void *dua_handler);
 * @brief  <charm service deinit>
 * @param  [in] dua_handler: dua handle
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_deinit(pps_void *dua_handler);

/** @fn     pps_s32 mcp_charm_service_enable(pps_s32 enable);
 * @brief  <charm service set enable>
 * @param  [in] enable     : enable
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_enable(pps_void *dua_handler, pps_s32 enable);

/** @fn     pps_s32 mcp_charm_service_external_enable(pps_s32 enable);
 * @brief  <charm service set external charm enable>
 * @param  [in] enable     : enable   //tuyu use charm_type
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_external_enable(pps_void *dua_handler, pps_s32 enable);

/** @fn     pps_s32 mcp_charm_service_pair(pps_u8 *serial_no);
 * @brief  <charm service pair>
 * @param  [in] rf_mode    : serial_no
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_pair(pps_void *dua_handler, pps_u8 *serial_no);

/** @fn     pps_s32 mcp_charm_service_unpair(pps_u8 *serial_no);
 * @brief  <charm service unpair>
 * @param  [in] serial_no : serial_no
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_unpair(pps_void *dua_handler, pps_u8 *serial_no);

/** @fn     pps_s32 mcp_charm_service_call(pps_u8 *serial_no, pps_charm_state_cb_f callback);
 * @brief  <charm service call>
 * @param  [in] serial_no : serial_no
 * @param  [in] callback  : cb
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_call(pps_void *dua_handler, pps_u8 *serial_no, pps_charm_state_cb_f callback);

/** @fn     pps_s32 mcp_charm_service_linkage(pps_u8 *serial_no, pps_u8 dev_id, pps_u32 ctrl);
 * @brief  <charm service init>
 * @param  [in] serial_no : serial_no
 * @param  [in] dev_id    : linkage devid, use CHARM_LINKAGE_DEVID_E
 * @param  [in] ctrl      : 0: close 1: open
 * @return 0 - success | else - failure
 * @note   tuya custom interface
 */
pps_s32 mcp_charm_service_linkage(pps_void *dua_handler, pps_u8 *serial_no, pps_u8 dev_id, pps_u32 ctrl);

/** @fn     pps_s32 mcp_charm_service_get_song_list(const pps_char ***list, pps_s32 *count);
 * @brief  <charm service get song list>
 * @param  [out] list    : song list
 * @param  [out] count   : song num
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_get_song_list(pps_void *dua_handler, const pps_char ***list, pps_s32 *count);

/** @fn     pps_s32 mcp_charm_service_set_play_id(pps_u8 song_id);
 * @brief  <charm service set play song id>
 * @param  [in] song_id  : song_id
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_set_play_id(pps_void *dua_handler, pps_u8 song_id);

/** @fn     pps_s32 mcp_charm_service_set_play_volume(pps_s32 volume);
 * @brief  <charm service set play volume>
 * @param  [in] volume    : volume
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_set_play_volume(pps_void *dua_handler, pps_s32 volume);

/** @fn     pps_s32 mcp_charm_service_set_play_duration(pps_s32 duration);
 * @brief  <charm service set play duration>
 * @param  [in] duration  : duration (seconds)
 * @return 0 - success | else - failure
 */
pps_s32 mcp_charm_service_set_play_duration(pps_void *dua_handler, pps_s32 duration);

#ifdef __cplusplus
}
#endif

#endif /*    __DUA_CHARM_SERVICE_H    */
