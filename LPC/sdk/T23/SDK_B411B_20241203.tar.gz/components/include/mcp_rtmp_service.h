#ifndef _MCP_RTMP_SERVICE_H_
#define _MCP_RTMP_SERVICE_H_

#define DUA_CONFIG_MAX_DEVICE_PASSWORD_LEN 64

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 mcp_rtmp_server_set_time(pps_s32 time);
 * @brief   <update time>
 * @param   [in] expire_time: expire time(seconds)
 * @return  0 - sucess | else - failure
 * @note    rtmp will push the stream data expire_time seconds
 */
pps_s32 mcp_rtmp_server_set_time(pps_s32 expire_time);

/** @fn      pps_s32 mcp_rtmp_server_start(pps_void *dua_handler, const pps_char *url);
 * @brief   <rtmp server start>
 * @param   [in] dua_handler: dua handler
 * @param   [in] url: url
 * @return  0 - sucess | else - failure
 */
pps_s32 mcp_rtmp_server_start(pps_void *dua_handler, const pps_char *url);

/** @fn      pps_s32 mcp_rtmp_server_stop(pps_void);
 * @brief   <rtmp server stop>
 * @return  0 - sucess | else - failure
 */
pps_s32 mcp_rtmp_server_stop(pps_void);

/** @fn      pps_s32 mcp_rtmp_server_status(pps_void);
 * @brief   <get rtmp server status>
 * @return  status, 0 initilize , 1 start handshake , 2 putstream, -1, no rtmp related thread
 */
pps_s32 mcp_rtmp_server_status(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_RTMP_SERVICE_H_ */
