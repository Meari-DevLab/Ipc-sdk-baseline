/**
 * @file        mcp_lowpower_service.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       lowpower service
 * @author      hcq
 * @date        2023/08/23
 * @version     1.0.0
 * @note
 */

#ifndef _DUA_LOWPOWER_SERVICE_H_
#define _DUA_LOWPOWER_SERVICE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pps_osal_type.h"

typedef enum {
    DUA_LPC_VETO_P2P         = 0,
    DUA_LPC_VETO_PREVIEW     = 1,
    DUA_LPC_VETO_PLAYBACK    = 2,
    DUA_LPC_VETO_NET_CONFIG  = 3,
    DUA_LPC_VETO_NET_CONNECT = 4,
    DUA_LPC_VETO_PIR         = 5,
    DUA_LPC_VETO_BELL_CALL   = 6,
    DUA_LPC_VETO_TAMPER      = 7,
    DUA_LPC_VETO_LIGHT       = 8,
    DUA_LPC_VETO_SIREN       = 9,
    DUA_LPC_VETO_MOTOR_WORK  = 10,
    DUA_LPC_VETO_VOICEMAIL   = 11,
    DUA_LPC_VETO_PLAY_MESS   = 12,
    DUA_LPC_VETO_SD_FORMAT   = 13,
    DUA_LPC_VETO_SD_FSCK     = 14,
    DUA_LPC_VETO_THIRD_PARTY = 15,
    DUA_LPC_VETO_TEST        = 16,
    DUA_LPC_VETO_RECORD      = 17,
    DUA_LPC_VETO_MAX,
} mcp_lpc_veto_id_t;

typedef enum {
    DUA_LPC_CHECK_TYPE_NONE          = 0,
    DUA_LPC_CHECK_TYPE_EVENTMNG      = 1,
    DUA_LPC_CHECK_TYPE_RECORD        = 2,
    DUA_LPC_CHECK_TYPE_NETCONFIG     = 3,
    DUA_LPC_CHECK_TYPE_SOUND_PLAYING = 4,
} mcp_lpc_check_type_e;

typedef pps_u8 (*mcp_lpc_check_callback_f)(pps_void *context);
typedef pps_void (*mcp_lpc_veto_timeout_cb)(mcp_lpc_veto_id_t veto_id, pps_void *contex);
typedef pps_s32 (*mcp_lpc_standby_entry_f)(pps_void);

/** @fn      pps_s32 mcp_lpc_init(pps_void *dua_handler);
 * @brief   <lowpower service init>
 * @param   [in] dua_handler: dua handler
 * @param   [in] config: keepalive config
 * @return  0 - success | else - failure
 * @note    lowpower device standby mode manager
 */
pps_s32 mcp_lpc_init(pps_void *dua_handler);

/** @fn      pps_s32 mcp_lpc_register_standby_entry(mcp_lpc_standby_entry_f standby_entry);
 * @brief   <register standby handler>
 * @param   [in] standby_entry: stnadby handler
 * @return  0 - success | else - failure
 * @note    before device standby, the mcp_lpc_standby_entry_f func will be called,
 *          in mcp_lpc_standby_entry_f func,
 *          developer needs to deinit sdcard, cloud sdk, other resources release, finally calling dua_standby func
 *
 */
pps_s32 mcp_lpc_register_standby_entry(mcp_lpc_standby_entry_f standby_entry);

/** @fn      pps_s32 mcp_lpc_standby_entry(pps_void);
 * @brief   <entry standby mode>
 * @return  0 - success | else - failure
 * @note    device go into standby mode directly, actually it calls the api mcp_lpc_standby_entry_f
 */
pps_s32 mcp_lpc_standby_entry(pps_void);

/** @fn      pps_s32 mcp_lpc_get_sleep_timeout(pps_void);
 * @brief   <get device sleep timeout for lpc device>
 * @return  sleep_timeout - success
 */
pps_s32 mcp_lpc_get_sleep_timeout(pps_void);

/** @fn      pps_s32 mcp_lpc_set_sleep_timeout(pps_s32 sleep_timeout);
 * @brief   <set device sleep timeout for lpc device>
 * @param   [in] sleep_timeout: sleep timeout
 * @return  0 - success | else - failure
 * @note    if all the veto are false, the device will go into standby mode after sleep_timeout seconds
 */
pps_s32 mcp_lpc_set_sleep_timeout(pps_s32 sleep_timeout);

/** @fn      pps_s32 mcp_lpc_add_veto(mcp_lpc_veto_id_t veto_id);
 * @brief   <add veto for lpc device>
 * @param   [in] veto_id: veto id
 * @return  0 - success | else - failure
 * @note    once mcp_lpc_veto_id_t is added, which means the device is controlled by custom or alarming, so that device will not go into the standby mode
 *          need to mcp_lpc_remove_veto all the mcp_lpc_veto_id_t so that devcie can be allowed to go into the standby mode
 */
pps_s32 mcp_lpc_add_veto(mcp_lpc_veto_id_t veto_id);

/** @fn      pps_s32 mcp_lpc_add_veto_timeout(mcp_lpc_veto_id_t veto_id, pps_u32 timeout);
 * @brief   <add veto timeout for lpc device>
 * @param   [in] veto_id: veto id
 * @param   [in] timeout: veto timeout time
 * @return  0 - success | else - failure
 * @note    if timeout = 0, which means add veto fail
 *          once mcp_lpc_veto_id_t is added and timeout, the veto will be auto removed
 */
pps_s32 mcp_lpc_add_veto_timeout(mcp_lpc_veto_id_t veto_id, pps_u32 timeout);

/** @fn      pps_s32 mcp_lpc_set_veto_timeout_cb(mcp_lpc_veto_id_t veto_id, mcp_lpc_veto_timeout_cb timeout_cb, pps_void *args);
 * @brief   <set veto timeout callback for lpc device>
 * @param   [in] veto_id: veto id
 * @param   [in] timeout_cb: timeout callback
 * @param   [in] args: timeout callback context
 * @return  0 - success | else - failure
 * @note    once mcp_lpc_veto_id_t is added and timeout, the veto will be auto removed and call the func mcp_lpc_veto_timeout_cb
 */
pps_s32 mcp_lpc_set_veto_timeout_cb(mcp_lpc_veto_id_t veto_id, mcp_lpc_veto_timeout_cb timeout_cb, pps_void *args);

/** @fn      pps_u32 mcp_lpc_remove_veto(mcp_lpc_veto_id_t veto_id);
 * @brief   <remove veto id for lpc device>
 * @param   [in] veto_id: veto id
 * @return  0 - success | else - failure
 */
pps_s32 mcp_lpc_remove_veto(mcp_lpc_veto_id_t veto_id);

/** @fn      pps_void *mcp_lpc_register_check_handler(mcp_lpc_check_type_e type, mcp_lpc_check_callback_f callback, pps_void *context);
 * @brief   <register check handler for lpc device>
 * @param   [in] type: check type
 * @param   [in] callback: check handler callback, the return value shouled be true(1) or false(0)
 * @param   [in] context: callback context
 * @return  lpc check handler - success | else - NULL
 * @note    this api is used as mcp_lpc_add_veto, mcp_lpc_check_callback_f is customized veto,
 *          if mcp_lpc_check_callback_f return true, the device will not go into standby mode
 */
pps_void *mcp_lpc_register_check_handler(mcp_lpc_check_type_e type, mcp_lpc_check_callback_f callback, pps_void *context);

/** @fn      pps_s32 mcp_lpc_unregister_check_handler(pps_void *handler);
 * @brief   <unregister check handler for lpc device>
 * @param   [in] handler: lpc check handler
 * @return  0 - success | else - failure
 * @note    this api is used as mcp_lpc_remove_veto
 */
pps_s32 mcp_lpc_unregister_check_handler(pps_void *handler);

/** @fn      pps_u32 mcp_lpc_get_veto_status(mcp_lpc_veto_id_t veto_id);
 * @brief   <get veto status for lpc device>
 * @param   [in] veto_id: veto id
 * @return  0 - success | else - failure
 */
pps_u8 mcp_lpc_get_veto_status(mcp_lpc_veto_id_t veto_id);

/** @fn      pps_u32 mcp_lpc_get_veto_timeout(mcp_lpc_veto_id_t veto_id);
 * @brief   <get veto timeout for lpc device>
 * @param   [in] veto_id: veto id
 * @return  0 - success | else - failure
 */
pps_u32 mcp_lpc_get_veto_timeout(mcp_lpc_veto_id_t veto_id);

#ifdef __cplusplus
}
#endif

#endif // _DUA_LOWPOWER_SERVICE_H_
