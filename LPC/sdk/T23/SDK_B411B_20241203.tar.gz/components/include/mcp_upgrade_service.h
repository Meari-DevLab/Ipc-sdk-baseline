#ifndef _UPGRADE_SERVER_H_
#define _UPGRADE_SERVER_H_

#include "pps_osal_type.h"
#include "mcp_upgrade_def.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 读取数据的抽象接口
 */
typedef pps_s32 (*read_data_function_cb)(pps_void *context, pps_s32 seek_set, pps_void *buffer, pps_s32 size);

/**
 * @brief 升级初始化
 */
pps_s32 mcp_upgrade_init(pps_void *dua_handler);

/**
 * @brief URL\ SD卡升级
 */
pps_s32 mcp_upgrade_start(pps_void *dua_handler, read_data_function_cb read_func, UPGRADE_TYPE_INFO context);

/**
 * @brief 全量包重组成专包拷贝接口
 */
pps_s32 mcp_upgrade_write_buf(pps_void *dua_handler, pps_char *upgrade_slice_buffer, pps_s32 slice_buffer_size);

/**
 * @brief buffer直接升级, 专包直接升级使用
 */
pps_s32 mcp_upgrade_start_by_buf(pps_void *dua_handler);

/**
 * @brief 升级反始化
 */
pps_s32 mcp_upgrade_deinit(pps_void *dua_handler, pps_s32 upgrade_suc);

/**
 * @brief 获取升级进度
 */
pps_s32 mcp_upgrade_progress(pps_s32 *upgrade_percent, pps_s32 *download_percent);

#ifdef __cplusplus
}
#endif

#endif //_UPGRADE_MGR_H_