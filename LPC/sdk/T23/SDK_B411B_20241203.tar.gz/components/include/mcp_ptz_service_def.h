/**
 * @file        mcp_ptz_service_def.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      liping
 *
 * @date        2023/10/17
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __MCP_PTZ_SERVICE_DEF_H
#define __MCP_PTZ_SERVICE_DEF_H

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_PRESET_POSITION_NUM (8)

typedef enum mcp_ptz_ctrl_status {
    MCP_PTZ_DEFAULT = 0,  // PTZ default status
    MCP_PTZ_IDLE,         // PTZ idle status
    MCP_PTZ_DISABLE,      // PTZ disable
    MCP_PTZ_SLEEPING,     // PTZ in privacy mode
    MCP_PTZ_CALIBRATING,  // PTZ calibrating
    MCP_PTZ_MOVING,       // PTZ up/down/left/right ctrl
    MCP_PTZ_360_P_PATROL, // PTZ 360 p direction patrol
    MCP_PTZ_360_T_PATROL, // PTZ 360 t direction patrol
    MCP_PTZ_TRACKING,     // PTZ tracking
    MCP_PTZ_GOTO_PRESET,  // PTZ goto preset position
    MCP_PTZ_GOTO_POS,     // PTZ goto target position
} MCP_PTZ_CTRL_STATUS_E;

typedef enum mcp_ptz_patrol_type {
    MCP_PTZ_USR_360_P_PATROL_TYPE_ONCE = 0, // usr ctrl 360 p direction patrol
    MCP_PTZ_DEV_360_P_PATROL_TYPE_ONCE,     // dev ctrl 360 p direction patrol (ptral according to the plan)
    MCP_PTZ_USR_PRESET_P_PATROL_TYPE_ONCE,  // usr ctrl preset position patrol
    MCP_PTZ_DEV_PRESET_P_PATROL_TYPE_ONCE,  // dev ctrl preset position patrol (ptral according to the plan)
} MCP_PTZ_PATROL_TYPE_E;

typedef struct mcp_ptz_position {
    pps_s32 p_pos;
    pps_s32 t_pos;
} MCP_PTZ_POSITION_T, *MCP_PTZ_POSITION_PTR;

typedef pps_s32 (*update_ptz_position_f)(pps_s32 p_pos, pps_s32 t_pos);

typedef struct mcp_ptz_service_config_param {
    pps_s32 max_preset_position_num;
    // usually we use sub stream to calculate the tracking position
    // so we need the width and height of the source stream image
    pps_s32               tracking_image_width;
    pps_s32               tracking_image_height;
    pps_s32               ptz_turn; // ptz turn value, 0-normal, 0x1-letf/right ctrl reverse, 0x2-up/down ctrl reverse, 0x3 = 0x1 | 0x2
    pps_s32               max_p_angle;
    pps_s32               max_t_angle;
    pps_s32               max_p_steps;
    pps_s32               max_t_steps;
    pps_s32               p_tps;
    pps_s32               t_tps;
    pps_s32               pan_home_preset;
    pps_s32               tilt_home_preset;
    pps_s32               cali_by_opos_flg;
    pps_s32               support_ptz_privacy;
    pps_s32               band_p_fov; // horizontal angle of view for ptz motion lens
    pps_s32               band_t_fov; // veritcal angle of view for ptz motion lens
    MCP_PTZ_POSITION_T    orignal_positon;
    update_ptz_position_f update_ptz_pos_f;
} MCP_PTZ_SERVICE_INIT_CONFIG_T, *MCP_PTZ_SERVICE_INIT_CONFIG_PTR;

#ifdef __cplusplus
}
#endif
#endif /* __MCP_PTZ_SERVICE_DEF_H */
