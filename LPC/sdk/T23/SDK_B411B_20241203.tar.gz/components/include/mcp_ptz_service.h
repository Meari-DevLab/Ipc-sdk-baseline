/**
 * @file        mcp_ptz_service_v2.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/11/01
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_PTZ_SERVICE_V2_H_
#define _MCP_PTZ_SERVICE_V2_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "dua_common.h"
#include "mcp_ptz_service_def.h"

pps_void *mcp_ptz_service_init(pps_void *dua_handler, MCP_PTZ_SERVICE_INIT_CONFIG_PTR cfg);

pps_s32 mcp_ptz_service_deinit(pps_void *ptz_serv_handler);

pps_s32 mcp_ptz_service_enable(pps_void *ptz_serv_handler, pps_s32 enable);

pps_s32 mcp_ptz_service_set_ptz_move_speed(pps_void *ptz_serv_handler, pps_s32 p_tps, pps_s32 t_tps);

MCP_PTZ_CTRL_STATUS_E mcp_ptz_service_get_status(pps_void *ptz_serv_handler);

pps_s32 mcp_ptz_get_cur_position(MCP_PTZ_POSITION_PTR ptz_position);

pps_s32 mcp_ptz_service_calibration(pps_void *ptz_serv_handler);

pps_s32 mcp_ptz_service_move(pps_void *ptz_serv_handler, DUA_PTZ_MOVE_CTRL_CMD_E cmd, pps_u32 move_steps, pps_s32 timeout_ms);

pps_s32 mcp_ptz_service_set_preset_position(pps_void *ptz_serv_handler, MCP_PTZ_POSITION_T preset_position, pps_u32 index);

pps_s32 mcp_ptz_service_get_preset_position(pps_void *ptz_serv_handler, pps_u32 index, MCP_PTZ_POSITION_PTR preset_position);

pps_void mcp_ptz_clear_preset_position(pps_void *ptz_serv_handler);

pps_s32 mcp_ptz_service_goto_preset(pps_void *ptz_serv_handler, pps_u32 index);

pps_s32 mcp_ptz_service_privacy_enable(pps_void *ptz_serv_handler, pps_s32 enable);

pps_s32 mcp_ptz_service_patrol(pps_void *ptz_serv_handler, MCP_PTZ_PATROL_TYPE_E type, pps_u32 patrol_move_steps, pps_u32 patrol_steps_staytime_ms);

pps_s32 mcp_ptz_service_goto_target_pos(pps_void *ptz_serv_handler, pps_s32 target_p_position, pps_s32 target_t_position);

pps_s32 mcp_ptz_service_tracking(pps_void *ptz_serv_handler, pps_s32 is_flip, pps_s32 is_mirror, pps_s32 x, pps_s32 y, pps_s32 w, pps_s32 h);

pps_s32 mcp_ptz_single_step_move(pps_void *ptz_serv_handler,  DUA_PTZ_MOVE_CTRL_CMD_E cmd, pps_u32 move_steps);
#ifdef __cplusplus
}
#endif
#endif /* _MCP_PTZ_SERVICE_V2_H_ */
