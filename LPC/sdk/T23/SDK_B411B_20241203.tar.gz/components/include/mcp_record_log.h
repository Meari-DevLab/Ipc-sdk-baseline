/**
 * @file        mcp_record_log.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       
 * @author      raozhenqing
 * @date        2023/05/23
 * @version     1.0.0
 * @note
 */
#ifndef _MCP_RECORD_LOG_H_
#define _MCP_RECORD_LOG_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum record_log_type
{
    RECORD_LOG_SDCARD_TYPE, //日志记录到sd卡
    RECORD_LOG_ONLINE_TYPE, //日志在线上传
} RECORD_LOG_TYPE_E;

typedef int (*report_log_cb)(pps_char* path);

/** @fn      pps_void mcp_record_log_start(RECORD_LOG_ONLINE_TYPE type);
 * @brief   <开启日志记录上传>
 * @param
 * @return  0 - 成功 | 非0 - 失败
 */
pps_void mcp_record_log_start(RECORD_LOG_TYPE_E type);

//停止
/** @fn      pps_void mcp_record_log_service_exit(pps_void);
 * @brief   <停止日志记录上传>
 * @param
 * @return  0 - 成功 | 非0 - 失败
 */
pps_void mcp_record_log_service_exit(pps_void);

/** @fn      pps_s32 mcp_register_report_log_cb(report_log_cb cb);
 * @brief   <注册日志上报接口>
 * @param    上报接口函数
 * @return  0 - 成功 | 非0 - 失败
 */
pps_s32 mcp_register_report_log_cb(report_log_cb cb);

/** @fn      mcp_record_log_service_init(pps_void * handle);
 * @brief   <日志服务初始化>
 * @param 
 * @return  0 - 成功 | 非0 - 失败
 */
pps_s32 mcp_record_log_service_init(pps_void * handle);


/** @fn      mcp_record_log_service_exit();
 * @brief   <日志服务卸载>
 * @param 
 * @return  0 - 成功 | 非0 - 失败
 */
pps_void mcp_record_log_service_exit(pps_void);

#ifdef __cplusplus
}
#endif
#endif /* _MCP_RECORD_LOG_H_ */