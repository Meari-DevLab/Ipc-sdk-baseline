/**
 * @file        pps_factory_check_info.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zengyaowu
 *
 * @date        2021/04/15
 *
 * @version     0.1.0
 *
 * @note
 */
#ifndef __PPS_FACTORY_CHECK_INFO_H
#define __PPS_FACTORY_CHECK_INFO_H

#ifdef __cplusplus
extern "C" {
#endif


typedef struct {
    char audioName[64];
} FACTORY_CHECK_AUDIO_FILE;

typedef struct {
    unsigned int ircut_cnt;
} FACTORY_CHECK_ICURT_INFO;

typedef struct {
    char ssid[128];
    char psk[128];
    int  key_mgmt;
} FACTORY_CHECK_WIFI_PARAM;

typedef struct {
    char ipaddr[32];
    char gateway[32];
    int  flag;
} WIFI_IP_CONFIG;

typedef enum {
    FACTORY_CHECK_INFO_FLAG_WiFI  = 0, // use FACTORY_CHECK_WIFI_PARAM
    FACTORY_CHECK_INFO_FLAG_AUDIO = 1, // use FACTORY_CHECK_AUDIO_FILE
    FACTORY_CHECK_INFO_FLAG_IRCUT = 2, // use FACTORY_CHECK_ICURT_INFO
    FACTORY_CHECK_INFO_PTZ_TEST   = 3, // use FACTORY_CHECK_INFO_PTZ_TEST
    FACTORY_CHECK_INFO_CLOSE_BLE  = 4, // use FACTORY_CHECK_INFO_CLOSE_BLE
} FACTORY_CHECK_INFO_FLAG;

#define FACTORY_CHECK_INFO_FILE "/mnt/mmc01/ppsFactoryTool.txt"
#define FACTORY_DEBUG_INFO_FILE "/mnt/mmc01/ppsDebugTool.txt"

int pps_factory_check_get_info(FACTORY_CHECK_INFO_FLAG flag, void *info);
int pps_factory_check_get_wifi_ip(WIFI_IP_CONFIG *info);


#ifdef __cplusplus
}
#endif
#endif /* __PPS_FACTORY_CHECK_INFO_H */
