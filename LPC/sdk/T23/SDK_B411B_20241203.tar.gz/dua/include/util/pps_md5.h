/**
 * @file        pps_md5.h
 *
 * @copyright   2016-2019 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author      yll
 *
 * @date        2019/7/10
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_MD5_H
#define _PPS_MD5_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    unsigned int  count[2];
    unsigned int  state[4];
    unsigned char buffer[64];
} pps_md5_ctx;

void  pps_md5_init(pps_md5_ctx *context);
void  pps_md5_update(pps_md5_ctx *context, unsigned char *input, unsigned int inputlen);
void  pps_md5_final(pps_md5_ctx *context, unsigned char digest[16]);
char *pps_md5(char buf[33], ...);

#ifdef __cplusplus
}
#endif

#endif /* _PPS_MD5_H */
