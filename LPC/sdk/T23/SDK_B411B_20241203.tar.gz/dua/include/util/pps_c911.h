#ifndef _PPS_C911_H
#define _PPS_C911_H

/* check if string valid */
enum {
    PPS_CHECK_STRING_TYPE_0,
    PPS_CHECK_STRING_TYPE_1,
    PPS_CHECK_STRING_TYPE_2,
    PPS_CHECK_STRING_TYPE_3,
    PPS_CHECK_STRING_TYPE_4,

    PPS_CHECK_STRING_TYPE_MAX,
};

int pps_check_string_valid(int type, const char *dst, int dstlen);

#endif /* _PPS_C911_H */
