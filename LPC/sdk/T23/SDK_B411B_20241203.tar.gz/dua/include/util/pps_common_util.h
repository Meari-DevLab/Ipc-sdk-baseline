/**
 * @file        pps_common_util.h
 *
 * @copyright   2016-2021 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zengyaowu
 *
 * @date        2021/04/15
 *
 * @version     0.1.0
 *
 * @note
 */
#ifndef __PPS_COMMON_UTIL_H
#define __PPS_COMMON_UTIL_H

#include <sys/time.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @func    pps_create
 * @brief   create/open file
 * @param   file - file name
 * @return  return a FILE pointer
 */
void *pps_create(char *file_name);

/**
 * @func        pps_fopen
 * @brief       open and possibly create a file.
 * @param       file_name - file name
 * @param       mode - (eg: "r" "r+" "w" "w+")
 * @return      a FILE pointer
 */
FILE *pps_fopen(char *file_name, char *mode);

/**
 * @func        pps_fwrite
 * @brief       write buf to f
 * @return      0:success;-1:error
 */
int pps_fwrite(FILE *f, char *buf, int len);

/**
 * @func         pps_fclose
 * @brief        close a file
 * @return       success:0;error:-1
 */
int pps_fclose(FILE *f);

/**
 * @func        pps_lseek
 * @brief       reposition read/write file offset
 * @param       seek_mode - (eg:SEEK_SET SEEK_END SEEK_END)
 * @return      success:return the offset base to seek_mode;error:-1
 */
int pps_lseek(FILE *f, int offset, int seek_mode);

/**
 * @fn pps_ftell
 * @brief       obtains the current value of the file position
 * @param       f - a FILE pointer
 * @return      success:the current offset;error:-1
 */
int pps_ftell(FILE *f);

/**
 * @func        pps_remove_file
 * @brief       remove a file
 * @return      success:0;error:-1
 */
int pps_remove_file(const char *filename);

/**
 * @func        pps_mkdir
 * @brief       make a new directory
 * @param       dir - directory name
 * @return      success:0;error:-1
 */
int pps_mkdir(char *dir);

/**
 * @func        pps_is_dir
 * @brief       judge filename is a directory or not
 * @param       filename - directory name
 * @return      dir:retrurn 0,not dir:return -1
 */
int pps_is_dir(char *filename);

/**
 * @func        pps_delete_dir
 * @brief       delete a dir
 * @param       dirname - directory name
 * @return      success:0;error:-1
 *
 * note:delete,even include the dirname
 */
int pps_delete_dir(char *dirname);

/**
 * @func        pps_remove
 * @brief       remove a file
 * @return      success:0;error:-1
 */
int pps_remove(char *filename);

/**
 * @func         pps_remove_dir
 * @brief        remove sub_dir and files from a directory
 * @param        path - pathname
 * @return       success:0;error:-1
 *
 * note:delete,but will reserve the pathname;after deleting,the pathname will be an empty dir
 */
int pps_remove_dir(const char *pathname);

/**
 * @func        kill_specific_process
 * @brief       terminate a process which called name
 * @param       name - process's name
 * @return      success:0;error:-1
 */
int pps_kill_specific_process(char *name);

/**
 * @func        pps_fprintf
 * @brief       write to filename base fmt
 * @param       fmt - (eg:"%s" "%5d")
 * @return      success:0;error:-1
 */
int pps_fprintf(char *filename, char *fmt, ...);

/**
 * @func pps_fcopy
 * @brief copy src to dst
 * @return success:the bytes have read;error:-1
 */
int pps_fcopy(char *dst, char *src);

/**
 * @func        pps_fread
 * @brief       read size bytes from file to buf
 * @param       size - the bytes to read
 * @param       f - file descriptor
 * @return      success:the bytes have read;error:-1
 */
int pps_fread(char *buf, int size, FILE *f);

/**
 * @func        pps_file_read/write
 * @brief       read/write size bytes from file to buf
 * @param       size - the bytes to read
 * @param       filename - filename
 * @return      success:the bytes have read;error:-1
 */
int pps_file_read(char *filename, void *buf, int size);
int pps_file_write(char *filename, void *buf, int size);

/**
 * @func        pps_file_tell
 * @brief       get file size
 * @param       filename - filename
 * @return      success: file size;error:-1
 */
long pps_file_tell(char *filename);

/**
 * @func      find_pid_by_name
 * @brief     find process's pid by name
 * @param     pid_name - process's name
 * @return    success:pid;error:-1
 */
long pps_find_pid_by_name(char *pid_name);

/**
 * @func      pps_run_web_cmd
 * @brief     run web command and save it
 * @param     cmd
 * @return    -1 false, 0 success
 */
int pps_run_web_cmd(char *cmd);

/**
 * @func      pps_get_web_cmd_buf
 * @brief     get saved command run result
 * @param     cmd
 * @param     cmd_len
 * @return    -1 false, 0 success
 */
int pps_get_web_cmd_buf(char *cmd, size_t cmd_len);

/**
 * @func    pps_fcat
 * @brief   simulate cat command
 *
 * @param buf write buffer
 * @param size write buffer size
 * @param file file name
 * @return 0 on success, < 0 on failure
 */
int pps_fcat(char *buf, int size, char *file);

int pps_dirname(char *filename, int count, char *dirname, int count2);

/**
 * @func    pps_write_cache_to_file_parts
 * @brief   each time write part size buffer content to file
 *
 * @param path write to which path
 * @param filename file name
 * @param buf write buffer
 * @param buffer_len write buffer size
 * @param part_size each time write size
 * @return 0 on success, < 0 on failure
 */
int pps_write_cache_to_file_parts(char *path, char *filename, char *buffer, int buffer_len, int part_size);

/**
 * @func    pps_strdup
 * @brief    encapsulation of strdup
 *
 * @param s string to strdup

 * @return strdup add,you must free
 */
char *pps_strdup(char *s);

/**
 * @func    pps_basename
 * @brief   get base filename /home/cfg/settings.json -> settings.json
 *
 * @param   filename[in] input filename
 * @return  On success, return basename. Or return input filename.
 **/
char *pps_basename(char *filename);

/**
 * @func    pps_check_byte_sum
 * @brief   calculate check sum
 *
 * @param   padata[in] input data
 * @param   len[in] input data length
 * @return  return sum result.
 **/
unsigned int pps_check_byte_sum(char *pdata, unsigned int len);

/**
 * @func    pps_char_to_hex
 * @brief   convert char to hex
 *
 * @param   c[in] input data
 * @return  return hex result.
 **/
int pps_char_to_hex(char c);

/* timeval proc */
void timeval_normalize(struct timeval *a);
void timeval_sub(struct timeval *a, struct timeval b);
int  timeval_compare(struct timeval a, struct timeval b);

/**
 * @func    pps_read_file_data
 * @brief   read specific file
 *
 * @param   filename[in] input filename
 * @param   file_buf[out] output file date, need free outside
 * @param   file_size[out] output file data size
 * @return  On success, return 0. Or return -1 or error code.
 **/
int pps_read_file_data(char *filename, char **file_buf, unsigned int *file_size);

#ifdef __cplusplus
}
#endif
#endif /* __PPS_COMMON_UTIL_H */
