/**
 * @file        pps_mqueue.h
 *
 * @copyright   2016-2020 Meari technology Co., Ltd
 *
 * @brief       osal message queue interfaces
 *
 * @author
 *
 * @date        2020/4/28
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_MQUEUE_H_
#define _PPS_MQUEUE_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* max mqueue count */
#define PPS_MQUEUE_MAX_COUNT     32
#define PPS_MQUEUE_DEFAULT_COUNT 8

typedef struct mcp_mqueue_t {
    pps_u32 msg_id;
    pps_u32 msg_size;
    pps_u8  msg_count;
    pps_u8  cur_count;
} MCP_MQUEUE_T, *MCP_MQUEUE_PTR;

/**
 * @func    mcp_mqueue_create
 * @brief   create message queue
 *
 * @param   mq[out] msg queue handle context
 * @param   msg_count[in] create msg queue count
 * @param   msg_size[in] msg data size
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_mqueue_create(MCP_MQUEUE_PTR mq, pps_u8 msg_count, pps_u32 msg_size);

/**
 * @func    mcp_mqueue_delete
 * @brief   delete message queue
 *
 * @param   mq[in] msg queue handle context
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_mqueue_delete(MCP_MQUEUE_PTR mq);

/**
 * @func    mcp_mqueue_send
 * @brief   send message to queue
 *
 * @param   mq[in] msg queue handle context
 * @param   msg[in] msg data
 * @param   msg_size[in] msg data size
 * @param   timeout_ms[in] send timeout mseconds
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_mqueue_send(MCP_MQUEUE_PTR mq, pps_void *msg, pps_u32 msg_size, pps_u32 timeout_ms);

/**
 * @func    mcp_mqueue_send
 * @brief   send message to queue
 *
 * @param   mq[in] msg queue handle context
 * @param   msg[out] msg data
 * @param   msg_size[in/out] msg data size
 * @return  On success, return 0. On error, return errno.
 */
pps_s32 mcp_mqueue_wait(MCP_MQUEUE_PTR mq, pps_void *msg, pps_u32 *msg_size);

/**
 * @func    mcp_mqueue_is_full
 * @brief   check message queue is full or not.
 *
 * @param   mq[in] msg queue handle context
 * @return  If mqueue is full, return TRUE. Otherwise, return errno.
 */
pps_s32 mcp_mqueue_is_full(MCP_MQUEUE_PTR mq);

pps_s32 mcp_mqueue_is_empty(MCP_MQUEUE_PTR mq);

#ifdef __cplusplus
}
#endif

#endif // _PPS_MQUEUE_H_
