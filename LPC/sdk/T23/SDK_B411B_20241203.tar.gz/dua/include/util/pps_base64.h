/**
 * @file        pps_base64.h
 *
 * @copyright   2016-2019 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author      yll
 *
 * @date        2019/7/10
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_BASE64_H
#define _PPS_BASE64_H

#ifdef __cplusplus
extern "C" {
#endif

int pps_base64_encode(const char *in_str, int in_len, char *out_str);
int pps_base64_decode(const char *in_str, int in_len, char *out_str);

#ifdef __cplusplus
}
#endif

#endif /* _PPS_BASE64_H */
