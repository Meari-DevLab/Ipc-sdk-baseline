/**
 * @file        dua_comm.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       The public header file of the dua
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_COMMON_H_
#define _DUA_COMMON_H_

#include "dua_event_def.h"
#include <time.h>

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#ifndef CONFIG_BIG_ENDIAN
#define CONFIG_BIG_ENDIAN 1
#endif
#elif __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#ifndef CONFIG_LITTLE_ENDIAN
#define CONFIG_LITTLE_ENDIAN 1
#endif
#else
/* default */
#error "unkown endian info"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define DEV_NAME_LEN        32
#define DEV_MODEL_NAME_LEN  32
#define DEV_SOC_NAME_LEN    32
#define DEV_SENSOR_NAME_LEN 32
#define DEV_PCB_NAME_LEN    64
#define DEV_VERSION_LEN     128
#define DEV_BUILD_TIME_LEN  64
#define DEV_CUS_ENC_LEN     1024
#define DEV_SN_LEN          10
#define DEV_NET_MODULE_LEN  32
#define DEV_WIFI_MAC_LEN    32
#define DEV_WIFI_MAX_SSID_LEN     (32)
#define DEV_WIFI_MAX_BSSID_LEN    (64)
#define DEV_WIFI_MAX_PASSWORD_LEN (64)
#define DUA_PCM_BUFF_SIZE         (2048)
#define DUA_AUDIO_AAC_SAMPLING_RATE (16000)

#define DEV_MCU_VERSION_LEN    32

#define DUA_DETECTION_MAX_AREA (6)

#define DEV_NET_APP_OPEN_PREVIEW  (1)
#define DEV_NET_APP_CLOSE_PREVIEW (0)

typedef enum dua_dev_flash_type {
    DUA_DEV_FLASH_DEFAULT,
    DUA_DEV_FLASH_8M,
    DUA_DEV_FLASH_16M,
} DUA_DEV_FLASH_TYPE_E;

typedef enum dua_dev_class {
    DUA_DEV_CLASS_BASE,
    DUA_DEV_CLASS_BELL,
    DUA_DEV_CLASS_FLIGHT,
    DUA_DEV_CLASS_BABY,
    DUA_DEV_CLASS_PET,
} DUA_DEV_CLASS_E;

typedef enum dua_ircut_id {
    DUA_IRCUT_ID_1,
    DUA_IRCUT_ID_2,
    DUA_IRCUT_MAX_NUM
} DUA_IRCUT_ID_E;

typedef enum dua_ircut_status {
    DUA_IRCUT_DAY_STATUS   = 0,
    DUA_IRCUT_NIGHT_STATUS = 1,
} DUA_IRCUT_STATUS_E;

/** @struct  dua_board_info
 * @brief   <Device board-level information>
 */
typedef struct dua_board_info {
    // Basic information
    pps_char             name[DEV_NAME_LEN];                     // Device name
    pps_s32              device_type;                            // Device type
    pps_s32              device_class;                           // Device Class enum DUA_DEV_CLASS_E
    pps_char             model_name[DEV_MODEL_NAME_LEN];         // Device type
    pps_char             serial_no[DEV_SN_LEN];                  // Device serial number
    pps_char             sensor_name[DEV_SENSOR_NAME_LEN];       // Lens name
    pps_char             pcb_name[DEV_PCB_NAME_LEN];             // PCB name
    pps_char             hardware_version[DEV_VERSION_LEN];      // Hardware version
    pps_char             software_version[DEV_VERSION_LEN];      // Software version
    pps_char             firmware_version[DEV_VERSION_LEN];      // Firmware version
    pps_char             software_buildtime[DEV_BUILD_TIME_LEN]; // Software build time
    pps_s32              wifi_module;                            // wifi module id
    pps_char             soc_name[DEV_SOC_NAME_LEN];             // soc name
    DUA_DEV_FLASH_TYPE_E flash_type;                             // Flash type
    pps_s32              country_id;                             // Country code reference :enum dua_zome_e
    pps_char             wifi_mac[DEV_WIFI_MAC_LEN];             // WIFI MAC
    pps_char             mcu_version[DEV_MCU_VERSION_LEN];          // mcu version
    pps_char             feydata[128];
    // Customers encrypt information
    pps_char cus_enc_info[DEV_CUS_ENC_LEN]; // Customer-defined encrypted information
} DUA_BOARD_INFO_T, *DUA_BOARD_INFO_PTR;

typedef struct dua_capability {
    pps_s32 support_mic;           // microphone        , 0=not support, 1=support
    pps_s32 support_speaker;       // speaker           , 0=not support, 1=support
    pps_s32 support_wireless_ring; // wireless ring     , 0-not support, 1-support
    pps_s32 support_mech_ring;     // mechanical ring   , 0-not support, 1-support
    pps_s32 support_infrared;      // infrared          , 0-not support, 1-support
    pps_s32 support_whitelight;    // whitelight        , 0-not support, 1-support  note the brightness of whitelight can not be adjusted
    pps_s32 support_warmlight;     // warmlight         , 0-not support, 1-support  note the brightness of whitelight can be adjusted
    pps_s32 support_rgb;           // rgb light         , 0-not support, 1-support
    pps_s32 support_ptz;           // ptz               , 0-not support, 1-up/down/left/right, 2-left/right, 3-up/down
    pps_s32 support_ptz_privacy;   // support ptz privacy mode, 0-not support, 1-support
    pps_s32 support_pet_feed;      // pet dev feed motor, 0-not support, 1-support
    pps_s32 support_pet_stir;      // pet dev stir motor, 0-not support, 1-support
    pps_s32 support_battery;       // battery           , 0-not support, 1-support  note both plugin and lowpower device can have battery
    pps_s32 support_charge;        // battery charge    , 0-not support, 1-support
    pps_s32 support_voltameter;    // voltameter electrical measurement, 0-not support, 1-support
    pps_s32 support_adc;           // adc electrical measurement       , 0-not support, 1-support
    pps_s32 support_btl;           // battery lock      , 0-not support, 1-support
    pps_s32 support_tamper;        // tamper alarm      , 0-not support, 1-support
    pps_s32 support_4g;            // 4g network        , 0-not support, 1-support
    pps_s32 support_bt;            // bluetooth         , 0-not support, 1-support
    pps_s32 support_eth;           // wire network      , 0-not support, 1-support
    pps_s32 support_sd;            // sdcard            , 0=not support, 1=support
    pps_s32 support_lum;           // hardware light photosensitivity  , 0-not support, 1-support
    pps_s32 support_pir;           // pir sensor        , 0=not support, 1=single pir, 2=double pir
    pps_s32 support_radar;         // radar             , 0-not support, 1-support
    pps_s32 support_temperature;   // temperature sensor, 0-not support, 1-support
    pps_s32 support_humidity;      // humidity sensor   , 0-not support, 1-support
    pps_s32 support_lcd_screen;    // lcd screen        , 0-not support, 1-support
} DUA_CAPABILITY_T, *DUA_CAPABILITY_PTR;

typedef struct dua_dev_ex_capa {
    pps_s32 support_vtk;
    pps_s32 support_ndr;
    pps_s32 support_dnm;
    pps_s32 support_lwm;
    pps_s32 support_lwm2;
    pps_s32 support_pir;
    pps_s32 support_flk;
    pps_s32 support_rng;
    pps_s32 support_lot;
    pps_s32 support_sfi;
    pps_s32 support_pbr;
    pps_s32 support_pbs;
    pps_char msc[256];
}DUA_EX_CAPABILITY_T,*DUA_EX_CAPABILITY_PTR;
/********************************************************** media ********************************************************* */
/** @enum  dua_video_type
 * @brief <Video encoding format>
 */
typedef enum dua_video_type {
    DUA_VIDEO_H264_TYPE = 0,
    DUA_VIDEO_H265_TYPE = 1,
} DUA_VIDEO_TYPE_E;

typedef enum {
    DUA_MEDIA_PIC_CIF = 0,
    DUA_MEDIA_PIC_360P = 1,    /* 640 * 360 */
    DUA_MEDIA_PIC_VGA = 2,     /* 640 * 480 */
    DUA_MEDIA_PIC_D1_PAL = 3,  /* 720 * 576 */
    DUA_MEDIA_PIC_D1_NTSC = 4, /* 720 * 480 */
    DUA_MEDIA_PIC_720P = 5,    /* 1280 * 720  */
    DUA_MEDIA_PIC_1080P = 6,   /* 1920 * 1080 */
    DUA_MEDIA_PIC_2304x1296 = 7,
    DUA_MEDIA_PIC_2560x1440 = 8,
    DUA_MEDIA_PIC_2592x1520 = 9,
    DUA_MEDIA_PIC_2592x1536 = 10,
    DUA_MEDIA_PIC_2592x1944 = 11,
    DUA_MEDIA_PIC_2688x1520 = 12,
    DUA_MEDIA_PIC_2716x1524 = 13,
    DUA_MEDIA_PIC_3840x2160 = 14,
    DUA_MEDIA_PIC_4096x2160 = 15,
    DUA_MEDIA_PIC_3000x3000 = 16,
    DUA_MEDIA_PIC_4000x3000 = 17,
    DUA_MEDIA_PIC_7680x4320 = 18,
    DUA_MEDIA_PIC_3840x8640 = 19,
    DUA_MEDIA_PIC_1536x1536 = 20,
    DUA_MEDIA_PIC_480x480 = 21,
    DUA_MEDIA_PIC_864x480 = 22,
    DUA_MEDIA_PIC_2048x1536 = 23,
    DUA_MEDIA_PIC_2880x1620 = 24,
    DUA_MEDIA_PIC_480x360 = 25,
    DUA_MEDIA_PIC_1984x1488 = 26,
    DUA_MEDIA_PIC_2272x1704 = 27,
    DUA_MEDIA_PIC_320x240 = 28,
    DUA_MEDIA_PIC_2880x1600 = 29,
    DUA_MEDIA_PIC_3840x2144 = 30,
    DUA_MEDIA_PIC_2944x1656 = 31,
    DUA_MEDIA_PIC_1728x1728 = 32,
    DUA_MEDIA_PIC_320x180 = 33,
    DUA_MEDIA_PIC_BUTT
} DUA_VIDEO_RESOLUTION_E;

/** @enum  dua_audio_type
 * @brief <Audio format>
 */
typedef enum dua_audio_type {
    DUA_AUDIO_G711U_TYPE = 0,
    DUA_AUDIO_G711A_TYPE = 1,
    DUA_AUDIO_PCM_TYPE   = 2,
    DUA_AUDIO_AAC_TYPE   = 3,
    DUA_AUDIO_OPUS_TYPE  = 4,
} DUA_AUDIO_TYPE_E;

/** @enum  dua_stream_channel
 * @brief <Audio and video channels>
 */
typedef enum dua_stream_channel {
    // video stream channel
    DUA_VIDEO_MAIN_STREAM_CHANNEL     = 0,
    DUA_VIDEO_SUB_STREAM_CHANNEL      = 1,
    DUA_VIDEO_THIRD_STREAM_CHANNEL    = 2,
    DUA_VIDEO_SEC_MAIN_STREAM_CHANNEL = 3,
    DUA_VIDEO_SEC_SUB_STREAM_CHANNEL  = 4,
    DUA_VIDEO_SNAPSHOT_CHANNEL        = 5,
    DUA_VIDEO_SEC_SNAPSHOT_CHANNEL    = 6,

    // YUV stream channel
    DUA_VIDEO_MAIN_YUV_CHANNEL        = 10,
    DUA_VIDEO_SUB_YUV_CHANNEL         = 11,

    // audio stream channel
    DUA_AUDIO_G711U_STREAM_CHANNEL    = 20, // g711u and g711a can not register together, default g771u type
    DUA_AUDIO_G711A_STREAM_CHANNEL    = 21,
    DUA_AUDIO_PCM_STREAM_CHANNEL      = 22,
    DUA_AUDIO_AAC_STREAM_CHANNEL      = 23,
    DUA_AUDIO_OPUS_STREAM_CHANNEL     = 24,
} DUA_STREAM_CHANNEL_E;

/** @enum  dua_stream_type
 * @brief <The type of data fetched>
 */
typedef enum dua_stream_type {
    DUA_VIDEO_STREAM_DATA = 0,
    DUA_AUDIO_STREAM_DATA = 1
} DUA_STREAM_TYPE_E;

/** @enum  dua_video_bitrate_type
 * @brief <The bitrate type of the video>
 */
typedef enum dua_video_bitrate_type {
    DUA_VIDEO_CBR_TYPE = 0, // Fixed bit rate
    DUA_VIDEO_VBR_TYPE = 1, // Dynamic bitrate
} DUA_VIDEO_BITRATE_TYPE_E;

/** @enum  dua_video_quality
 * @brief <Video quality>
 */
typedef enum dua_video_quality {
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_1 = 0,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_2 = 1,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_3 = 2,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_4 = 3,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_5 = 4,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_6 = 5,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_7 = 6,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_8 = 7,
    DUA_MEDIA_VIDEO_QUALITY_LEVEL_9 = 8,
} DUA_VIDEO_QUALITY_E;

/** @enum  dua_osd_time_format
 * @brief <OSD time format>
 */
typedef enum dua_osd_time_format {
    DUA_OSD_YYYY_MM_DD_24HOURS     = 0,
    DUA_OSD_YYYY_S_MM_S_DD_12HOURS = 1,
    DUA_OSD_MM_S_DD_S_YYYY_12HOURS = 2,
    DUA_OSD_MM_DD_YYYY_12HOURS     = 3,
    DUA_OSD_DD_MM_YYYY_24HOURS     = 4,
    DUA_OSD_MM_DD_YYYY_24HOURS     = 5,
    DUA_OSD_YYYY_MM_DD_12HOURS     = 6,
    DUA_OSD_DD_MM_YYYY_12HOURS     = 7,
    DUA_OSD_MM_S_DD_S_YYYY_24HOURS = 8,
} DUA_OSD_TIME_FORMAT_T;

/** @enum  dua_antiflicker_mode
 * @brief <Anti-stroboscopic>
 */
typedef enum dua_antiflicker_mode {
    DUA_MEDIA_ANTIFLICKER_MODE_DISABLE = 0x0,
    DUA_MEDIA_ANTIFLICKER_MODE_AUTO,
    DUA_MEDIA_ANTIFLICKER_MODE_50HZ,
    DUA_MEDIA_ANTIFLICKER_MODE_60HZ,
    DUA_MEDIA_ANTIFLICKER_MODE_BUTT
} DUA_ANTIFLICKER_MODE_E;

/** @enum  dua_sleep_mode
 * @brief <the mode of sleeping>
 */
typedef enum dua_sleep_mode {
    DUA_SLEEP_MANUAL_OFF = 0, // off--镜头打开
    DUA_SLEEP_MANUAL_ON  = 1, // on--镜头关闭
    DUA_SLEEP_TIME       = 2,
    DUA_SLEEP_GEOGRAPHIC = 3,
    DUA_MODE_MAX,
} DUA_SLEEP_MODE_E;

/** @enum  dua_alarm_detect_level
 * @brief <the sensitivity of detecting noise/md/pd>
 */
typedef enum dua_alarm_detect_level {
    DUA_ALARM_DETECT_SENSITIVITY_LEVEL_LOW  = 1,
    DUA_ALARM_DETECT_SENSITIVITY_LEVEL_MID  = 2,
    DUA_ALARM_DETECT_SENSITIVITY_LEVEL_HIGH = 3,
} DUA_ALARM_DETECT_LEVEL_E;

/** @enum  dua_daynight_mode
 * @brief <Switch mode day and night>
 */
typedef enum dua_daynight_mode {
    DUA_DAYNIGHT_MODE_NONE  = 0,
    DUA_DAYNIGHT_MODE_DAY   = 1,
    DUA_DAYNIGHT_MODE_NIGHT = 2,
    DUA_DAYNIGHT_MODE_AUTO  = 3,
    DUA_DAYNIGHT_MODE_WARM  = 4,
    DUA_DAYNIGHT_MODE_QRCODE = 5,
} DUA_DAYNIGHT_MODE_E;

typedef enum dua_light_mode {
    DUA_DAYNIGHT_MODE_PROC_NONE     = 10,
    DUA_DAYNIGHT_MODE_PROC_AUTO     = 11,
    DUA_DAYNIGHT_MODE_PROC_VISIBLE  = 12,
    DUA_DAYNIGHT_MODE_PROC_INFRARED = 13,
} DUA_DAYNIGHT_MODE_PROC_E;

typedef enum device_net_wifi_module {
    NET_WIFI_MODULE_NONE          = 0,
    NET_WIFI_MODULE_ATBM603X      = 1,  // 6032
    NET_WIFI_MODULE_8188FU        = 2,  // 8188
    NET_WIFI_MODULE_SSW101B       = 3,  // ssw101b
    NET_WIFI_MODULE_SSV6X5X       = 4,  // ssv6x5x
    NET_WIFI_MODULE_3881          = 5,  // 3881
    NET_WIFI_MODULE_HGICS         = 6,  // hgics 蓝牙双模wifi
    NET_WIFI_MODULE_8192FU        = 7,  // 8192
    NET_WIFI_MODULE_8731BU        = 8,  // 8731
    NET_WIFI_MODULE_8733BU        = 9,  // 8733
    NET_WIFI_MODULE_8733BU_BT     = 10, // 8733_bt
    NET_WIFI_MODULE_8733BU_BT_BLE = 11, // 8733_bt 蓝牙驱动
    NET_WIFI_MODULE_SSV635X       = 12, // ssv635x 蓝牙双模
    NET_WIFI_MODULE_ATBM6062      = 13, // atmb6052 wifi蓝牙
    NET_WIFI_MODULE_AIC8800BU     = 14, // aic8800
    NET_WIFI_MODULE_AIC8800BU_BT  = 15, // aic8800 蓝牙
    //低功耗
    NET_WIFI_MODULE_ESP32C6       = 100, //
    NET_WIFI_MODULE_MRC6          = 101, //
    NET_WIFI_MODULE_AIW4211L      = 102,
    NET_WIFI_MODULE_3861L         = 103,
    NET_WIFI_MODULE_EC2           = 104,
    NET_WIFI_MODULE_MC66          = 105,
    NET_WIFI_MODULE_EC800         = 106,
    NET_WIFI_MODULE_EG800         = 107,
    NET_WIFI_MODULE_BL616C        = 108,
} DEVICE_NET_WIFI_MODULE_E;

typedef enum {
    DUA_MEDIA_WAKEUP_AOV = 0,
    DUA_MEDIA_WAKEUP_PIR = 1,
    DUA_MEDIA_WAKEUP_PEOPLE_DETECT = 2,
    DUA_MEDIA_WAKEUP_RECORD = 3,
    DUA_MEDIA_WAKEUP_OTHRER  = 4,
} DUA_MEDIA_WAKEUP_MODE_E;

/** @enum  dua_daynight_mode
 * @brief <Switch mode day and night>
 */
typedef enum dua_customized_resolution {
    DUA_VIDEO_RESOLUTION_DEFALUT      = 0,
    DUA_VIDEO_SUB_RESOLUTION_1280_720 = 100, // not all platform support customized sub stream resolution
} DUA_CUSTOMIZED_RESOLUTION_E;

/** @enum  dua_isp_info_type
 * @brief <media isp info type>
 */
typedef enum dua_isp_info_type {
    DUA_ISP_INFO_TYPE_WB = 0x0,       /* DUA_ISP_WB_INFO_T */
    DUA_ISP_INFO_TYPE_EXPOSURE = 1,   /* DUA_ISP_EXPOSURE_INFO_T */
    DUA_ISP_INFO_TYPE_FORCUS = 2,     /* undefined */
    DUA_ISP_INFO_TYPE_BUTT
} DUA_ISP_INFO_TYPE_E;

typedef struct {
    pps_u32 luma;          /* [0, 0xFFFFFFFF] */
    pps_u32 rgain;         /* [0, 0xFFFFFFFF] */
    pps_u32 bgain;         /* [0, 0xFFFFFFFF] */
    pps_u32 color_temp;   /* [0, 0xFFFFFFFF] */
} DUA_ISP_WB_INFO_T, *DUA_ISP_WB_INFO_PTR;

typedef struct {
    pps_u32 exposure_time; /* [0, 0xFFFFFFFF] */
    pps_u32 exposure_value; /* [0, 0xFFFFFFFF] */
} DUA_ISP_EXPOSURE_INFO_T, *DUA_ISP_EXPOSURE_INFO_PTR;

typedef struct dua_image_flip_mirror_param {
    pps_u32 is_mirror;
    pps_u32 is_flip; /* turn upside down, doesn't means rotating 180 degree. */
} DUA_IMGAE_FLIP_MIRROR_PARAM_T, *DUA_IMGAE_FLIP_MIRROR_PARAM_PTR;

#define DUA_OSD_PRE_SUF_FIX_LEN 16
/** @struct dua_osd_param
 * @brief  <OSD configuration information>
 */
typedef struct dua_osd_config {
    pps_s32               osd_enable;
    pps_s32               time_osd_x_pos;                           // time osd start x position
    pps_s32               time_osd_y_pos;                           // time osd start y position
    DUA_OSD_TIME_FORMAT_T time_osd_format;                          // time osd format
    pps_char              time_osd_prefix[DUA_OSD_PRE_SUF_FIX_LEN]; // time osd prefix
    pps_char              time_osd_suffix[DUA_OSD_PRE_SUF_FIX_LEN]; // time osd suffix
} DUA_OSD_CONFIG_T, *DUA_OSD_CONFIG_PTR;

#define DUA_AOV_OSD_MAX_LEN 8
/** @struct dua_osd_param
 * @brief  <OSD configuration information>
 */
typedef struct dua_aov_osd_config {
    pps_s32               aov_osd_enable;
    pps_s32               aov_osd_x_pos;                           // time osd start x position
    pps_s32               aov_osd_y_pos;                           // time osd start y position
    pps_char              aov_osd_str[DUA_AOV_OSD_MAX_LEN];        // time osd format
} DUA_AOV_OSD_CONFIG_T, *DUA_AOV_OSD_CONFIG_PTR;

#define DUA_LOGO_PATH_LEN 64
/** @struct dua_logo_config
 * @brief  <Logo watermark configuration information>
 */
typedef struct dua_logo_config {
    pps_u32  logo_x;                           // Logo watermark The x-axis coordinate of the starting position
    pps_u32  logo_y;                           // Logo watermark The y-axis coordinate of the starting position
    pps_u32  logo_height;                      // Logo watermark high
    pps_u32  logo_width;                       // Logo watermark wide
    pps_u32  logo_transprency;                 // Logo watermark transparency
    pps_char logo_bmp_path[DUA_LOGO_PATH_LEN]; // logo watermark Image path
    pps_u32  logo_enable;                      // logog enable
} DUA_LOGO_CONFIG_T, *DUA_LOGO_CONFIG_PTR;

/** @struct dua_video_image_param
 * @brief  <视频画面参数设置>
 */
typedef struct dua_video_image_param {
    pps_u32 brightness; // value range: [0, 100], 50 is default
    pps_u32 contrast;   // value range: [0, 100], 50 is default
    pps_u32 sharpness;  // value range: [0, 100], 50 is default
    pps_u32 saturation; // value range: [0, 100], 50 is default
} DUA_VIDEO_IMAGE_PARAM_T, *DUA_VIDEO_IMAGE_PARAM_PTR;

/** @struct  dua_video_stream
 * @brief   <Information for the video stream>
 */
typedef struct dua_video_stream {
    pps_u32                       width;             // Resolution width (if there is no customization, width corresponds to pic_size, otherwise it is according to the customized width)
    pps_u32                       height;            // High resolution (if there is no customization, height corresponds to pic_size, otherwise it is customized high)
    DUA_VIDEO_TYPE_E              encode_type;       // Stream encoding format
    DUA_VIDEO_BITRATE_TYPE_E      bitrate_type;      // Bitrate type
    pps_u32                       bitrate;           // bit rate
    pps_u32                       fps;               // Frame rate
    DUA_IMGAE_FLIP_MIRROR_PARAM_T filp_mirror_param; // Imaging type
    DUA_VIDEO_QUALITY_E           quality;           // Stream quality
    DUA_VIDEO_IMAGE_PARAM_T       image;             // Video screen parameters
} DUA_VIDEO_STREAM_INFO_T, *DUA_VIDEO_STREAM_INFO_PTR;

/** @struct  dua_audio_stream_info
 * @brief   <Information for the audio stream>
 */
typedef struct dua_audio_stream_info {
    pps_u32 sample_rate; // Sample rate
    pps_u32 bit_width;   // Bit width
} DUA_AUDIO_STREAM_INFO_T, *DUA_AUDIO_STREAM_INFO_PTR;

/** @struct  dua_speaker_audio_data
 * @brief   <Information for audio playback>
 */
typedef struct dua_speaker_audio_data {
    pps_ulong        seq;
    pps_char        *data;
    pps_u32          data_len;
    DUA_AUDIO_TYPE_E payload;
    pps_ulong        pts;         // stream timestamp, unit: ms
    pps_u32          sample_rate; // for now, only support 8000
} DUA_SPEAKER_AUDIO_DATA_T, *DUA_SPEAKER_AUDIO_DATA_PTR;

typedef struct {
    pps_s32  enable;
    pps_char voicemail_url[256];
} DUA_VOICEMAIL_T;

/** @struct  dua_media_header
 * @brief   <Data headers for audio/video streams>
 */
typedef struct dua_media_header_t {
    pps_u32 seq;          // media header: old: 0x56565099, now: vidoe/audio sequence
    pps_u32 videoid;      // sensor 0;sensor 1;
    pps_u32 streamid;     // stream type: 0: main stream 1: sub-stream
    pps_u32 media_format; // media encoding format
                          // 0x01=H264 0x02=mpeg4 0x03=mjpeg, 0x04=h265
                          // 0x81=aac 0x82=g711u 0x83=g711a 0x84=g726_16 0x85=G726_32 0x90=PCM
                          // 0xffe=sleep mode

    pps_u32 frame_type; // 0xF0 = video frame type main frame
                        // 0xF1 = video fill the frame
                        // 0xF2 = pps 0xF3 = sps
                        // 0xFA = audio frame
    union {
        struct {
            pps_u32 frame_rate; // frame rate
            pps_u32 width;      // video width
            pps_u32 height;     // video High
        } video;

        struct {
            pps_u32 sample_rate; // sampling Rate 0=8000 1=12000 2=11025 3=16000 4=22050 5=24000 6=32000 7=44100 8=48000
            pps_u32 bit_rate;    // audio of bit rate
            pps_u32 bit_width;   // audio of bit width
            pps_u32 channels;    // channel
        } audio;
    };

    pps_u32 timestamp;   // timestamp, millisecond
    pps_u64 timestamp64; // timestamp, millisecond
    pps_u32 datetime;    // utc time the frame data, second grade
    pps_u32 size;        // The length of the frame data
} DUA_MEDIA_HEADER_T, *DUA_MEDIA_HEADER_PTR;

/** @fn      pps_s32 (*dua_media_avstream_cb)(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 len);
 * @brief   <Callback for audio and video retrieval>
 * @param   [in] av_type: Audio and video type: DUA_STREAM_TYPE_E
 * @param   [in] header : Data flow headers
 * @param   [in] data   : Streaming data
 * @param   [in] len    : Stream data size length
 * @return  0 - Initialization succeeded | else - Initialization failed
 */
typedef pps_s32 (*dua_media_avstream_cb)(pps_s32 av_type, DUA_MEDIA_HEADER_PTR header, pps_void *data, pps_s32 len);

/** @fn      pps_void (*dua_qrcode_get_result_cb)(pps_char *data, pps_u32 len);
 * @brief   <Get the scan results>
 * @param   [in] data: QR code data
 * @param   [in] len : QR code data length
 * @return  no return
 */
typedef pps_void (*dua_qrcode_get_result_cb)(pps_char *data, pps_u32 len);

/** @fn      pps_s32 (*dua_get_alarm_schedule_cb)(pps_void);
 * @return   alarm_schedule
 */
typedef pps_s32 (*dua_get_alarm_schedule_cb)(pps_void);
/********************************************************** media **********************************************************/

/********************************************************** avproc **********************************************************/
/** @enum  dua_avproc_type
 * @brief <DUA Intelligent algorithm detection type>
 */
typedef enum dua_avproc_type {
    // video
    DUA_AVPROC_MOTION_DETECTION   = 0,
    DUA_AVPROC_PEOPLE_DETECTION   = 1,
    DUA_AVPROC_CAR_DETECTION      = 2,
    DUA_AVPROC_PET_DETECTION      = 3,
    DUA_AVPROC_FACE_DETECTION     = 4,
    DUA_AVPROC_PIR_REAL_DETECTION = 5,
    DUA_AVPROC_PACKAGE_DETECTION  = 6,
    // Multi-model
    DUA_AVPROC_MUTLI_MODEL = 99,
    // audio
    DUA_AVPROC_BABY_CRY_DETECTION = 500,
    DUA_AVPROC_NOISE_DETECTION    = 501,
    DUA_AVPROC_DOG_BARK_DETECTION = 502,
} DUA_AVPROC_TYPE_E;

/** @struct  dua_avporc_tracking_info
 * @brief   <dua Humanoid/motion tracking>
 */
typedef struct dua_avporc_tracking_info {
    pps_s32 enable;
    pps_s32 sensor_id;
    pps_s32 x;
    pps_s32 y;
    pps_u32 width;
    pps_u32 height;
} DUA_AVPROC_TRACKING_INFO_T, *DUA_AVPROC_TRACKING_INFO_PTR;

#define DUA_POLYGPN_MAX_AREA 6

typedef double (*dua_media_corrd_t)[2];

// 单区域
typedef struct dua_avproc_polygon {
    pps_s32           vertex;
    dua_media_corrd_t coordinate;
} DUA_AVPROC_POLYGON_T, *DUA_AVPROC_POLYGON_PTR;

// 一个镜头的所有区域
typedef struct dua_avproc_polygon_alarm_roi {
    pps_s32              rgn_cnt;
    DUA_AVPROC_POLYGON_T polygon_area[DUA_DETECTION_MAX_AREA];
} DUA_AVPROC_POLYGON_ALARM_ROI_T, *DUA_AVPROC_POLYGON_ALARM_ROI_PTR;

#define DUA_ROI_BITMAP 36

typedef struct {
    pps_char bitmap[DUA_ROI_BITMAP];
} DUA_AVPROC_ALARM_BITMAP_ROI_T, *DUA_AVPROC_ALARM_BITMAP_ROI_PTR;

typedef enum dua_zone_type {
    DUA_ZONE_TYPE_RECTANGLES = 0,
    DUA_ZONE_TYPE_POLYGON    = 1,
} DUA_ZONE_TYPE_E;

#define DUA_MAX_SENSOR_NUM 2
/** @struct DUA_AVPROC_PARAM_T
 * @brief  <avproc default configuration information>
 */
typedef struct dua_avproc_cfg_t {
    DUA_AVPROC_TYPE_E type;                          // avproc type
    pps_s32           enable[DUA_MAX_SENSOR_NUM];    // avproc detect zone enable
    pps_s32           zone_type[DUA_MAX_SENSOR_NUM]; // avproc detect set zone type DUA_ZONE_TYPE_E
    pps_void         *zone;                          // avproc detect zone
    pps_s32           zone_size[DUA_MAX_SENSOR_NUM]; // avproc detect zone size
    pps_s32           level[DUA_MAX_SENSOR_NUM];     // avproc detect level   battery_type:[pd score threshold]
                                       // plugin_type: DUA_ALARM_DETECT_LEVEL_E
    pps_s32 sensor_nums; // avproc sensor nums
} DUA_AVPROC_CFG_T, *DUA_AVPROC_CFG_PTR;


#define MCP_ALARM_PIC_MAX_COUNT 2

typedef struct {
    pps_char *pic_data;
    pps_u32   pic_size;
} MCP_ALARM_PIC_T;

typedef struct {
    pps_char  name[32];
    pps_float score;
    pps_u32   top;
    pps_u32   left;
    pps_u32   width;
    pps_u32   height;
    pps_char  event[32];
} MCP_AI_VEDIO_INFO_T;

typedef struct {
    pps_u32             curtime;
    pps_s32             duration;
    pps_u8              record_enable;
    pps_s32             sensor_id;
    pps_u8              pic_count;
    MCP_ALARM_PIC_T     data[MCP_ALARM_PIC_MAX_COUNT];
    pps_s32             ext_data; // 额外数据，如噪声报价需要上报噪音数值
    pps_s32             obj_num;
    MCP_AI_VEDIO_INFO_T aivideoinfo[12];
} MCP_ALARM_INFO_T;

/********************************************************** avproc **********************************************************/

/********************************************************** charm **********************************************************/
/** @struct CHARM_SEND_PKG_T
 * @brief  <OSD configuration information>
 */
typedef struct charm_send_pkg {
    pps_u8  data[128];           // payload data
    pps_s32 data_len;            // payload data size
    pps_s32 times;               // send package times
    pps_s32 timeout_us;          // bit timeval
    pps_s32 external_charm_ctrl; // open external charm
} CHARM_SEND_PKG_T, *CHARM_SEND_PKG_PTR;

/** @struct CHARM_LINKAGE_DEVID_E
 * @brief  <charm linkage devid>
 */
typedef enum charm_linkage_devid_e {
    DUA_CHARM_LINKAGE_MIN      = 0x0,
    DUA_CHARM_LINKAGE_CHARM    = 0x1,
    DUA_CHARM_LINKAGE_DOORLOCK = 0x2,
    DUA_CHARM_LINKAGE_LIGHT    = 0x3,
    DUA_CHARM_LINKAGE_SWITCH   = 0x4,
    DUA_CHARM_LINKAGE_GARAGE   = 0x5,
    DUA_CHARM_LINKAGE_RELAY    = 0x6,
    DUA_CHARM_LINKAGE_ALL      = 0xff
} CHARM_LINKAGE_DEVID_E;

/** @struct dua_charm_play
 * @brief  <charm play param>
 */
typedef struct dua_charm_play {
    pps_s32 enable;
    pps_s32 song_id;  /**< select song id */
    pps_s32 volume;   /**< charm play volume */
    pps_s32 duration; /**< charm play duration */
} DUA_CHARM_PLAY_T;

/** @struct DUA_DOORBELL_STATE_E
 * @brief  <doorbell state>
 * @note   <tuya use>
 */
typedef enum dua_doorbell_state_e {
    DUA_DOORBELL_NOTINIT        = 0,
    DUA_DOORBELL_DISABLE        = 1,
    DUA_DOORBELL_ENABLE         = 2,
    DUA_DOORBELL_RF_ENABLE      = 3,
    DUA_DOORBELL_DIGITAL_ENABLE = 4,
} DUA_DOORBELL_STATE_E;
/********************************************************** charm **********************************************************/

/********************************************************** ptz **********************************************************/
/** @enum  dua_ptz_ctrl_cmd
 * @brief <Gimbal control instructions>
 */
typedef enum dua_ptz_move_ctrl_cmd {
    DUA_PTZ_MOVE_CTRL_CMD_DEFAULT,
    DUA_PTZ_MOVE_CTRL_CMD_UP,
    DUA_PTZ_MOVE_CTRL_CMD_DOWN,
    DUA_PTZ_MOVE_CTRL_CMD_LEFT,
    DUA_PTZ_MOVE_CTRL_CMD_RIGHT,
    DUA_PTZ_MOVE_CTRL_CMD_VERTICAL_STOP,
    DUA_PTZ_MOVE_CTRL_CMD_HORIZONTAL_STOP,
    DUA_PTZ_MOVE_CTRL_CMD_STOP_ALL,
} DUA_PTZ_MOVE_CTRL_CMD_E;

typedef enum dua_motor_pt_type {
    DUA_MOTOR_P_TYPE = 0x0,
    DUA_MOTOR_T_TYPE = 0x1,
} DUA_MOTOR_PT_TYPE_E;

/********************************************************** ptz **********************************************************/

/********************************************************** light **********************************************************/
/** @enum  dua_led_id
 * @brief <led id>
 */
typedef enum dua_led_id {
    DUA_LED_BLUE   = 0, // LED blue
    DUA_LED_RED    = 1, // LED Red
    DUA_LED_YELLOW = 2, // LED yellow
    DUA_LED_EPHY   = 3, // NVR Ethernet lights
    DUA_LED_LIGHT  = 4, // flight
} DUA_LED_ID_E;

/** @enum  dua_light_id
 * @brief <light id>
 */
typedef enum dua_light_ctrl_type {
    DUA_LIGHT_CTRL_TYPE_SOFT = 0,
    DUA_LIGHT_CTRL_TYPE_HARD = 1,
} DUA_LIGHT_CTRL_TYPE_E;

/** @enum  dua_infr_id
 * @brief <infrared led>
 */
typedef enum dua_infr_id {
    DUA_INFR_ID_1     = 0,
    DUA_INFR_ID_2_PWM = 1,
} DUA_INFR_ID_E;

/********************************************************** light **********************************************************/

/********************************************************** battery **********************************************************/
/** @enum   dua_battery_status
 * @brief  <battery status>
 */
typedef enum dua_battery_status {
    DUA_POWER_MODE_DISCHARGING = 0,
    DUA_POWER_MODE_CHARGING    = 1,
    DUA_POWER_MODE_CHARGED     = 2,
    DUA_POWER_MODE_USB         = 3,
    DUA_POWER_MODE_ERROR       = 0xff
} DUA_BATTER_STATUS_T,
  *DUA_BATTER_STATUS_PTR;
/********************************************************** battery **********************************************************/

/********************************************************** network **********************************************************/
/** @enum  dua_wifi_keymgmt
 * @brief <WiFi encryption/authentication type>
 * @note
 */
typedef enum dua_wifi_keymgmt {
    DUA_WPA_CLI_ENC_TYPES_NONE,
    DUA_WPA_CLI_ENC_TYPES_WEP,
    DUA_WPA_CLI_ENC_TYPES_WPA,
    DUA_WPA_CLI_ENC_TYPES_WPA_TKIP,
    DUA_WPA_CLI_ENC_TYPES_WPA_AES,

    DUA_WPA_CLI_ENC_TYPES_WPA2,
    DUA_WPA_CLI_ENC_TYPES_WPA2_TKIP,
    DUA_WPA_CLI_ENC_TYPES_WPA2_AES,
    DUA_WPA_CLI_ENC_TYPES_WPA2_AES_TKIP,

    DUA_WPA_CLI_ENC_TYPES_WPA_WPA2,
    DUA_WPA_CLI_ENC_TYPES_WPA_WPA2_TKIP,
    DUA_WPA_CLI_ENC_TYPES_WPA_WPA2_AES,
    DUA_WPA_CLI_ENC_TYPES_WPA_WPA2_AES_TKIP,
    DUA_WPA_CLI_ENC_TYPES_WPA3,
    DUA_WIFI_KEYMGMT_MAX = 254,
} DUA_WIFI_KEYMGMT_E;

/** @enum  dua_wifi_keymgmt
 * @brief <WiFi encryption/authentication type>
 * @note
 */
typedef enum dua_wifi_type {
    DUA_WIFI_4,
    DUA_WIFI_5,
    DUA_WIFI_6,
} DUA_WIFI_TYPE_E;

/** @struct dua_network_wifi_param
 * @brief  <WiFi information>
 * @note
 */
typedef struct dua_network_wifi_param {
    pps_char ssid[DEV_WIFI_MAX_SSID_LEN + 1];
    pps_char res[3];
    pps_char psw[DEV_WIFI_MAX_PASSWORD_LEN + 1];
    pps_char res2[3];
    pps_char bssid[DEV_WIFI_MAX_BSSID_LEN + 1];
    pps_u8   keymgmt;   // DUA_WIFI_KEYMGMT_E
    pps_u8   wifi_type; // DUA_WIFI_TYPE_E
    pps_u8   priority;  // 0-first choice to connect, other is alternate wifi
    pps_s32  db_signal;
    pps_s32  freq;
} DUA_NETWORK_WIFI_PARAM_T, *DUA_NETWORK_WIFI_PARAM_PTR;

typedef struct dua_network_ap_info {
    pps_char ssid[DEV_WIFI_MAX_SSID_LEN + 1]; // SSID only support ASCLL
    pps_u8   channel;                         // channel，range to 1-14
    pps_char res[2];
    pps_char bssid[DEV_WIFI_MAX_PASSWORD_LEN + 1]; // BSSID
    pps_char res2[3];
    pps_s32  auth; // auth mode
    pps_s32  rssi; // signal level
    pps_s32  freq; // freq
} DUA_NETWORK_AP_INFO_T, *DUA_NETWORK_AP_INFO_PTR;

typedef enum {
    NETWORK_NET_DEFAULT = 0,
    NETWORK_NET_OFFLINE = 1,
    NETWORK_NET_ONLINE  = 2,
    NETWORK_NET_FACTORY = 3,
} NETWORK_NETCOON_STATE_E;

typedef enum {
    DUA_NETWORK_WIFI_LINK_CONNECT_SUCCESS        = 200,  // 配网成功
    DUA_NETWORK_WIFI_LINK_TIMEOUT                = 2000, // 配网等待超时
    DUA_NETWORK_WIFI_LINK_QR_SCAN_FAILE          = 2001, // 配网信息解析失败
    DUA_NETWORK_WIFI_LINK_NOT_FOUND              = 2010, // 未检索到SSID
    DUA_NETWORK_WIFI_LINK_POOR_SIGNAL            = 2011, // WIFI信号弱
    DUA_NETWORK_WIFI_LINK_CONNECT_ROUTER_TIMEOUT = 2020, // 连接路由器超时
    DUA_NETWORK_WIFI_LINK_PASSWORD_ERROR         = 2021, // 密码错误
    DUA_NETWORK_WIFI_LINK_EQUIPMENT_SECURE_MODE  = 2022, // 安全模式不支持
    DUA_NETWORK_WIFI_LINK_ENC_TYPE_NOT_SUPPORT   = 2023, // 加密方式不支持
    DUA_NETWORK_WIFI_LINK_ROUTER_REJUCT          = 2024, // 路由器拒绝
    DUA_NETWORK_WIFI_LINK_UNCONN_PUBLIC_NET      = 2025, // 路由器未接入外网
    DUA_NETWORK_WIFI_LINK_DHCP_TIMEOUT           = 2050, // 获取DHCP超时
} DUA_NETWORK_WIFI_LINK_STATE_E;

typedef struct network_wifi_swi_result_t {
    pps_char                      ssid[128];
    DUA_NETWORK_WIFI_LINK_STATE_E state;
} DUA_NETWORK_WIFI_LINK_SWI_RESULT_T, *DUA_NETWORK_WIFI_LINK_SWI_RESULT_PTR;

typedef struct dua_network_wifi_info {
    DUA_NETWORK_WIFI_PARAM_T           cur_connect_wifi;
    DUA_NETWORK_WIFI_LINK_SWI_RESULT_T cur_connect_wifi_state[2];
    pps_s32                            connect_wifi_info_num;
    DUA_NETWORK_WIFI_PARAM_T           connect_wifi_info[2];
} DUA_NETWORK_WIFI_INFO_T, *DUA_NETWORK_WIFI_INFO_PTR;


/** @struct dua_network_status
 * @brief  <Network status information>
 * @note
 */
typedef enum dua_network_status {
    DUA_NETWORK_DEFAULT,
    // AP
    DUA_NETWORK_AP_MODE, // In AP mode
    // BT
    DUA_NETWORK_BT_MODE, // In BT mode
    // STATION
    DUA_NETWORK_WIFI_CONNECTING,   // WIFI connection in station mode
    DUA_NETWORK_WIFI_CONNECTED,    // In station mode, WIFI connection is successful
    DUA_NETWORK_WIFI_DISCONNECTED, // In station mode WIFI connection failed
    DUA_NETWORK_WIFI_ACCESS_NET,   // In station mode WIFI successfully obtains IP and accesses the network
    // WIRE NET
    DUA_NETWORK_WIRE_NET_CONNECTING,   // Wired network connection
    DUA_NETWORK_WIRE_NET_CONNECTED,    // The wired network connection is successful
    DUA_NETWORK_WIRE_NET_DISCONNECTED, // The wired network connection is lost
    // 4G NET

} DUA_NETWORK_STATUS_E;

/** @struct dua_network_status_info
 * @brief  <Network status information>
 * @note
 */
typedef struct dua_network_status_info {
    pps_char                       if_name[16];
    DUA_NETWORK_STATUS_E           status;
    DUA_NETWORK_CONNECT_ERR_CODE_E err_code;
    pps_s32                        wifi_rssi;
} DUA_NETWORK_STATUS_T, *DUA_NETWORK_STATUS_PTR;
/********************************************************** network **********************************************************/

/********************************************************** storage **********************************************************/
/** @enum  dua_sd_status
 * @brief <Dua sdcard status>
 */
typedef enum dua_sd_status {
    DUA_SD_STATUS_UNPLUGED       = 0, /* The card is not inserted */
    DUA_SD_STATUS_NORMAL         = 1, /* In normal use */
    DUA_SD_STATUS_ERROR          = 2, /* sdcard status error */
    DUA_SD_STATUS_FORMATING      = 3, /* format */
    DUA_SD_STATUS_LOADING        = 4, /* Identify loading */
    DUA_SD_STATUS_MANUAL_UNMOUNT = 5, /* It is not mounted, which is usually the state after manual unmounting */
} DUA_SDCARD_STATUS_E;

/** @enum  dua_sdcard_err_code
 * @brief <Error code for dua sdcard status>
 */
typedef enum dua_sdcard_err_code {
    DUA_SD_ERROR_NULL    = 0, /* inerrancy */
    DUA_SD_IO_ERROR      = 1, /* Bad card or IO abnormality */
    DUA_SD_FS_UNSUPPORT  = 2, /* File system is not supported */
    DUA_SD_UNFORMATED    = 3, /* SD card is not formatted, including no partitions and so on */
    DUA_SD_UNKNOWN_ERROR = 4, /* Unknown error */
} DUA_SDCARD_ERR_CODE_E;

/** @enum  dua_sdcard_status
 * @brief <Dua sdcard status information>
 */
typedef struct dua_sdcard_status {
    DUA_SDCARD_STATUS_E   status;   // sdcard status
    DUA_SDCARD_ERR_CODE_E err_code; // Error status code
} DUA_SDCARD_STATUS_T, *DUA_SDCARD_STATUS_PTR;

/** @enum  dua_sdcard_info
 * @brief <Dua sdcard information>
 */
typedef struct dua_sdcard_info {
    pps_char mount_dir[32];
    pps_u64  total_bytes;
    pps_u64  used_bytes;
    pps_u64  free_bytes;
} DUA_SDCARD_INFO_T, *DUA_SDCARD_INFO_PTR;

/** @enum  dua_record_type
 * @brief <Dua record recording type>
 */
typedef enum dua_record_type {
    DUA_RECORD_TYPE_UNKOWN   = 0,
    DUA_RECORD_TYPE_CONTINUE = 1, // Continuous recording
    DUA_RECORD_TYPE_EVENT    = 2, // Event recording: Events have a short-term timeliness, which can be triggered by external events, timers, etc., and the recording will automatically stop when the recording reaches the time
} DUA_RECORD_TYPE_E;

/** @struct  dua_record_search_time
 * @brief <Dua record recording type>
 */
typedef struct dua_record_search_time {
    pps_s32 year;
    pps_s32 month;
    pps_s32 day;
    pps_s32 hour;
    pps_s32 min;
    pps_s32 sec;
} DUA_RECORD_TIME_T, DUA_RECORD_TIME_SEARCH_T, *DUA_RECORD_TIME_SEARCH_PTR;

/** @struct dua_recorder_day_search
 * @brief  <Search the structure by day>
 */
typedef struct dua_recorder_day_search {
    pps_s32 year;  /**<After Year 1990*/
    pps_s32 month; /**<1-12*/
    pps_s32 day;   /**<1-31*/
} DUA_RECORDER_DAY_SEARCH_T, *DUA_RECORDER_DAY_SEARCH_PTR;

/** @struct dua_recorder_month_search
 * @brief  <Monthly search structure>
 */
typedef struct dua_recorder_month_search {
    pps_s32 year;  /**<After Year 1990*/
    pps_s32 month; /**<1-12*/
} DUA_RECORDER_MONTH_SEARCH_T, *DUA_RECORDER_MONTH_SEARCH_PTR;

/** @struct dua_recorder_day_list
 * @brief  <day search result>
 * @note   please do not use in the stack memory, malloc for it
 */
typedef struct dua_recorder_day_list {
    pps_s32 recordnum; /**<There Recording Days*/
    struct {
        pps_u8  start_hour;
        pps_u8  start_min;
        pps_u8  start_sec;
        pps_u8  stop_hour;
        pps_u8  stop_min;
        pps_u8  stop_sec;
        pps_u8  reserved[2];
        pps_s32 duration;
    } record_list[60 * 24];
} DUA_RECORDER_DAY_LIST_T, *DUA_RECORDER_DAY_LIST_PTR;

/** @struct dua_recorder_month_list
 * @brief  <monthly search result>
 * @note   please do not use in the stack memory, malloc for it
 */
typedef struct dua_recorder_month_list {
    pps_s32 recordnum;      /**<There Recording Days*/
    pps_s32 recordlist[31]; /**<Back to search results month, 0 month 1- month there is no video recording*/
} DUA_RECORDER_MONTH_LIST_T, *DUA_RECORDER_MONTH_LIST_PTR;

typedef enum {
    MCP_RECORD_FRAME_UNKNOWN = 0,

    /* video */
    MCP_RECORD_FRAME_H264_IFRAME = 1,
    MCP_RECORD_FRAME_H264_PFRAME = 2,
    MCP_RECORD_FRAME_H264_BFRAME = 3,

    MCP_RECORD_FRAME_HEVC_IFRAME = 4,
    MCP_RECORD_FRAME_HEVC_PFRAME = 5,
    MCP_RECORD_FRAME_HEVC_BFRAME = 6,

    /* audio */
    MCP_RECORD_FRAME_G711U = 7,
    MCP_RECORD_FRAME_AAC   = 8, /* with ADTS head */
    MCP_RECORD_FRAME_PCM   = 9,
    MCP_RECORD_FRAME_G711A = 10,
} MCP_RECORD_FRAME_TYPE_E;

typedef enum {
    MCP_RECORD_AVTYPE_VIDEO = 0,
    MCP_RECORD_AVTYPE_AUDIO = 1,
    MCP_RECORD_AVTYPE_OTHER = 2,
} MCP_RECORD_AVTYPE_E;

typedef enum {
    MCP_RECORD_AVCODEC_UNKNOWN = 0,

    /* video */
    MCP_RECORD_AVCODEC_VIDEO_BASE = 1,
    MCP_RECORD_AVCODEC_H264       = 1,

    /* warning:
     * please do not define 3, never!
     * old codes use 3 to define G711U, 5 to define AAC
     */

    MCP_RECORD_AVCODEC_HEVC = 4, // H265

    /* audio */
    MCP_RECORD_AVCODEC_AUDIO_BASE = 5,
    MCP_RECORD_AVCODEC_G711U      = MCP_RECORD_AVCODEC_AUDIO_BASE,
    MCP_RECORD_AVCODEC_G711A      = 6,
    MCP_RECORD_AVCODEC_AAC        = 7,
    MCP_RECORD_AVCODEC_PCM        = 8,
} MCP_RECORD_AVCODEC_E;

/** @struct dua_playback_avframe
 * @brief  <dua A frame of data played back>
 */
typedef struct dua_playback_avframe {
    pps_u32 size; // buffer used size
    /* streamid:0-15, trackid: 0-15 */
#if defined(CONFIG_BIG_ENDIAN)
    pps_u8 stream_id : 4; // stream id, start from 0
    pps_u8 track_id : 4;  // track_id
#elif defined(CONFIG_LITTLE_ENDIAN)
    pps_u8 track_id : 4;  // track_id
    pps_u8 stream_id : 4; // stream id, start from 0
#else
#error "undefined endian information"
#endif

    pps_u8  avtype;     // see MCP_RECORD_AVTYPE_E
    pps_u8  frame_type; // see MCP_RECORD_FRAME_TYPE_E
    pps_u8  codec_id;   // see MCP_RECORD_AVCODEC_E
    pps_u32 seq;        // sequence
    pps_u32 date;       // seconds, system unix time
    pps_u32 pts;        // ms
    pps_s32 is_dst;     // is_dst=1 means daylight saving time, and 0 is non-daylight saving time
    pps_s32 is_west;    // West=1 means the western time zone, and 0 is the east time zone
    pps_s32 timezone;   // timezone: seconds(absolute value)
    union {
        struct {
            pps_u32 width;
            pps_u32 height;
            pps_u32 frame_rate;
            pps_u32 resv2;
        } video;
        struct {
            pps_u32 sample_rate;
            pps_u32 bit_per_sample;
            pps_u32 bit_rate;
            pps_u32 audio_format;
        } audio;
    };
    pps_void *buf;

    /* No user is required to actively populate */
    pps_u32 offset;       // offset in file
    pps_u32 buffer_size;  // allocated size
    pps_u32 sample_delta; // The sampling difference compared to the previous frame
    pps_u8  is_keyframe;
    pps_u8  reserved[3];
} DUA_PLAYBACK_AVFRAME_T, *DUA_PLAYBACK_AVFRAME_PTR;
/********************************************************** storage **********************************************************/

typedef enum dua_rf_mode {
    DUA_RF_433M      = 0x01,
    DUA_RF_915M      = 0x02,
    DUA_RF_868M      = 0x03,
    DUA_RF_429M      = 0x04,
    DUA_RF_433M_200K = 0x05,
    DUA_RF_315M      = 0x06,
    DUA_RF_447M      = 0x07,
    DUA_RF_B433M     = 0x08,
    DUA_RF_D433M     = 0x09,
    DUA_RF_MAX_NUM   = 0x0A,
} DUA_RF_MODE_E;
/************************************************** rf_transceiver frequency***************************************************/
typedef struct dua_battery_info {
    pps_s32 voltage;
    pps_s32 capacity;
} DUA_BATTERY_INFO_T, *DUA_BATTERY_INFO_PTR;

/************************************************** mcu ***************************************************/
/** @struct dua_wakeup_type
 * @brief  <Wake-up type>
 */
typedef enum dua_wakeup_type_e {
    DUA_WAKEUP_EVENT_KEY         = (1 << 0), // button wakeup device
    DUA_WAKEUP_EVENT_PIR         = (1 << 1), // pir alarm trigger wakeup device
    DUA_WAKEUP_EVENT_USB         = (1 << 2), // once device is powered on, it will be waked up
    DUA_WAKEUP_EVENT_WIFI_PACKET = (1 << 3), // wake up device by server
    DUA_WAKEUP_EVENT_UPGRADE     = (1 << 4), // if mcu is upgrading, the master chip will be waked up
    DUA_WAKEUP_EVENT_TAMPER      = (1 << 5), // tamper trigger, the device will be waked up
    DUA_WAKEUP_EVENT_UDSLEEP     = (1 << 6), // device power on
    DUA_WAKEUP_EVENT_INIT        = (1 << 7), // device reboot
    DUA_WAKEUP_EVENT_4G_UPGRADE  = (1 << 8),
    DUA_WAKEUP_EVENT_MAX         = (1 << 31)
} DUA_WAKEUP_TYPE_E;

typedef struct dua_mcu_param {
    pps_char pdt_type[16];
    pps_u8 battery_config;
} DUA_MCU_NV_PARAM_T, *DUA_MCU_NV_PARAM_PTR;

/************************************************** module_pwr_ctrl ***************************************************/
typedef enum dua_module_pwr_ctrl_e {
    DUA_MODULE_PWR_CTRL_OFF = 0,
    DUA_MODULE_PWR_CTRL_ON  = 1,
} DUA_MODULE_PWR_CTRL_E;

/** @enum sensor id
 * @brief  <distinguish multi-sensor devices>
 */
typedef enum dua_sensor_id {
    DUA_SENSOR_FIRST  = 0,
    DUA_SENSOR_SECOND = 1,
    DUA_SENSOR_MAX
} DUA_SENSOR_ID_E;

/** @struct dua_media_sensor_init_cfg
 * @brief  <sensor initialization configuration>
 */
typedef struct dua_media_sensor_init_cfg {
    // sensor id
    DUA_SENSOR_ID_E sensor_id; //
    pps_s32         ptz_ctrl;  // 仅用于测试msc能力级，后续需要删除
    // video
    pps_s32         main_stream_width;
    pps_s32         main_stream_height;
    pps_s32         sub_stream_width;
    pps_s32         sub_stream_height;
    pps_s32         third_stream_width;
    pps_s32         third_stream_height;
    DUA_VIDEO_TYPE_E              main_stream_encode_type;    // Master stream encoding format
    DUA_VIDEO_TYPE_E              sub_stream_encode_type;     // Substream encoding format
    DUA_VIDEO_TYPE_E              third_stream_encode_type;   // thirdstream encoding format

    DUA_CUSTOMIZED_RESOLUTION_E   main_customized_resolution; // Custom resolution of the main stream
    DUA_CUSTOMIZED_RESOLUTION_E   sub_customized_resolution;  // Custom resolution for substreams
    DUA_CUSTOMIZED_RESOLUTION_E   third_customized_resolution;  // Custom resolution for thirdstreams

    DUA_VIDEO_QUALITY_E           main_stream_quality;        // Master stream image quality
    DUA_VIDEO_QUALITY_E           sub_stream_quality;         // Substream image quality
    DUA_VIDEO_QUALITY_E           third_stream_quality;         // thirdstream image quality

    pps_s32                       main_stream_fps;            // The frame rate of the main stream stream, if filled in 0, the default frame rate
    pps_s32                       sub_stream_fps;             // Substream frame rate, if filled with 0, the default frame rate
    pps_s32                       third_stream_fps;             // Substream frame rate, if filled with 0, the default frame rate

    pps_s32                       main_stream_bitrate;        // The bitrate of the main bitstream is kbit/sec, if you enter 0, the default bitrate
    pps_s32                       sub_stream_bitrate;         // The bitrate of the substream is kbit/sec, and if you enter 0, the default bitrate
    pps_s32                       third_stream_bitrate;         // The bitrate of the substream is kbit/sec, and if you enter 0, the default bitrate

    DUA_IMGAE_FLIP_MIRROR_PARAM_T flip_mirror_param;          // Parameters for the device to flip the image
    // avproc
    pps_s32 is_avproc_use_model; // Whether algorithms such as humanoid detection, cry detection, etc. use models

    DUA_ANTIFLICKER_MODE_E flicker_freq; // Anti-flicker frequency

    DUA_DAYNIGHT_MODE_E      daynight_mode;      // Day and night mode
    DUA_DAYNIGHT_MODE_PROC_E daynight_mode_proc; // Day and night mode proc

    // OSD configuration
    DUA_OSD_CONFIG_T main_osd_cfg; // Master stream OSD configuration
    DUA_OSD_CONFIG_T sub_osd_cfg;  // Substream OSD configuration
    DUA_OSD_CONFIG_T third_osd_cfg;  // Substream OSD configuration

    DUA_AOV_OSD_CONFIG_T main_aov_osd_cfg;
    DUA_AOV_OSD_CONFIG_T sub_aov_osd_cfg;
    DUA_AOV_OSD_CONFIG_T third_aov_osd_cfg;

    // Default log configuration
    DUA_LOGO_CONFIG_T main_logo_cfg;
    DUA_LOGO_CONFIG_T sub_logo_cfg;
    DUA_LOGO_CONFIG_T third_logo_cfg;

    pps_char ir_status[16];
    pps_s32  brightness;
} DUA_MEDIA_SENSOR_INIT_CFG_T, *DUA_MEDIA_SENSOR_INIT_CFG_PTR;

/** @struct dua_media_audio_init_cfg
 * @brief  <audio initialization configuration>
 */
typedef struct dua_media_audio_init_cfg {
    pps_s32          audio_channel;        // Not used for the time being, used for subsequent multiple audio channels
    DUA_AUDIO_TYPE_E audio_lq_encode_type; // DUA_AUDIO_G711U_TYPE or DUA_AUDIO_G711A_TYPE
    pps_s32          mic_enable;           // microphone enable
    pps_u32          mic_volume;
    pps_u32          speaker_volume;
} DUA_MEDIA_AUDIO_INIT_CFG_T, *DUA_MEDIA_AUDIO_INIT_CFG_PTR;

/** @struct dua_media_init_cfg
 * @brief  <Media initialization configuration>
 */
typedef struct dua_media_init_cfg {
    // photosensitive
    pps_s32 lum_threshold; // light threshold
    pps_s32 ldr_min;
    pps_s32 ldr_max;
    pps_s32 bk_lum_threshold;    // black_light threshold
    // media config
    pps_char *mediacfg;
} DUA_MEDIA_INIT_CFG_T, *DUA_MEDIA_INIT_CFG_PTR;

typedef enum network_wifi_congest_status {
    DUA_NETWORK_WIFI_CONGEST_TIME_INIT    = 0,
    DUA_NETWORK_WIFI_CONGEST_RESET_TIME   = 1,
    DUA_NETWORK_WIFI_CONGEST_PREVIEW_WAIT = 2,
    DUA_NETWORK_WIFI_CONGEST_TIMER_WAIT   = 3,
} DUA_NETWORK_WIFI_CONGEST_STATE_E;

typedef struct {
    pps_s32 alarm_interval; // once standby, the the pir alarm will not wakeup the device in alarm_interval seconds
    pps_u32 battery_threshold; //aov模式下电量唤醒,0表示关闭
} DUA_DEVICE_STANDBY_PARAM_T;

typedef struct device_partition_info {
    pps_ulong partition_base_offset; // 分区起始地址
    pps_ulong partition_size;        // 分区大小
    pps_s32   run_os;                // run os part
    pps_s32   mtd_index;
} DEVICE_PARTITION_INFO_T, *DEVICE_PARTITION_INFO_PTR;

typedef struct dua_aac_encode_param {
    pps_char            pcm_buff[DUA_PCM_BUFF_SIZE];
    pps_u32             pcm_buff_len;
    DUA_MEDIA_HEADER_T  aac_header;
    pps_u8              resample_buf[DUA_PCM_BUFF_SIZE];
} DUA_AAC_ENCODE_PARAM_T, *DUA_AAC_ENCODE_PARAM_PTR;

typedef enum dua_media_log_leveL {
    DUA_MEDIA_PRT_EMERG,
    DUA_MEDIA_PRT_ALERT,
    DUA_MEDIA_PRT_CRIT,
    DUA_MEDIA_PRT_ERROR,
    DUA_MEDIA_PRT_WARN,
    DUA_MEDIA_PRT_NOTE,
    DUA_MEDIA_PRT_INFO,
    DUA_MEDIA_PRT_DEBUG,
    DUA_MEDIA_PRT_MAX
} DUA_MEDIA_PRT_LEVEL_E ;

#ifdef __cplusplus
}
#endif
#endif /* _DUA_COMMON_H_ */
