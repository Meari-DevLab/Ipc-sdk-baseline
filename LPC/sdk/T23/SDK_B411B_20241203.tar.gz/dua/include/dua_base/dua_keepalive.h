/**
 * @file        dua_keepalive.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua keepalive
 * @author      hcq
 * @date        2023/08/23
 * @version     1.0.0
 * @note
 */

#ifndef _DUA_KEEPAVLIE_H_
#define _DUA_KEEPAVLIE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pps_osal_type.h"

#define DUA_KEEPALIVE_SERVER_HOST_LEN 128
#define DUA_KEEPALIVE_SERVER_IP_LEN   64
#define DUA_KEEPALIVE_CONN_PKT_LEN    128
#define DUA_KEEPALIVE_PKT_LEN         64

typedef enum dua_keepalive_onlie_state {
    DUA_KEEPALIVE_STATE_STANDBY          = 0, // or enable by dua_standby --> enable_keepalive=1
    DUA_KEEPALIVE_STATE_ONLINE           = 1, // notify keepalive module --> sdk online
    DUA_KEEPALIVE_STATE_ONLINE_WITH_LOCK = 2, // notify keepalive module --> sdk online, only support one connections
} DUA_KEEPALIVE_ONLINE_STATE_E;

typedef struct dua_keepalive_config {
    pps_char server_host[DUA_KEEPALIVE_SERVER_HOST_LEN];
    pps_char server_ip[DUA_KEEPALIVE_SERVER_IP_LEN];
    pps_u16  server_port;
    pps_u16  ping_timeval;
    pps_char conn_pkt[DUA_KEEPALIVE_CONN_PKT_LEN];
    pps_char connack_pkt[DUA_KEEPALIVE_CONN_PKT_LEN];
    pps_char ping_pkt[DUA_KEEPALIVE_PKT_LEN];
    pps_char pong_pkt[DUA_KEEPALIVE_PKT_LEN];
    pps_char wakeup_pkt[DUA_KEEPALIVE_PKT_LEN];
    pps_char wakeup_ack_pkt[DUA_KEEPALIVE_PKT_LEN];
    pps_u8   conn_pkt_len;
    pps_u8   connack_pkt_len;
    pps_u8   ping_pkt_len;
    pps_u8   pong_pkt_len;
    pps_u8   wakeup_pkt_len;
    pps_u8   wakeup_ack_pkt_len;
    pps_u8   res[2];
} DUA_KEEPALIVE_CONFIG_T, *DUA_KEEPALIVE_CONFIG_PTR;

typedef struct dua_keepalive_server_params {
    pps_char server_ip[DUA_KEEPALIVE_SERVER_IP_LEN];
    pps_u16  server_port;
} DUA_KEEPALIVE_SERVER_PARAMS_T, *DUA_KEEPALIVE_SERVER_PARAMS_PTR;

/** @fn      pps_s32 dua_keepalive_set_config(pps_void *dua_handler, DUA_KEEPALIVE_CONFIG_PTR config);
 * @brief   <set keepalive config for lpc device>
 * @param   [in] dua_handler: dua handler
 * @param   [in] config: keepalive config
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_set_config(pps_void *dua_handler, pps_void *config, pps_u32 len);

/** @fn      pps_s32 dua_keepalive_set_ping_timeval(pps_void *dua_handler, pps_u16 timeval);
 * @brief   <set keepalive timeval for lpc device>
 * @param   [in] dua_handler: dua handler
 * @param   [in] timeval: keepalive timeval
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_set_ping_timeval(pps_void *dua_handler, pps_u16 timeval);

/** @fn      pps_s32 dua_keepalive_set_online_state(pps_void *dua_handler, DUA_KEEPALIVE_ONLINE_STATE_E state);
 * @brief   <set keepalive online state>
 * @param   [in] dua_handler: dua handler
 * @param   [in] state: keepalive online state
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_set_online_state(pps_void *dua_handler, DUA_KEEPALIVE_ONLINE_STATE_E state);

/** @fn      pps_s32 dua_keepalive_get_server_params(pps_void *dua_handler, DUA_KEEPALIVE_SERVER_PARAMS_PTR params);
 * @brief   <get keepalive server params for lpc device>
 * @param   [in] dua_handler: dua handler
 * @param   [in] params: keepalive server params
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_get_server_params(pps_void *dua_handler, DUA_KEEPALIVE_SERVER_PARAMS_PTR params);

/** @fn      pps_s32 dua_keepalive_set_server_params(pps_void *dua_handler, DUA_KEEPALIVE_SERVER_PARAMS_PTR params);
 * @brief   <set keepalive server params for lpc device>
 * @param   [in] dua_handler: dua handler
 * @param   [in] params: keepalive server params
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_set_server_params(pps_void *dua_handler, DUA_KEEPALIVE_SERVER_PARAMS_PTR params);

/** @fn      pps_s32 dua_keepalive_get_wakeup_packet(pps_void *dua_handler, pps_void *packet, pps_s32 len);
 * @brief   <get keepalive wakeup packet for lpc device>
 * @param   [in] dua_handler: dua handler
 * @param   [out] packet: keepalive wakeup packet, max_len=256
 * @param   [in | out] len: keepalive wakeup packet length
 * @return  0 - success | else - failure
 */
pps_s32 dua_keepalive_get_wakeup_packet(pps_void *dua_handler, pps_void *packet, pps_s32 len);

#ifdef __cplusplus
}
#endif

#endif // _DUA_KEEPAVLIE_H_
