/**
 * @file        dua_upgrade.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/06/08
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_UPGRADE_H_
#define _DUA_UPGRADE_H_

#include "dua_common.h"
#include "pps_osal_type.h"
#include "dua_event_def.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef pps_void (*dua_upgrade_percent_cb)(pps_u32 event_id, pps_void *data, pps_s32 data_len);

/** @fn      pps_s32 dua_upgrade_init_ex(pps_void *dua_handler, pps_char **dsp_buf, pps_s32 *dsp_buf_size);
 * @brief   <dua upgrade init>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] dsp_buf    : dsp buf
 * @return  0 - success | else - failure
 */
pps_s32 dua_upgrade_init(pps_void *dua_handler, pps_char **dsp_buf, pps_s32 *dsp_buf_size);

/** @fn      pps_s32 dua_upgrade_deinit(pps_void *dua_handler, pps_char **dsp_buf, pps_bool upgrade_suc);
 * @brief   <dua upgrade deinit>
 * @param   [in] dua_handler: dua handler dsp_buf: dsp_buf
 * @return  0 - success | else - failure
 */
pps_s32 dua_upgrade_deinit(pps_void *dua_handler, pps_char *dsp_buf, pps_bool upgrade_suc);

/** @fn      pps_s32 dua_sensor_pir_init(pps_void *dua_handler);
 * @brief   <pir module init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_upgrade_partition(pps_void *dua_handler, pps_char *upfile_name, pps_char *upfile_buf, pps_s32 upfile_size, pps_u32 upfile_checksum, dua_upgrade_percent_cb percent_cb);

/** @fn      pps_s32 dua_sensor_pir_init(pps_void *dua_handler);
 * @brief   <pir module init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_get_partition_info(pps_void *dua_handler, pps_char *upfile_name, DEVICE_PARTITION_INFO_PTR partition_info);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_UPGRADE_H_ */
