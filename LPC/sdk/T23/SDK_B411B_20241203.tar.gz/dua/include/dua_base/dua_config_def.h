/**
 * @file        dua_config_device_inner.h
 *
 * @copyright   2023 Meari technology Co., Ltd
 *
 * @brief       Describe information here...
 *
 * @author      zhangsujie
 *
 * @date        2023/07/26
 *
 * @version     1.0.0
 *
 * @note
 */
#ifndef __DUA_CONFIG_DEVICE_INNER_H
#define __DUA_CONFIG_DEVICE_INNER_H

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum dua_dev_cfg_sensor_id {
    DUA_DEV_CFG_SENSOR_0 = 0,
    DUA_DEV_CFG_SENSOR_1 = 1,
    DUA_DEV_CFG_SENSOR_2 = 2,
    DUA_DEV_CFG_SENSOR_3 = 3,
    DUA_DEV_CFG_SENSOR_4 = 4,
    DUA_DEV_CFG_SENSOR_5 = 5,
    DUA_DEV_CFG_SENSOR_6 = 6,
    DUA_DEV_CFG_SENSOR_7 = 7,
    DUA_DEV_CFG_SENSOR_8 = 8,
    DUA_DEV_CFG_SENSOR_ID_MAX,
} DUA_DEV_CFG_SENSOR_ID_E;

typedef enum dua_ptz_speed_level {
    DUA_PTZ_SPEED_LEVEL_1 = 0,
    DUA_PTZ_SPEED_LEVEL_2 = 1,
    DUA_PTZ_SPEED_LEVEL_3 = 2,
    DUA_PTZ_SPEED_LEVEL_4 = 3,
    DUA_PTZ_SPEED_LEVEL_5 = 4,
    DUA_PTZ_SPEED_LEVEL_MAX,
} DUA_PTZ_SPEED_LEVLE_E;

typedef struct dua_speaker_cfg {
    pps_u8 digital_vol; // Maximum digital speaker volume
    pps_u8 percent_vol; // Percentage volume of speakers
    pps_u8 res[2];
} DUA_SPEAKER_CFG_T, *DUA_SPEAKER_CFG_PTR;

typedef struct dua_microphone_cfg {
    pps_u8 digital_vol; // Maximum digital volume of the microphone
    pps_u8 res[3];
} DUA_MICROPHONE_CFG_T, *DUA_MICROPHONE_CFG_PTR;

typedef struct dua_vstream_cfg {
    pps_u8   encode_type; // coding format H264/H265
    pps_u8   fps;         // frame rate
    pps_u8   img_quality; // image quality
    pps_u8   res0;
    pps_u16  bitrate; // bitrate
    pps_u16  w;       // Customized Resolution
    pps_u16  h;       // Customized Resolution
    pps_u32  logo_transprency; // logo transprency
    pps_char logo_path[DUA_LOGO_PATH_LEN];    // lofo file path
    pps_s16  logo_x;  // logo x coordinate
    pps_s16  logo_y;  // logo y coordinate
    pps_s16  osd_x;   // time OSD x coordinate
    pps_s16  osd_y;   // time OSD y coordinate
    pps_s16  aov_osd_x;   // aov OSD x coordinate
    pps_s16  aov_osd_y;   // aov OSD y coordinate
    pps_char res[4];
} DUA_VSTREAM_CFG_T, *DUA_VSTREAM_CFG_PTR;

typedef struct dua_sensor_cfg {
    DUA_VSTREAM_CFG_T main_stream_cfg; // Main Stream Related Parameters
    DUA_VSTREAM_CFG_T sub_stream_cfg;  // Substream Related Parameters
    DUA_VSTREAM_CFG_T third_stream_cfg;  // Thirdstream Related Parameters
    pps_u8            is_flip;         // Flip or not   0-not support  1-flip
    pps_u8            is_mirror;       // Mirror or not 0-not support  1-mirror
    pps_u8            is_main_sensor;  // Whether it is a main camera screen  0-not main sensor 1-main sensor
    pps_u8            position;        // 1left 2right 3up 4down 5middle
    pps_u8            res;
    pps_char          osd_prefix[DUA_OSD_PRE_SUF_FIX_LEN]; // osd prefix
    pps_char          osd_suffix[DUA_OSD_PRE_SUF_FIX_LEN]; // osd suffix
    pps_char          aov_osd_str[DUA_AOV_OSD_MAX_LEN];    // aov osd str
    pps_u16           PFOV;                                // horizontal lens FOV
    pps_u16           TFOV;                                // vertical lens FOV
} DUA_SENSOR_CFG_T, *DUA_SENSOR_CFG_PTR;

#define PPS_PIR_LEVEL_MAX 10

typedef struct dua_pir_para {
    pps_u8 sensit;
    pps_u8 pulse;
} DUA_PIR_PARA_T;

typedef struct dua_pir_cfg {
    DUA_PIR_PARA_T pir_para[PPS_PIR_LEVEL_MAX]; // pir gear level
    pps_char       res[4];
} DUA_PIR_CFG_T, *DUA_PIR_CFG_PTR;

typedef struct dua_pd_sensitivity_value {
    pps_u8 low;
    pps_u8 midlow;
    pps_u8 mid;
    pps_u8 midhigh;
    pps_u8 high;
} DUA_SENSITIVITY_VALUE_T;

typedef struct dua_db_sensitivity_value {
    pps_u8 low;
    pps_u8 mid;
    pps_u8 high;
} DUA_DB_SENSITIVITY_VALUE_T;

typedef struct dua_avproc_cfg {
    DUA_SENSITIVITY_VALUE_T pd_sensitivity[DUA_SENSOR_MAX];
    DUA_DB_SENSITIVITY_VALUE_T db_sensitivity;
    pps_u8 db_offset;
} DUA_AVPROC_T;

typedef struct dua_media_cfg {
    pps_u16        lum_value;
    pps_u16        lum_min;  // Minimum Light Sensitivity Threshold
    pps_u16        lum_max;  // Maximum Light Sensitivity Threshold
    pps_u16        bk_lum_value; // BlackLight device switch fps light sensitivity threshold
    pps_u8         rec_type; // Video type
    DUA_AVPROC_T   avproc;
    pps_char res[9];
} DUA_MEDIA_CFG_T, *DUA_MEDIA_CFG_PTR;

typedef struct dua_astream_cfg {
    pps_s32  raw_encode_type; // audio streaming coding format PCM
    pps_s32  raw_sample_rate; // audio streaming sampling rate
    pps_s32  lq_encode_type;  // audio streaming coding format G711A/G711U
    pps_s32  lq_sample_rate;  // audio streaming sampling rate
    pps_s32  hq_encode_type;  // audio streaming coding format AAC
    pps_s32  hq_sample_rate;  // audio streaming sampling rate
    pps_char res[8];
} DUA_ASTREAM_CFG_T, *DUA_ASTREAM_CFG_PTR;

typedef struct dua_ptz_cfg {
    pps_u8   bind_peripheral[16];
    pps_s32  max_pan_angle;  // Maximum horizontal angle
    pps_s32  max_tilt_angle; // Maximum vertical angle
    pps_s32  max_pan_steps;  // Horizontal Maximum Steps
    pps_s32  max_tilt_steps; // Vertical Maximum Steps
    pps_s32  ptz_structure_angle;
    pps_s32  pan_home_preset;                   // Horizontal origin position
    pps_s32  tilt_home_preset;                  // Vertical origin position
    pps_s32  is_lr_reverse;                     // flip left-right    0-not reverse 1-reverse
    pps_s32  is_ud_reverse;                     // turn upside-down   0-not reverse 1-reverse
    pps_s32  capa;                              // 0-not support, 1-up/down/left/right, 2-left/right, 3-up/down
    pps_s32  pan_tps[DUA_PTZ_SPEED_LEVEL_MAX];  // the greater tps, the slower speed, and the greater level, the faster speed
    pps_s32  tilt_tps[DUA_PTZ_SPEED_LEVEL_MAX]; // the greater tps, the slower speed, and the greater level, the faster speed
    pps_s32  p_deviation;                       // Motor linkage, deviation of center points between two screens
    pps_s32  t_deviation;                       // Motor linkage, deviation of center points between two screens
    pps_char res[8];
} DUA_PTZ_CFG_T, *DUA_PTZ_CFG_PTR;

typedef struct dua_dfStatus_cfg {
    pps_s32  pir_level;
    pps_s32  ptz_mute_switch;
    pps_s32  ptz_track_switch;
    pps_s32  md_detect_switch;
    pps_s32  pd_filter_switch;
    pps_s32  recorder_switch;
    pps_char res[8];
} DUA_DFSTATUS_CFG_T, *DUA_DFSTATUS_CFG_PTR;

typedef struct dua_device_cfg {
    DUA_SPEAKER_CFG_T    spk_cfg;
    DUA_MICROPHONE_CFG_T mic_cfg;
    pps_char             optical_code[64];
    pps_s32              sensor_num;
    DUA_SENSOR_CFG_T     sensor_cfg[DUA_DEV_CFG_SENSOR_ID_MAX];
    DUA_ASTREAM_CFG_T    astream_cfg[2];
    DUA_MEDIA_CFG_T      media_cfg;
    DUA_PIR_CFG_T        pir_cfg;
    pps_s32              ptz_num;
    DUA_PTZ_CFG_T        ptz_cfg[2];
    DUA_DFSTATUS_CFG_T   default_status_cfg;
    pps_char            *ppsmedia_cfg;
    pps_s32              dev_class;
    DUA_CAPABILITY_T     hardware_cfg;
    DUA_EX_CAPABILITY_T  dua_app_cfg;
    pps_s32              dai_cfg;
} DUA_DEVICE_CFG_T, *DUA_DEVICE_CFG_PTR;

#ifdef __cplusplus
}
#endif
#endif /* __DUA_CONFIG_DEVICE_INNER_H */
