/**
 * @file        dua_ptz.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       云台控制
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_PTZ_H_
#define _DUA_PTZ_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_ptz_init(pps_void *dua_handler);
 * @brief   <ptz init>
 * @param   [in] dua_handler : dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_ptz_init(pps_void *dua_handler);

/** @fn      pps_s32 dua_ptz_move_ctrl(DUA_PTZ_MOVE_CTRL_CMD cmd, pps_u32 move_steps, pps_u32 move_speed);
 * @brief   <ptz control>
 * @param   [in] dua_handler: dua handler
 * @param   [in] cmd        : control cmd
 * @param   [in] move_steps : ptz motor move steps
 * @param   [in] move_speed : ptz motor move speed, recommand 0 ~ 5000
 * @return  0 - success | else - failure
 * @note    this methods is non-block api
 */
pps_s32 dua_ptz_move_ctrl(pps_void *dua_handler, DUA_PTZ_MOVE_CTRL_CMD_E cmd, pps_u32 move_steps, pps_u32 move_speed);

/** @fn      pps_s32 dua_ptz_set_origin(pps_s32 p_step, pps_s32 t_step)
 * @brief   <set origin>
 * @return  0 - success | else - failure
 */
pps_s32 dua_ptz_set_origin(pps_s32 p_step, pps_s32 t_step);

/** @fn      pps_s32 dua_ptz_get_steps(DUA_MOTOR_PT_TYPE_E type);
 * @brief   <get steps>
 * @param   [in] type: ptz motor type P or T
 * @return  0 - success | else - failure
 */
pps_s32 dua_ptz_get_steps(DUA_MOTOR_PT_TYPE_E type);

/** @fn      pps_s32 dua_ptz_move_ctrl_waiting_time(pps_u32 move_steps, pps_u32 move_speed);
 * @brief   <ptz control time>
 * @param   [in] dua_handler: dua handler
 * @param   [in] move_steps : ptz motor move steps
 * @param   [in] move_speed : ptz motor move speed, recommand 0 ~ 5000
 * @return  0 - success | else - failure
 */
pps_s32 dua_ptz_move_ctrl_waiting_time(pps_void *dua_handler, pps_u32 move_steps, pps_u32 move_speed);

/** @fn      pps_s32 dua_ptz_get_status(DUA_MOTOR_PT_TYPE_E type);
 * @brief   <get steps>
 * @param   [in] type: ptz motor type P or T
 * @return  0 - success | else - failure
 */
pps_s32 dua_ptz_get_status(DUA_MOTOR_PT_TYPE_E type);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_PTZ_H_ */
