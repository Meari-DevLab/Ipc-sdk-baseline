/**
 * @file        dua_light.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       light control
 * @author      Shi Yanlin
 * @date        2023/03/09
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_LIGHT_H_
#define _DUA_LIGHT_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_light_init(pps_void *dua_handler);
 * @brief   <dua light module init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_light_init(pps_void *dua_handler);

/** @fn      pps_s32 dua_led_ctrl(pps_void *dua_handler, DUA_LED_ID_E led, pps_s32 switch_on);
 * @brief   <led control>
 * @param   [in] dua_handler: dua handler
 * @param   [in] led        : led type
 * @param   [in] switch_on  : switch, 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_led_ctrl(pps_void *dua_handler, DUA_LED_ID_E led, pps_s32 switch_on);

/** @fn      pps_s32 dua_led_get_status(pps_void *dua_handler, DUA_LED_ID_E led, pps_s32 *switch_on);
 * @brief   <get led status>
 * @param   [in]  dua_handler: dua handler
 * @param   [in]  led       : led type
 * @param   [out] switch_on : switch, 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_led_get_status(pps_void *dua_handler, DUA_LED_ID_E led, pps_s32 *switch_on);

/** @fn      pps_s32 dua_rgb_light_ctrlpps_s32 dua_rgb_light_ctrl(pps_s32 red_brightness, pps_s32 green_brightness, pps_s32 blue_brightness);
 * @brief   <rgb led control>
 * @param   [in] dua_handler     : dua handler
 * @param   [in] red_brightness  : red   brightness 0 ~ 100
 * @param   [in] green_brightness: green brightness 0 ~ 100
 * @param   [in] blue_brightness : blue  brightness 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_rgb_light_ctrl(pps_void *dua_handler, pps_s32 red_brightness, pps_s32 green_brightness, pps_s32 blue_brightness);

/** @fn      pps_s32 dua_rgb_light_get_status(pps_void *dua_handler, pps_s32 *red_brightness, pps_s32 *green_brightness, pps_s32 *blue_brightness);
 * @brief   <get rgb brightness>
 * @param   [in]  dua_handler     : dua handler
 * @param   [out] red_brightness  : red   brightness 0 ~ 100
 * @param   [out] green_brightness: green brightness 0 ~ 100
 * @param   [out] blue_brightness : blue  brightness 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_rgb_light_get_status(pps_void *dua_handler, pps_s32 *red_brightness, pps_s32 *green_brightness, pps_s32 *blue_brightness);

/** @fn      pps_s32 dua_white_light_ctrl(pps_void *dua_handler, DUA_LIGHT_CTRL_TYPE_E type, pps_s32 brightness);
 * @brief   <white light control>
 * @param   [in] dua_handler: dua handler
 * @param   [in] type       : white light ctrl type
 * @param   [in] brightness : brightness 0 ~ 100
 * @return  0 - success | else - failure
 * @warning When turning off the lights, it is necessary to set the type to DUA_LIGHT_CTRL_TYPE_SOFT
 */
pps_s32 dua_white_light_ctrl(pps_void *dua_handler, DUA_LIGHT_CTRL_TYPE_E type, pps_s32 brightness);

/** @fn      pps_s32 dua_white_light_get_status(pps_void *dua_handler, pps_s32 *brightness);
 * @brief   <get white light status>
 * @param   [in]  dua_handler: dua handler
 * @param   [out] brightness : brightness 0 ~ 100
 * @return  0 - success | else - failure
 */
pps_s32 dua_white_light_get_status(pps_void *dua_handler, pps_s32 *brightness);

/** @fn      pps_s32 dua_infrared_led_ctrl(DUA_INFR_ID_E infr, pps_s32 switch_on);
 * @brief   <infrared led control>
 * @param   [in] dua_handler: dua handler
 * @param   [in] infr       : infrared led
 * @param   [in] switch_on  : switch, 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_infrared_led_ctrl(pps_void *dua_handler, DUA_INFR_ID_E infr, pps_s32 switch_on);

/** @fn      pps_s32 dua_infrared_led_get_status(DUA_INFR_ID_E infr, pps_s32 *switch_on);
 * @brief   <get infrared led status>
 * @param   [in]  dua_handler: dua handler
 * @param   [in]  infr       : infrared led
 * @param   [out] switch_on  : switch, 0 - disable | 1 - enable
 * @return  0 - success | else - failure
 */
pps_s32 dua_infrared_led_get_status(pps_void *dua_handler, DUA_INFR_ID_E infr, pps_s32 *switch_on);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_LIGHT_H_ */
