/**
 * @file         pps_osal_errno.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief        pps_osal_errno.h file
 *
 * @author       lyl
 *
 * @date         2021/11/24 17:13
 *
 * @version:     1.0.0
 *
 * @note         Something you must take care...
 */

#ifndef _PPS_OSAL_ERRNO_H_
#define _PPS_OSAL_ERRNO_H_

#define PPS_OSAL_SUCCESS         (0) // suceess
#define PPS_OSAL_ERROR_FAILED    (1) // general failed
#define PPS_OSAL_ERRNO_DEFINE(n) (0x0000 + n)

/* 系统错误码 */
#define PPS_OSAL_ERROR_EPERM           PPS_OSAL_ERRNO_DEFINE(1)  /* Operation not permitted */
#define PPS_OSAL_ERROR_ENOENT          PPS_OSAL_ERRNO_DEFINE(2)  /* No such file or directory */
#define PPS_OSAL_ERROR_ESRCH           PPS_OSAL_ERRNO_DEFINE(3)  /* No such process */
#define PPS_OSAL_ERROR_EINTR           PPS_OSAL_ERRNO_DEFINE(4)  /* Interrupted system call */
#define PPS_OSAL_ERROR_EIO             PPS_OSAL_ERRNO_DEFINE(5)  /* I/O error */
#define PPS_OSAL_ERROR_ENXIO           PPS_OSAL_ERRNO_DEFINE(6)  /* No such device or address */
#define PPS_OSAL_ERROR_E2BIG           PPS_OSAL_ERRNO_DEFINE(7)  /* Arg list too long */
#define PPS_OSAL_ERROR_ENOEXEC         PPS_OSAL_ERRNO_DEFINE(8)  /* Exec format error */
#define PPS_OSAL_ERROR_EBADF           PPS_OSAL_ERRNO_DEFINE(9)  /* Bad file number */
#define PPS_OSAL_ERROR_ECHILD          PPS_OSAL_ERRNO_DEFINE(10) /* No child processes */
#define PPS_OSAL_ERROR_EAGAIN          PPS_OSAL_ERRNO_DEFINE(11) /* Try again */
#define PPS_OSAL_ERROR_ENOMEM          PPS_OSAL_ERRNO_DEFINE(12) /* Out of memory */
#define PPS_OSAL_ERROR_EACCES          PPS_OSAL_ERRNO_DEFINE(13) /* Permission denied */
#define PPS_OSAL_ERROR_EFAULT          PPS_OSAL_ERRNO_DEFINE(14) /* Bad address */
#define PPS_OSAL_ERROR_ENOTBLK         PPS_OSAL_ERRNO_DEFINE(15) /* Block device required */
#define PPS_OSAL_ERROR_EBUSY           PPS_OSAL_ERRNO_DEFINE(16) /* Device or resource busy */
#define PPS_OSAL_ERROR_EEXIST          PPS_OSAL_ERRNO_DEFINE(17) /* File exists */
#define PPS_OSAL_ERROR_EXDEV           PPS_OSAL_ERRNO_DEFINE(18) /* Cross-device link */
#define PPS_OSAL_ERROR_ENODEV          PPS_OSAL_ERRNO_DEFINE(19) /* No such device */
#define PPS_OSAL_ERROR_ENOTDIR         PPS_OSAL_ERRNO_DEFINE(20) /* Not a directory */
#define PPS_OSAL_ERROR_EISDIR          PPS_OSAL_ERRNO_DEFINE(21) /* Is a directory */
#define PPS_OSAL_ERROR_EINVAL          PPS_OSAL_ERRNO_DEFINE(22) /* Invalid argument */
#define PPS_OSAL_ERROR_ENFILE          PPS_OSAL_ERRNO_DEFINE(23) /* File table overflow */
#define PPS_OSAL_ERROR_EMFILE          PPS_OSAL_ERRNO_DEFINE(24) /* Too many open files */
#define PPS_OSAL_ERROR_ENOTTY          PPS_OSAL_ERRNO_DEFINE(25) /* Not a typewriter */
#define PPS_OSAL_ERROR_ETXTBSY         PPS_OSAL_ERRNO_DEFINE(26) /* Text file busy */
#define PPS_OSAL_ERROR_EFBIG           PPS_OSAL_ERRNO_DEFINE(27) /* File too large */
#define PPS_OSAL_ERROR_ENOSPC          PPS_OSAL_ERRNO_DEFINE(28) /* No space left on device */
#define PPS_OSAL_ERROR_ESPIPE          PPS_OSAL_ERRNO_DEFINE(29) /* Illegal seek */
#define PPS_OSAL_ERROR_EROFS           PPS_OSAL_ERRNO_DEFINE(30) /* Read-only file system */
#define PPS_OSAL_ERROR_EMLINK          PPS_OSAL_ERRNO_DEFINE(31) /* Too many links */
#define PPS_OSAL_ERROR_EPIPE           PPS_OSAL_ERRNO_DEFINE(32) /* Broken pipe */
#define PPS_OSAL_ERROR_EDOM            PPS_OSAL_ERRNO_DEFINE(33) /* Math argument out of domain of func */
#define PPS_OSAL_ERROR_ERANGE          PPS_OSAL_ERRNO_DEFINE(34) /* Math result not representable */
#define PPS_OSAL_ERROR_EDEADLK         PPS_OSAL_ERRNO_DEFINE(35) /* Resource deadlock would occur */
#define PPS_OSAL_ERROR_ENAMETOOLONG    PPS_OSAL_ERRNO_DEFINE(36) /* File name too long */
#define PPS_OSAL_ERROR_ENOLCK          PPS_OSAL_ERRNO_DEFINE(37) /* No record locks available */
#define PPS_OSAL_ERROR_ENOSYS          PPS_OSAL_ERRNO_DEFINE(38) /* Function not implemented */
#define PPS_OSAL_ERROR_ENOTEMPTY       PPS_OSAL_ERRNO_DEFINE(39) /* Directory not empty */
#define PPS_OSAL_ERROR_ELOOP           PPS_OSAL_ERRNO_DEFINE(40) /* Too many symbolic links encountered */
#define PPS_OSAL_ERROR_EWOULDBLOCK     PPS_OSAL_ERROR_EAGAIN     /* Operation would block */
#define PPS_OSAL_ERROR_ENOMSG          PPS_OSAL_ERRNO_DEFINE(41) /* No message of desired type */
#define PPS_OSAL_ERROR_EIDRM           PPS_OSAL_ERRNO_DEFINE(42) /* Identifier removed */
#define PPS_OSAL_ERROR_ECHRNG          PPS_OSAL_ERRNO_DEFINE(43) /* Channel number out of range */
#define PPS_OSAL_ERROR_EL2NSYNC        PPS_OSAL_ERRNO_DEFINE(44) /* Level 2 not synchronized */
#define PPS_OSAL_ERROR_EL3HLT          PPS_OSAL_ERRNO_DEFINE(45) /* Level 3 halted */
#define PPS_OSAL_ERROR_EL3RST          PPS_OSAL_ERRNO_DEFINE(46) /* Level 3 reset */
#define PPS_OSAL_ERROR_ELNRNG          PPS_OSAL_ERRNO_DEFINE(47) /* Link number out of range */
#define PPS_OSAL_ERROR_EUNATCH         PPS_OSAL_ERRNO_DEFINE(48) /* Protocol driver not attached */
#define PPS_OSAL_ERROR_ENOCSI          PPS_OSAL_ERRNO_DEFINE(49) /* No CSI structure available */
#define PPS_OSAL_ERROR_EL2HLT          PPS_OSAL_ERRNO_DEFINE(50) /* Level 2 halted */
#define PPS_OSAL_ERROR_EBADE           PPS_OSAL_ERRNO_DEFINE(51) /* Invalid exchange */
#define PPS_OSAL_ERROR_EBADR           PPS_OSAL_ERRNO_DEFINE(52) /* Invalid request descriptor */
#define PPS_OSAL_ERROR_EXFULL          PPS_OSAL_ERRNO_DEFINE(53) /* Exchange full */
#define PPS_OSAL_ERROR_ENOANO          PPS_OSAL_ERRNO_DEFINE(54) /* No anode */
#define PPS_OSAL_ERROR_EBADRQC         PPS_OSAL_ERRNO_DEFINE(55) /* Invalid request code */
#define PPS_OSAL_ERROR_EBADSLT         PPS_OSAL_ERRNO_DEFINE(56) /* Invalid slot */
#define PPS_OSAL_ERROR_EDEADLOCK       PPS_OSAL_ERROR_EDEADLK
#define PPS_OSAL_ERROR_EBFONT          PPS_OSAL_ERRNO_DEFINE(57)  /* Bad font file format */
#define PPS_OSAL_ERROR_ENOSTR          PPS_OSAL_ERRNO_DEFINE(58)  /* Device not a stream */
#define PPS_OSAL_ERROR_ENODATA         PPS_OSAL_ERRNO_DEFINE(59)  /* No data available */
#define PPS_OSAL_ERROR_ETIME           PPS_OSAL_ERRNO_DEFINE(60)  /* Timer expired */
#define PPS_OSAL_ERROR_ENOSR           PPS_OSAL_ERRNO_DEFINE(61)  /* Out of streams resources */
#define PPS_OSAL_ERROR_ENONET          PPS_OSAL_ERRNO_DEFINE(62)  /* Machine is not on the network */
#define PPS_OSAL_ERROR_ENOPKG          PPS_OSAL_ERRNO_DEFINE(63)  /* Package not installed */
#define PPS_OSAL_ERROR_EREMOTE         PPS_OSAL_ERRNO_DEFINE(64)  /* Object is remote */
#define PPS_OSAL_ERROR_ENOLINK         PPS_OSAL_ERRNO_DEFINE(65)  /* Link has been severed */
#define PPS_OSAL_ERROR_EADV            PPS_OSAL_ERRNO_DEFINE(66)  /* Advertise error */
#define PPS_OSAL_ERROR_ESRMNT          PPS_OSAL_ERRNO_DEFINE(67)  /* Srmount error */
#define PPS_OSAL_ERROR_ECOMM           PPS_OSAL_ERRNO_DEFINE(68)  /* Communication error on send */
#define PPS_OSAL_ERROR_EPROTO          PPS_OSAL_ERRNO_DEFINE(69)  /* Protocol error */
#define PPS_OSAL_ERROR_EMULTIHOP       PPS_OSAL_ERRNO_DEFINE(70)  /* Multihop attempted */
#define PPS_OSAL_ERROR_EDOTDOT         PPS_OSAL_ERRNO_DEFINE(71)  /* RFS specific error */
#define PPS_OSAL_ERROR_EBADMSG         PPS_OSAL_ERRNO_DEFINE(72)  /* Not a data message */
#define PPS_OSAL_ERROR_EOVERFLOW       PPS_OSAL_ERRNO_DEFINE(73)  /* Value too large for defined data type */
#define PPS_OSAL_ERROR_ENOTUNIQ        PPS_OSAL_ERRNO_DEFINE(74)  /* Name not unique on network */
#define PPS_OSAL_ERROR_EBADFD          PPS_OSAL_ERRNO_DEFINE(75)  /* File descriptor in bad state */
#define PPS_OSAL_ERROR_EREMCHG         PPS_OSAL_ERRNO_DEFINE(76)  /* Remote address changed */
#define PPS_OSAL_ERROR_ELIBACC         PPS_OSAL_ERRNO_DEFINE(77)  /* Can not access a needed shared library */
#define PPS_OSAL_ERROR_ELIBBAD         PPS_OSAL_ERRNO_DEFINE(78)  /* Accessing a corrupted shared library */
#define PPS_OSAL_ERROR_ELIBSCN         PPS_OSAL_ERRNO_DEFINE(79)  /* .lib section in a.out corrupted */
#define PPS_OSAL_ERROR_ELIBMAX         PPS_OSAL_ERRNO_DEFINE(80)  /* Attempting to link in too many shared libraries */
#define PPS_OSAL_ERROR_ELIBEXEC        PPS_OSAL_ERRNO_DEFINE(81)  /* Cannot exec a shared library directly */
#define PPS_OSAL_ERROR_EILSEQ          PPS_OSAL_ERRNO_DEFINE(82)  /* Illegal byte sequence */
#define PPS_OSAL_ERROR_ERESTART        PPS_OSAL_ERRNO_DEFINE(83)  /* Interrupted system call should be restarted */
#define PPS_OSAL_ERROR_ESTRPIPE        PPS_OSAL_ERRNO_DEFINE(84)  /* Streams pipe error */
#define PPS_OSAL_ERROR_EUSERS          PPS_OSAL_ERRNO_DEFINE(85)  /* Too many users */
#define PPS_OSAL_ERROR_ENOTSOCK        PPS_OSAL_ERRNO_DEFINE(86)  /* Socket operation on non-socket */
#define PPS_OSAL_ERROR_EDESTADDRREQ    PPS_OSAL_ERRNO_DEFINE(87)  /* Destination address required */
#define PPS_OSAL_ERROR_EMSGSIZE        PPS_OSAL_ERRNO_DEFINE(88)  /* Message too long */
#define PPS_OSAL_ERROR_EPROTOTYPE      PPS_OSAL_ERRNO_DEFINE(89)  /* Protocol wrong type for socket */
#define PPS_OSAL_ERROR_ENOPROTOOPT     PPS_OSAL_ERRNO_DEFINE(90)  /* Protocol not available */
#define PPS_OSAL_ERROR_EPROTONOSUPPORT PPS_OSAL_ERRNO_DEFINE(91)  /* Protocol not supported */
#define PPS_OSAL_ERROR_ESOCKTNOSUPPORT PPS_OSAL_ERRNO_DEFINE(92)  /* Socket type not supported */
#define PPS_OSAL_ERROR_EOPNOTSUPP      PPS_OSAL_ERRNO_DEFINE(93)  /* Operation not supported on transport endpoint */
#define PPS_OSAL_ERROR_EPFNOSUPPORT    PPS_OSAL_ERRNO_DEFINE(94)  /* Protocol family not supported */
#define PPS_OSAL_ERROR_EAFNOSUPPORT    PPS_OSAL_ERRNO_DEFINE(95)  /* Address family not supported by protocol */
#define PPS_OSAL_ERROR_EADDRINUSE      PPS_OSAL_ERRNO_DEFINE(96)  /* Address already in use */
#define PPS_OSAL_ERROR_EADDRNOTAVAIL   PPS_OSAL_ERRNO_DEFINE(97)  /* Cannot assign requested address */
#define PPS_OSAL_ERROR_ENETDOWN        PPS_OSAL_ERRNO_DEFINE(98)  /* Network is down */
#define PPS_OSAL_ERROR_ENETUNREACH     PPS_OSAL_ERRNO_DEFINE(99)  /* Network is unreachable */
#define PPS_OSAL_ERROR_ENETRESET       PPS_OSAL_ERRNO_DEFINE(100) /* Network dropped connection because of reset */
#define PPS_OSAL_ERROR_ECONNABORTED    PPS_OSAL_ERRNO_DEFINE(101) /* Software caused connection abort */
#define PPS_OSAL_ERROR_ECONNRESET      PPS_OSAL_ERRNO_DEFINE(102) /* Connection reset by peer */
#define PPS_OSAL_ERROR_ENOBUFS         PPS_OSAL_ERRNO_DEFINE(103) /* No buffer space available */
#define PPS_OSAL_ERROR_EISCONN         PPS_OSAL_ERRNO_DEFINE(104) /* Transport endpoint is already connected */
#define PPS_OSAL_ERROR_ENOTCONN        PPS_OSAL_ERRNO_DEFINE(105) /* Transport endpoint is not connected */
#define PPS_OSAL_ERROR_ESHUTDOWN       PPS_OSAL_ERRNO_DEFINE(106) /* Cannot send after transport endpoint shutdown */
#define PPS_OSAL_ERROR_ETOOMANYREFS    PPS_OSAL_ERRNO_DEFINE(107) /* Too many references: cannot splice */
#define PPS_OSAL_ERROR_ETIMEDOUT       PPS_OSAL_ERRNO_DEFINE(108) /* Connection timed out */
#define PPS_OSAL_ERROR_ECONNREFUSED    PPS_OSAL_ERRNO_DEFINE(109) /* Connection refused */
#define PPS_OSAL_ERROR_EHOSTDOWN       PPS_OSAL_ERRNO_DEFINE(110) /* Host is down */
#define PPS_OSAL_ERROR_EHOSTUNREACH    PPS_OSAL_ERRNO_DEFINE(111) /* No route to host */
#define PPS_OSAL_ERROR_EALREADY        PPS_OSAL_ERRNO_DEFINE(112) /* Operation already in progress */
#define PPS_OSAL_ERROR_EINPROGRESS     PPS_OSAL_ERRNO_DEFINE(113) /* Operation now in progress */
#define PPS_OSAL_ERROR_ESTALE          PPS_OSAL_ERRNO_DEFINE(114) /* Stale NFS file handle */
#define PPS_OSAL_ERROR_EUCLEAN         PPS_OSAL_ERRNO_DEFINE(115) /* Structure needs cleaning */
#define PPS_OSAL_ERROR_ENOTNAM         PPS_OSAL_ERRNO_DEFINE(116) /* Not a XENIX named type file */
#define PPS_OSAL_ERROR_ENAVAIL         PPS_OSAL_ERRNO_DEFINE(117) /* No XENIX semaphores available */
#define PPS_OSAL_ERROR_EISNAM          PPS_OSAL_ERRNO_DEFINE(118) /* Is a named type file */
#define PPS_OSAL_ERROR_EREMOTEIO       PPS_OSAL_ERRNO_DEFINE(119) /* Remote I/O error */
#define PPS_OSAL_ERROR_EDQUOT          PPS_OSAL_ERRNO_DEFINE(120) /* Quota exceeded */
#define PPS_OSAL_ERROR_ENOMEDIUM       PPS_OSAL_ERRNO_DEFINE(121) /* No medium found */
#define PPS_OSAL_ERROR_EMEDIUMTYPE     PPS_OSAL_ERRNO_DEFINE(122) /* Wrong medium type */
#define PPS_OSAL_ERROR_ECANCELED       PPS_OSAL_ERRNO_DEFINE(123) /* Operation Canceled */
#define PPS_OSAL_ERROR_ENOKEY          PPS_OSAL_ERRNO_DEFINE(124) /* Required key not available*/
#define PPS_OSAL_ERROR_EKEYEXPIRED     PPS_OSAL_ERRNO_DEFINE(125) /* Keyhas expired */
#define PPS_OSAL_ERROR_EKEYREVOKED     PPS_OSAL_ERRNO_DEFINE(126) /* Keyhas been revoked */
#define PPS_OSAL_ERROR_EKEYREJECTED    PPS_OSAL_ERRNO_DEFINE(127) /* Key was rejected by service*/
#define PPS_OSAL_ERROR_EOWNERDEAD      PPS_OSAL_ERRNO_DEFINE(128) /* Ownerdied */
#define PPS_OSAL_ERROR_ENOTRECOVERABLE PPS_OSAL_ERRNO_DEFINE(129) /* State not recoverable */
#define PPS_OSAL_ERROR_ERFKILL         PPS_OSAL_ERRNO_DEFINE(130) /* Operation not possible due to RF-kill */
#define PPS_OSAL_ERROR_NOTIMPL         PPS_OSAL_ERRNO_DEFINE(131)
#define PPS_OSAL_ERROR_NOTSUPPORT      PPS_OSAL_ERRNO_DEFINE(132)

#endif // _PPS_OSAL_ERRNO_H_
