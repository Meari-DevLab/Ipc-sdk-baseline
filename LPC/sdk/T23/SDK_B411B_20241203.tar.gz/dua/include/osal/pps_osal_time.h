/**
 * @file        pps_osal_time.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer time module
 *
 * @author      jim
 *
 * @date        2020/3/24
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef _PPS_OSAL_TIME_H_
#define _PPS_OSAL_TIME_H_

#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief seconds and microseconds since the Epoch, expressed by a structure.
 */
typedef struct pps_timeval_t {
    pps_u64 tv_sec;  /** seconds */
    pps_u64 tv_usec; /** microseconds */
} pps_timeval_t;

/**
 * @brief hours/minutes/seconds since the Epoch, expressed by a structure.
 */
typedef struct pps_tm_t {
    pps_u32 tm_year; /* year: from 1900 */
    pps_u32 tm_mon;  /* mon: 0-11 */
    pps_u32 tm_mday; /* days: 1-31 */
    pps_u32 tm_sec;  /* seconds */
    pps_u32 tm_min;  /* minutes */
    pps_u32 tm_hour; /* hours */
} pps_tm_t;

/**
 * @brief sleep for a specified number of seconds, Thread safety
 *
 * @param seconds [IN] a specified number of seconds
 *
 * @return the operation status, 0 on success, -1 on error
 */
int pps_sleep(pps_u32 seconds);

/**
 * @brief suspend execution for microsecond intervals, Thread safety
 *
 * @param useconds [IN] microsecond number
 *
 * @return the operation status, 0 on success, -1 on error
 */
int pps_usleep(pps_u64 useconds);

/**
 * @brief get the current time, expressed as seconds and microseconds since the Epoch,
 *        and store it in the timeval structure pointed to by tp.
 *
 * @param tp [OUT] the current time value
 *
 * @return the operation status, 0 on success, -1 on error
 */
int pps_gettimeofday(pps_timeval_t *tp);

/**
 * @brief get the time as the number of seconds since the Epoch,
 *        1970-01-01 00:00:00 +0000 (UTC).
 *
 * @param void
 *
 * @return the number of seconds since the Epoch on success, -1 on error.
 */
pps_u32 pps_utc_time(void);

/**
 * @brief get the current time, store it in the tm structure pointed to by stru_curtime
 *        1970-01-01 00:00:00 +0000 (UTC).
 *
 * @param tm [OUT] the current time of pps_tm_t tm
 *
 * @return void
 */
void pps_localtime(pps_tm_t *tm);

/**
 * @brief get the time since system startup
 *
 * @param void
 *
 * @return The time since system startup (ms)
 */

pps_u64 pps_clock_monotonic_get(void);

#ifdef __cplusplus
}
#endif
#endif /* _PPS_OSAL_TIME_H_ */
