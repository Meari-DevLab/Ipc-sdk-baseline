/**
 * @file        pps_osal_mem.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer memory module
 *
 * @author      jim
 *
 * @date        2019/7/5
 *
 * @version     0.1.0
 *
 * @note
 */

#ifndef _PPS_OSAL_MEM_H_
#define _PPS_OSAL_MEM_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief initialize memory module
 *
 * @param size allocate memory limitation
 */
void pps_mem_global_init(int size);

/**
 * @brief deinitialize memory module
 *
 */
void pps_mem_global_free(void);

/**
 * @brief allocates size bytes and returns a pointer to the allocated memory.
 *  The memory is not initialized. If size is 0, then it returns NULL
 *
 * @param size memory size
 * @return the memory address
 */
void *pps_malloc(unsigned int size);

/**
 * @brief allocates memory for an array of nmemb elements of size bytes each
 *  and returns a pointer  to  the  allocated  memory.
 *  The  memory is set to zero. If nmemb or size is 0, then it returns NULL
 *
 * @param nmemb elements number
 * @param size element size
 * @return the memory address
 */
void *pps_calloc(unsigned int nmemb, unsigned int size);

/**
 * @brief frees the memory space pointed to by ptr, which must have been returned by a previous call to
 *  pps_malloc(), pps_calloc().
 *
 * @param ptr the memory address
 */
void pps_free(void *ptr);

/**
 * @brief show memory debug information.
 *
 */
void pps_mem_debug(void);

/**
 * @brief check if all memories allocated are freed.
 *
 * @return 1 if all freed, 0 if any one not freed.
 */
int pps_mem_all_freed(void);

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_MEM_H_ */
