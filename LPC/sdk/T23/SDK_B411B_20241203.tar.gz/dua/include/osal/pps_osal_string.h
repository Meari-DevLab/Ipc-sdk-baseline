/**
 * @file        pps_osal_string.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       Descript the file here...
 *              If you want descript file more, please write here...
 *
 * @author
 *
 * @date        2019/7/5
 *
 * @version     0.1.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_OSAL_STRING_H_
#define _PPS_OSAL_STRING_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct pps_string_t {
    const char  *p;
    unsigned int len;
} pps_string_t;

/**
 * @brief locate character in string
 *
 * @param s [IN] source string
 *
 * @param n [IN] locate max index
 *
 * @param c [IN] character to locate
 *
 * @return return a pointer to the matched character or NULL if the character is not found.
 */
char *pps_strnchr(char *s, int n, int c);

/**
 * @brief locate character in string
 *
 * @param s [IN] pps_string_t pointer
 *
 * @param c [IN] character to locate
 *
 * @return return a pointer to the matched character or NULL if the character is not found.
 */
char *pps_strchr(pps_string_t *s, int c);

/**
 * @brief at most n bytes of src are copied
 *
 * @param dest [IN] stores the copied content
 *
 * @param src [IN] source string
 *
 * @param n [IN] copy max num
 *
 * @return dest
 */
char *pps_strncpy(char *dest, char *src, int n);

/**
 * @brief Format a variable argument as a string
 *
 * @param str [IN] target lacation
 *
 * @param size [IN] number of bytes copied
 *
 * @param format [IN] Format to a string
 *
 * @return
 */
int pps_snprintf(char *str, int size, char *format, ...);

#ifdef __cplusplus
}
#endif

#endif /* __PPS_OSAL_STRING_H_ */
