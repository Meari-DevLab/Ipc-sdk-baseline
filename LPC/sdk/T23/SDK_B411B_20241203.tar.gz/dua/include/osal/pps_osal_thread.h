/**
 * @file        pps_osal_thread.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       OS abstruct layer thread module
 *
 * @author      jim
 *
 * @date        2020/3/25
 *
 * @version     0.1.0
 *
 * @note        Something you must take care...
 */

#ifndef _PPS_OSAL_THREAD_H_
#define _PPS_OSAL_THREAD_H_


#include "pps_osal_define.h"
#include "pps_osal_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* definition in the C file */
/* the biggest priority numbre among all system */
#define PPS_THREAD_PRIORITY_MAX 100
/* the shortest name among all system
 * Now, shortest name is rtthread's name, is 8
 */
#define PPS_THREAD_NAME_MAX 8
/* rtthread's timeslice of thread */
#define PPS_THREAD_TIMESLICE 5

#ifdef CONFIG_POSIX
#include <pthread.h>
#define pps_thread_t pthread_t
#else
#define pps_thread_t void *
#endif

typedef struct pps_thread_attr_t {
    const char *name;
    /* [1~100],  0=default value,  other undefined.
    linux: 1 = lowest, 100 = highest,
    windows: 1 = highest, 100 = lowest */
    int priority;
    int stack_size;
} pps_thread_attr_t;

/**
 * @brief create a new joinable thread
 *
 * @param thread [OUT] a reference to the thread just created, is passed back to the caller.
 *
 * @param attr [in] a point to set attribute of the thread. if it is NULL, That means the default attribute.
 *
 * @param start_routine [IN] an entry point to the thread ( thread main routine ).
 *
 * @param arg [IN] a point to parameters which as input to the thread routine.
 *
 * @return the operation status, PPS_OSAL_SUCCESS on success, PPS_OSAL_ERROR_FAILED on error.
 */
int pps_thread_create(pps_thread_t *thread, pps_thread_attr_t *attr, void *(*start_routine)(void *), void *arg);

/**
 * @brief create a new joinable thread
 *
 * @param thread [OUT] a reference to the thread just created, is passed back to the caller.
 *
 * @param attr [in] a point to set attribute of the thread. if it is NULL, That means the default attribute.
 *
 * @param funcptr_ [IN] function addr to start the new thread.
 *
 * @param args [IN] total optional arguments pass to the above function.
 *
 * @return 0 if successful, otherwise an error number returned.
 */
int pps_thread_create_args(pps_thread_t *thread, pps_thread_attr_t *attr, void *funcptr_, unsigned args, ...);

/**
 * @brief set attribute of the thread to detach mod.
 *
 * @param thread [IN] a reference to the created thread.
 *
 * @return the operation status, PPS_OSAL_SUCCESS on success, PPS_OSAL_ERROR_FAILED on error.
 */
int pps_thread_detach(pps_thread_t thread);

/**
 * @brief create a new detachable thread and detach thread.
 *
 * @param thread [OUT] a reference to the thread just created.
 *
 * @param name [IN] an arbitrary character string to identify the thread.
 *
 * @param priority [IN] thread priority, 1~100, 1 = highest, 100 = lowest, 0=default value, undefined.
 *
 * @param stack_size [IN] The size of the stack to be allocated for the thread. If the size is lower
 *                        then the minimun size of stack, it will be set into minimun size.
 *                        If the size is zero, it will set default value.
 * @param start_routine [IN] an entry point to the thread ( thread main routine ).
 *
 * @param arg [IN] a point to parameters which as input to the thread routine.
 *
 * @return the operation status, PPS_OSAL_SUCCESS on success, PPS_OSAL_ERROR_FAILED on error.
 */
int pps_thread_spawn(pps_thread_t *thread, const char *name, int priority, int stack_size, void *(*start_routine)(void *), void *arg);

/**
 * @brief create a new detachable thread and detach thread.
 *
 * @param thread [OUT] a reference to the thread just created.
 *
 * @param priority [IN] thread priority, 1~100, 1 = highest, 100 = lowest, 0=default value, undefined.
 *
 * @param stacksize [IN] The size of the stack to be allocated for the thread. If the size is lower
 *                        then the minimun size of stack, it will be set into minimun size.
 *                        If the size is zero, it will set default value.
 * @param funcptr_ [IN] an entry point to the thread ( thread main routine ).
 *
 * @param args [IN] total optional arguments pass to the above function optional arguments.
 *
 * @return 0 if successful, otherwise an error number returned.
 */
int pps_thread_spawn_args(pps_thread_t *thread, int priority, size_t stacksize, void *funcptr_, unsigned args, ...);

/**
 * @brief adjust thread is alive or not
 *
 * @param thread [IN] a reference to the created thread.
 *
 * @return the thread status, pps_true on alive, pps_false on not alive.
 */
pps_bool pps_thread_is_alive(pps_thread_t thread);

/**
 * @brief get thread identifier of the calling thread
 *
 * @param void
 *
 * @return return pps_thread_t in thread identifier
 */
pps_thread_t pps_thread_self(void);

int pps_thread_join(pps_thread_t thread);

/**
 * @func    pps_thread_exit
 * @brief   exit thread and free thread resource
 *
 * @param   tid[in] thread ID
 * @return  On success, return 0. On error, return -1 or error code.
 **/
extern void pps_thread_exit(void *tid);

/**
 * @func    pps_thread_setname
 * @brief   set thread name
 *
 * @param   name[in] thread name
 **/
extern void pps_thread_setname(char *name);

#ifdef __cplusplus
}
#endif
#endif /* _PPS_OSAL_THREAD_H_ */
