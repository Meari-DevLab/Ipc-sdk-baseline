/**
 * @file        pps_osal_define.h
 *
 * @copyright   2020 Meari technology Co., Ltd
 *
 * @brief       some useful definitions listed here
 *
 * @author      jim
 *
 * @date        2020/03/25
 *
 * @version     0.1.0
 *
 */

#ifndef _PPS_OSAL_DEFINE_H_
#define _PPS_OSAL_DEFINE_H_

#ifdef __cplusplus
extern "C" {
#endif

enum PPS_OS_TYPE_E {
    PPS_OS_TYPE_WINDOWS,
    PPS_OS_TYPE_MACOSX,
    PPS_OS_TYPE_LINUX,
    PPS_OS_TYPE_UNIX,
    PPS_OS_TYPE_LITEOS,
    PPS_OS_TYPE_RTTHREAD,
    PPS_OS_TYPE_FREERTOS,
};

/* Definitions for WORDSIZE */
#ifdef __INTPTR_WIDTH__
#if __INTPTR_WIDTH__ == 64
#define CONFIG_PPS_WORDSIZE 64
#else /* 32bit */
#define CONFIG_PPS_WORDSIZE 32
#endif /* __WORDSIZE == 64 */
#endif /* __WORDSIZE */

/*********************************************
 *  Definitions for CONFIG_OS_XXXX
 */
#ifdef _WIN32
#ifndef CONFIG_OS_WINDOWS
#define CONFIG_OS_WINDOWS 1
#endif
#endif /* _WIN32 */

#ifdef __linux__
#ifndef CONFIG_OS_LINUX
#define CONFIG_OS_LINUX 1
#endif

#ifndef CONFIG_POSIX
#define CONFIG_POSIX 1
#endif

#endif /* __linux__ */

#ifdef __darwin__
#ifndef CONFIG_OS_MACOSX
#define CONFIG_OS_MACOSX 1
#endif
#endif /* __darwin__ */

#ifdef __RTTHREAD__
#ifndef CONFIG_OS_RTTHREAD
#define CONFIG_OS_RTTHREAD 1
#endif
#endif /* __RTTHREAD__ */

/* end of CONFIG_OS_XXX
 *********************************************/

#ifndef PPS_TRUE
#define PPS_TRUE 1
#endif

#ifndef PPS_FALSE
#define PPS_FALSE 0
#endif

#ifndef PPS_OK
#define PPS_OK 0
#endif

#ifndef PPS_NULL
#ifdef __cplusplus
#define PPS_NULL (0)
#else
#define PPS_NULL ((void *)0)
#endif
#endif

#define PPS_MAX(a, b) ((a) > (b) ? (a) : (b))
#define PPS_MIN(a, b) ((a) > (b) ? (b) : (a))

#ifdef __GNUC__
#define __PPS_OSAL_UNUSED__ __attribute__((unused))
#define __PPS_OSAL_PACKED__ __attribute__((packed))
#else
#define __PPS_OSAL_UNUSED__
#define __PPS_OSAL_PACKED__
#endif

#ifndef PPS_OFFSETOF
#define PPS_OFFSETOF(TYPE, MEMBER) ((size_t) & ((TYPE *)0)->MEMBER)
#endif

#ifndef PPS_ARRAY_SIZE
#define PPS_ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif

#ifdef __cplusplus
}
#endif

#endif /* _PPS_OSAL_DEFINE_H_ */
