/**
 * @file        pps_osal_queue.h
 *
 * @copyright   2019 Meari technology Co., Ltd
 *
 * @brief       队列抽象层
 *
 * @author      jim
 *
 * @date        2019/10/08
 *
 * @version     1.0.0
 *
 * @note        Something you must take care...
 */

#ifndef __PPS_QUEUE_H__
#define __PPS_QUEUE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct pps_queue_s {
    int   pktsiz;
    int   nbpkts;
    int   head; /* 读指针, pop */
    int   tail; /* 写指针, push */
    int  *pktlen;
    char *buf;
} pps_queue_t;

pps_queue_t *pps_queue_new(int pktsiz, int nbpkts);
void         pps_queue_free(pps_queue_t *q);

int pps_queue_query(pps_queue_t *q, int index, char **ppacket, int **ppktlen);
int pps_queue_inused(pps_queue_t *q, int index);
int pps_queue_next(pps_queue_t *q, int index);
int pps_queue_head(pps_queue_t *q);
int pps_queue_tail(pps_queue_t *q);
int pps_queue_push(pps_queue_t *q);
int pps_queue_pop(pps_queue_t *q);

/* free space */
int pps_queue_space(pps_queue_t *q);

/* used count */
int pps_queue_count(pps_queue_t *q);

/* write packet, 适合简单的消息队列模型(data_size < 1KB), 内部有数据拷贝 */
int pps_queue_write_packet(pps_queue_t *q, void *packet, int len);

/* read packet, 适合简单的消息队列模型(data_size < 1KB), 内部有数据拷贝 */
int pps_queue_read_packet(pps_queue_t *q, void *packet, int len);

#ifdef __cplusplus
}
#endif

#endif /* __PPS_QUEUE_H__ */
