/**
 * @file        dua_event_def.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       dua event
 * @author      Shi Yanlin
 * @date        2023/03/10
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_EVENT_DEF_H_
#define _DUA_EVENT_DEF_H_

#include "pps_osal_type.h"
#include "mcp_list.h"
#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_void (*dua_event_callback_f)(pps_s32 event_id, pps_void *data, pps_s32 data_len);
 * @brief   <Event callback functions>
 * @param   [in] event_id: Event ID
 * @param   [in] data    : data
 * @param   [in] data_len: Data length
 * @return  0 - Initialization succeeded  | else - Initialization failed
 */
typedef pps_void (*dua_event_callback_f)(pps_u32 event_id, pps_void *data, pps_s32 data_len);

/** @enum  dua_event
 * @brief <dua_event>
 */
typedef enum dua_event {
    // GPIO
    // RESET BUTTON
    DUA_EVENT_BUTTION_RESET_KEYDOWN        = 0x1000, // Reset key press event
    DUA_EVENT_BUTTION_RESET_KEYUP          = 0x1001, // Reset key release event
    DUA_EVENT_BUTTION_RESET_KEYPRESS_SHORT = 0x1002, // The reset key is briefly pressed for the event
    DUA_EVENT_BUTTION_RESET_KEYPRESS_LONG  = 0x1003, // Reset key long-press event
    // DOORBELL BUTTON
    DUA_EVENT_BUTTION_DOORBELL_KEYDOWN        = 0x1010, // Doorbell key press event
    DUA_EVENT_BUTTION_DOORBELL_KEYUP          = 0x1011, // Doorbell key release event
    DUA_EVENT_BUTTION_DOORBELL_KEYPRESS_SHORT = 0x1012, // The doorbell key is short-pressed for the event
    DUA_EVENT_BUTTION_DOORBELL_KEYPRESS_LONG  = 0x1013, // The doorbell key is long pressed on the event
    // PIR
    DUA_EVENT_PIR_ALARM = 0x1100, // PIR alarm
    DUA_EVENT_PIR_NOISE = 0x1101, // PIR noise

    // RESET
    DUA_EVENT_DEVICE_RESET = 0x1200, // DEVCICE RESET

    // VOICEMAIL
    DUA_EVENT_PLAY_VOICEMAIL     = 0x1300, // play voice message
    DUA_EVENT_VOICEMAIL_FINISHED = 0x1301,
    DUA_EVENT_START_SPEAK        = 0x1302,
    DUA_EVENT_STOP_SPEAK         = 0x1303,

    // UPGRADE
    DUA_EVENT_UPGRADE_START    = 0x2000, // Start the upgrade
    DUA_EVENT_UPGRADE_PROGRESS = 0x2001, // The Upgrade Progress parameter is accompanied by a uint percentage progress
    DUA_EVENT_UPGRADE_DONE     = 0x2002, // The upgrade is complete

    // NETWORK All network-related events are parameterized DUA_NETWORK_EVENT_INFO_PTR
    // WIFI
    DUA_EVENT_NETWORK_AP_MODE_ENTER     = 0x3001, // Enter AP mode
    DUA_EVENT_NETWORK_AP_MODE_EXIT      = 0x3002, // Exit AP mode
    DUA_EVENT_NETWORK_WIFI_CONNECTING   = 0x3003, // WiFi connected
    DUA_EVENT_NETWORK_WIFI_CONNECTED    = 0x3004, // The wifi connection is successful
    DUA_EVENT_NETWORK_WIFI_DISCONNECTED = 0x3005, // WiFi connection disconnected
    DUA_EVENT_NETWORK_WIFI_NET_ACCESS   = 0x3006, // wifi successfully obtained IP, access net
    // WIRE NET
    DUA_EVENT_NETWORK_WIRE_NET_CONNECTING   = 0x3100, // Wired network connection
    DUA_EVENT_NETWORK_WIRE_NET_CONNECTED    = 0x3101, // The wired network connection is successful
    DUA_EVENT_NETWORK_WIRE_NET_DISCONNECTED = 0x3102, // Wired network connection failed
    // 4G
    DUA_EVENT_NETWORK_4G_NET_CONNECTING   = 0x3200, // 4G network connection
    DUA_EVENT_NETWORK_4G_NET_CONNECTED    = 0x3201, // The 4G network connection is successful
    DUA_EVENT_NETWORK_4G_NET_DISCONNECTED = 0x3202, // The 4G network is disconnected
    // BULETOOTH
    DUA_EVENT_NETWORK_BT_MODE_ENTER   = 0x3301, // Enter BT mode
    DUA_EVENT_NETWORK_BT_MODE_EXIT    = 0x3302, // Exit BT mode
    DUA_EVENT_NETWORK_BT_CONNECTING   = 0x3303, // The wifi connection is successful
    DUA_EVENT_NETWORK_BT_DISCONNECTED = 0x3304, // WiFi connection disconnected

    // MEDIA
    DUA_EVENT_MEDIA_INIT                = 0x3401,
    DUA_EVENT_MEDIA_DEINIT              = 0x3402,
    // DETECTION
    DUA_EVENT_AVPROC_MD_IN_GIRD_ALARM   = 0x4000, // Motion detection alarm in the area
    DUA_EVENT_AVPROC_MD_IN_VISION_ALARM = 0x4001, // Motion detection alarm in field of view
    DUA_EVENT_AVPROC_PD_IN_GIRD_ALARM   = 0x4010, // Humanoid detection alarm in the area
    DUA_EVENT_AVPROC_PD_IN_VISION_ALARM = 0x4011, // Humanoid detection alarm in the field of vision
    DUA_EVENT_AVPROC_BCD_ALARM          = 0x4020, // Crying detection alarm
    DUA_EVENT_AVPROC_NOISE_ALARM        = 0x4030, // Noise decibel detection alarm
    // TRACKING
    DUA_EVENT_AVPROC_MD_TRACKING = 0x4100, // Motion tracking
    DUA_EVENT_AVPROC_PD_TRACKING = 0x4101, // Humanoid tracking
    // DAYNIGHT
    DUA_EVENT_MEDIA_DAY_NIGHT_SWITCHED = 0x4500, // Day and night switching with parameters: DUA_DAYNIGHT_EVENT_INFO_PTR

    // TAMPER
    DUA_EVENT_TAMPER_ALARM = 0x4600, // Demolition alarm

    // SDCARD
    DUA_EVENT_SDCARD_FORMAT_START = 0x5000, // Start formatting sdcard
    DUA_EVENT_SDCARD_FORMATING    = 0x5001, // Format sdcard
    DUA_EVENT_SDCARD_FORMAT_DONE  = 0x5002, // Formatting sdcard is complete
    DUA_EVENT_SDCARD_MOUNT_START  = 0x5003, // Start mounting sdcard
    DUA_EVENT_SDCARD_MOUNT_DONE   = 0x5004, // Mount sdcard completes
    DUA_EVENT_SDCARD_UMOUNT_START = 0x5005, // Start uninstalling sdcard
    DUA_EVENT_SDCARD_UMOUNT_DONE  = 0x5006, // Uninstalling sdcard is complete
    DUA_EVENT_SDCARD_DISK_FULL    = 0x5007, // sdcard is full
    DUA_EVENT_SDCARD_FSCK_START   = 0x5008, // Start repairing sdcard
    DUA_EVENT_SDCARD_FSCK_FINISH  = 0x5009, // Repair sdcard complete

    // RECORDER
    DUA_EVENT_RECORDER_START              = 0x6000, // Start recording
    DUA_EVENT_RECORDER_STOP               = 0x6001, // Stop recording
    DUA_EVENT_RECORDER_NEW_SEGMENT        = 0x6002, // Start New Fragment parameter with filename of the new fragment
    DUA_EVENT_RECORDER_END_SEGMENT        = 0x6003, // End Fragment parameter with filename of the new fragment
    DUA_EVENT_RECORDER_DISK_NO_SPACE_LEFT = 0x6004, // sdcard is full
    DUA_EVENT_RECORDER_DISK_IO_ERROR      = 0x6005, // sdcard read and write failed

    // MCU EVENT
    DUA_EVENT_SYSLINK_ONLINE    = 0x7000, // mcu_syslink_online
    DUA_EVENT_SYSLINK_RESET     = 0x7001, // mcu_syslink_reset
    DUA_EVENT_SYSLINK_PWRDOWN   = 0x7002, // mcu_syslink_pwrdown
    DUA_EVENT_SYSLINK_KEEPALIVE = 0x7003, // mcu_syslink_keepalive

    DUA_EVENT_REMOTE_WAKEUP = 0x7010, // Remote wake-up
    DUA_EVENT_BATTERY_EMPTY = 0x7011, // The battery is empty


    // FACTORY
    DUA_EVENT_ENTER_FACTORY_MODE = 0xff00, // enter factory mode

} DUA_EVENT_E;

/** @enum  dua_network_connect_err_code
 * @brief <Error code for an error in the DUA network connection>
 */
typedef enum dua_network_connect_err_code {
    DUA_NETWORK_ERR_NULL = 0,
    DUA_PSK_IS_ILLEGAL = 1,
    // WIFI
    DUA_NETWORK_WIFI_PSK_ERR         = 0x1000,
    DUA_NETWORK_WIFI_CONNECT_FAILURE = 0x1001,
    DUA_NETWORK_WIFI_NOT_FOUND       = 0x1002,
    DUA_NETWORK_WIFI_SCAN_FAILURE    = 0x1003,
    // WIRE NET
    // 0x2000
    // 4G
    DUA_NETWORK_4G_HARDWARE_ERR         = 0x3000, // The communication serial port is abnormal
    DUA_NETWORK_4G_MEI_ERR              = 0x3001, // Can't read the MEI
    DUA_NETWORK_4G_NO_SIM_CARD          = 0x3002, // SIM card not found
    DUA_NETWORK_4G_ICCID_ERR            = 0x3003, // The ICCID cannot be read
    DUA_NETWORK_4G_SIM_CARD_WITH_PIN    = 0x3004, // SIM cards have PIN codes
    DUA_NETWORK_4G_NO_SIGNAL            = 0x3005, // No signal/weak signal
    DUA_NETWORK_4G_APN_ERR              = 0x3006, // APN error
    DUA_NETWORK_4G_REGISTER_NET_FAILURE = 0x3007, // Note net rejected
} DUA_NETWORK_CONNECT_ERR_CODE_E;

/** @struct dua_network_event_info
 * @brief  <Information about DUA network connection events>
 */
typedef struct dua_network_event_info {
    pps_char                       interface[16];
    DUA_NETWORK_CONNECT_ERR_CODE_E err_code;
    pps_char                       res[4];
} DUA_NETWORK_EVENT_INFO_T, *DUA_NETWORK_EVENT_INFO_PTR;

/** @struct dua_daynight_event_info
 * @brief  <DUA Day and Night Switch Event Information>
 */
typedef struct dua_daynight_event_info {
    pps_u8   is_day; // 0 - day | 1 night
    pps_char res[7];
} DUA_DAYNIGHT_EVENT_INFO_T, *DUA_DAYNIGHT_EVENT_INFO_PTR;

/** @struct dua_recoder_event_info
 * @brief  <Information about the DUA video event>
 */
typedef struct dua_recoder_event_info {
    pps_s32  job_id;
    pps_char segment_path[128];
    pps_char res[4];
} DUA_RECORDER_EVENT_INFO_T, *DUA_RECORDER_EVENT_INFO_PTR;

static inline pps_s32 mcp_list_event_trigger(MCP_LIST_PTR linked_list_head, pps_u32 event_id, void *data, pps_s32 data_len)
{
    MCP_LIST_PTR head = linked_list_head;

    while (head) {
        if (head->callback) {
            ((dua_event_callback_f)(head->callback))(event_id, data, data_len);
        }
        head = head->next;
    }

    return 0;
}

#ifdef __cplusplus
}
#endif
#endif /* _DUA_EVENT_DEF_H_ */
