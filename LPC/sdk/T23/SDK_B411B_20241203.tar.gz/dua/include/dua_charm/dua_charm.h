/**
 * @file        dua_charm.h
 * @copyright   2016-2023 Meari technology Co., Ltd
 * @brief       Describe information here...
 * @author      Shi Yanlin
 * @date        2023/03/11
 * @version     1.0.0
 * @note
 */
#ifndef _DUA_CHARM_H_
#define _DUA_CHARM_H_

#include "pps_osal_type.h"
#include "dua_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @fn      pps_s32 dua_charm_init(pps_void *dua_handler);
 * @brief   <charm init>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_charm_init(pps_void *dua_handler, DUA_RF_MODE_E rf);

/** @fn      pps_s32 dua_charm_deinit(pps_void *dua_handler);
 * @brief   <charm deinit>
 * @param   [in] dua_handler: dua handler
 * @return  0 - success | else - failure
 */
pps_s32 dua_charm_deinit(pps_void *dua_handler);

/** @fn      pps_s32 dua_charm_unpair(pps_void *dua_handler, CHARM_SEND_PKG_PTR data);
 * @brief   <charm send msg>
 * @param   [in] dua_handler: dua handler
 * @param   [in] data       : data
 * @return  0 - success | else - failure
 */
pps_s32 dua_charm_send(pps_void *dua_handler, CHARM_SEND_PKG_PTR data);

#ifdef __cplusplus
}
#endif
#endif /* _DUA_CHARM_H_ */
